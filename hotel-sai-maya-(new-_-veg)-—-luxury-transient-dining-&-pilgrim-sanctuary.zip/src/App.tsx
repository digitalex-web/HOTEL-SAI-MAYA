import React, { useState, useEffect } from 'react';
import { MenuItem, CartItem } from './types';
import { AdminProvider, useAdmin } from './context/AdminContext';
import { AdminLayout } from './components/admin/AdminLayout';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { PhilosophySection } from './components/PhilosophySection';
import { SensoryMenu } from './components/SensoryMenu';
import { BanquetSection } from './components/BanquetSection';
import { TransitConcierge } from './components/TransitConcierge';
import { InstagramShowcase } from './components/InstagramShowcase';
import { ReviewsSection } from './components/ReviewsSection';
import { GeoLocationHub } from './components/GeoLocationHub';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { ReservationModal } from './components/ReservationModal';
import { MobileBottomDock } from './components/MobileBottomDock';
import { triggerWhatsAppOrder } from './data/restaurantData';
import { Shield, Sparkles } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { isAdminMode, toggleAdminMode, homepageSections } = useAdmin();

  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReservationOpen, setIsReservationOpen] = useState(false);

  // Check URL hash for direct #admin access
  useEffect(() => {
    if (window.location.hash === '#admin' || window.location.hash === '#/admin') {
      toggleAdminMode(true);
    }

    const handleHashChange = () => {
      if (window.location.hash === '#admin' || window.location.hash === '#/admin') {
        toggleAdminMode(true);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [toggleAdminMode]);

  // Set of added item IDs for easy visual status on menu cards
  const addedItemIds = new Set(cartItems.map((ci) => ci.item.id));

  // Add item to cart
  const handleAddToCart = (
    item: MenuItem,
    dietary: 'Standard Satvik' | 'Strict Jain' | 'Mild Spices' | 'Extra Desi Ghee' = 'Standard Satvik'
  ) => {
    setCartItems((prev) => {
      const existing = prev.find((ci) => ci.item.id === item.id);
      if (existing) {
        return prev.map((ci) =>
          ci.item.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prev, { item, quantity: 1, dietaryPreference: dietary }];
    });
  };

  // Update item quantity
  const handleUpdateQuantity = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      setCartItems((prev) => prev.filter((ci) => ci.item.id !== itemId));
    } else {
      setCartItems((prev) =>
        prev.map((ci) => (ci.item.id === itemId ? { ...ci, quantity: newQty } : ci))
      );
    }
  };

  // Update dietary preference for a specific item
  const handleUpdateDietary = (
    itemId: string,
    pref: 'Standard Satvik' | 'Strict Jain' | 'Mild Spices' | 'Extra Desi Ghee'
  ) => {
    setCartItems((prev) =>
      prev.map((ci) => (ci.item.id === itemId ? { ...ci, dietaryPreference: pref } : ci))
    );
  };

  // Clear cart
  const handleClearCart = () => {
    setCartItems([]);
  };

  // Total item count for pill badges
  const totalCartCount = cartItems.reduce((acc, curr) => acc + curr.quantity, 0);

  // Smooth scroll to sensory menu
  const handleScrollToMenu = () => {
    const menuEl = document.getElementById('menu');
    if (menuEl) {
      menuEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // If in Admin Mode, render the comprehensive Hotel & Banquet Management Dashboard
  if (isAdminMode) {
    return <AdminLayout />;
  }

  // Check section visibility from Website Manager
  const isSectionVisible = (id: string) => {
    const sec = homepageSections.find((s) => s.id === id);
    return sec ? sec.isVisible : true;
  };

  return (
    <div className="min-h-screen bg-[#0c0c0e] text-[#f4f4f5] flex flex-col font-sans-ui selection:bg-[#c5a059]/30 selection:text-white">
      {/* Global Navigation Capsule */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReservation={() => setIsReservationOpen(true)}
        onOpenWhatsApp={() => triggerWhatsAppOrder()}
      />

      {/* Main Content Sections with Admin Visibility Controls */}
      <main className="flex-1">
        {/* Section B: Hero Stage */}
        {isSectionVisible('hero') && (
          <HeroSection
            onExploreMenu={handleScrollToMenu}
            onOpenWhatsApp={() => triggerWhatsAppOrder()}
            onOpenReservation={() => setIsReservationOpen(true)}
          />
        )}

        {/* Philosophy & Culinary Heritage Bridge */}
        {isSectionVisible('philosophy') && <PhilosophySection />}

        {/* Section C: The Sensory Menu Experience */}
        {isSectionVisible('menu') && (
          <SensoryMenu
            onAddToCart={handleAddToCart}
            addedItemIds={addedItemIds}
          />
        )}

        {/* Section D: 🏛️ Banquet Hall & Events */}
        {isSectionVisible('banquet') && <BanquetSection />}

        {/* Section E: Transit Concierge & Amenities Grid (Why Sai Maya) */}
        {isSectionVisible('transit') && (
          <TransitConcierge
            onPreOrder={() => setIsReservationOpen(true)}
          />
        )}

        {/* Section F: Instagram Social Showcase & Visual Chronicle (@hotel_sai_maya_new) */}
        {isSectionVisible('gallery') && <InstagramShowcase />}

        {/* Section G: Revered Guest Experiences & Reviews Carousel */}
        {isSectionVisible('reviews') && <ReviewsSection />}

        {/* Section H: Interactive Geo-Navigation & Real-time Location Hub */}
        {isSectionVisible('location') && <GeoLocationHub />}
      </main>

      {/* Global Footer with Discreet Admin Portal Link */}
      <Footer onOpenAdmin={() => toggleAdminMode(true)} />

      {/* Section G: Mobile-Optimized Executive Dock (Screens < 768px) */}
      <MobileBottomDock
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWhatsApp={() => triggerWhatsAppOrder()}
        onOpenReservation={() => setIsReservationOpen(true)}
      />

      {/* Slide-out Express Tray / Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onUpdateDietary={handleUpdateDietary}
        onClearCart={handleClearCart}
      />

      {/* Pilgrim VIP Reservation & Transit Enquiry Modal */}
      <ReservationModal
        isOpen={isReservationOpen}
        onClose={() => setIsReservationOpen(false)}
      />

      {/* Floating Manager / Staff Access Quick Trigger */}
      <div className="fixed bottom-20 left-4 z-40 hidden sm:block">
        <button
          type="button"
          onClick={() => toggleAdminMode(true)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#141416]/90 hover:bg-[#1a1a1e] border border-[#c5a059]/40 text-[#dfbb76] hover:text-white text-xs font-semibold shadow-xl backdrop-blur-md transition-all cursor-pointer group"
          title="Open Hotel & Banquet Management Dashboard"
        >
          <Shield className="w-3.5 h-3.5 text-[#b38938] group-hover:scale-110 transition-transform" />
          <span>Admin Portal</span>
        </button>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AdminProvider>
      <MainAppContent />
    </AdminProvider>
  );
}
