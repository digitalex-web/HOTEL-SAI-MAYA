import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  XCircle,
  HelpCircle,
  ArrowRight,
  MessageSquare
} from 'lucide-react';
import { BANQUET_CALENDAR_DATA } from '../data/restaurantData';
import { BanquetCalendarDate, BanquetDateStatus } from '../types';

interface BanquetCalendarProps {
  onSelectDate: (dateStr: string) => void;
  selectedDateStr?: string;
  onWhatsAppInquiry: (dateStr: string, note?: string) => void;
}

export const BanquetCalendar: React.FC<BanquetCalendarProps> = ({
  onSelectDate,
  selectedDateStr,
  onWhatsAppInquiry
}) => {
  const [activeMonthIdx, setActiveMonthIdx] = useState<number>(0);
  const [filterType, setFilterType] = useState<'all' | 'available' | 'peak' | 'muhurat'>('all');
  const [selectedDay, setSelectedDay] = useState<BanquetCalendarDate | null>(null);

  const monthData = BANQUET_CALENDAR_DATA[activeMonthIdx] || BANQUET_CALENDAR_DATA[0];

  // Default day of week headers (Monday to Sunday)
  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  // Handle month switching
  const handlePrevMonth = () => {
    if (activeMonthIdx > 0) {
      setActiveMonthIdx((prev) => prev - 1);
      setSelectedDay(null);
    }
  };

  const handleNextMonth = () => {
    if (activeMonthIdx < BANQUET_CALENDAR_DATA.length - 1) {
      setActiveMonthIdx((prev) => prev + 1);
      setSelectedDay(null);
    }
  };

  // Status helper styling
  const getStatusBadge = (status: BanquetDateStatus) => {
    switch (status) {
      case 'available':
        return {
          bg: 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300',
          dot: 'bg-emerald-400',
          label: 'Available'
        };
      case 'peak':
        return {
          bg: 'bg-amber-950/70 border-amber-500/40 text-amber-300',
          dot: 'bg-amber-400 animate-pulse',
          label: 'Peak Festival Transit'
        };
      case 'muhurat':
        return {
          bg: 'bg-yellow-950/70 border-[#dfbb76]/60 text-[#f7e7c4]',
          dot: 'bg-[#dfbb76]',
          label: 'Auspicious Muhurat'
        };
      case 'booked':
        return {
          bg: 'bg-rose-950/50 border-rose-500/30 text-rose-300',
          dot: 'bg-rose-400',
          label: 'Reserved'
        };
      default:
        return {
          bg: 'bg-zinc-800 border-zinc-700 text-zinc-300',
          dot: 'bg-zinc-400',
          label: 'Pending'
        };
    }
  };

  // Filter logic
  const shouldHighlightDay = (day: BanquetCalendarDate) => {
    if (filterType === 'all') return true;
    if (filterType === 'available') return day.status === 'available';
    if (filterType === 'peak') return day.status === 'peak';
    if (filterType === 'muhurat') return day.status === 'muhurat';
    return true;
  };

  return (
    <div className="bg-[#121215] border border-white/10 rounded-2xl p-6 sm:p-8 space-y-8 shadow-2xl relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#dfbb76]/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header & Description */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#18181c] border border-[#dfbb76]/30 text-[#e6ca92] text-xs font-mono">
            <CalendarIcon className="w-3.5 h-3.5 text-[#dfbb76]" />
            <span>Upcoming Banquet Events & Availability</span>
          </div>
          <h3 className="font-playfair text-2xl sm:text-3xl text-white font-bold">
            Availability & Peak Social Dates
          </h3>
          <p className="text-xs sm:text-sm text-[#a1a1aa] max-w-xl font-sans-ui">
            Browse upcoming weekend openings, sacred pilgrimage festival rushes, and auspicious wedding muhurats for your family celebrations.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 bg-[#18181c] p-1.5 rounded-xl border border-white/10 self-start md:self-auto">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
              filterType === 'all'
                ? 'bg-[#dfbb76] text-black font-semibold shadow-sm'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            All Dates
          </button>
          <button
            onClick={() => setFilterType('available')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
              filterType === 'available'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Available
          </button>
          <button
            onClick={() => setFilterType('peak')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
              filterType === 'peak'
                ? 'bg-amber-600 text-white font-semibold shadow-sm'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Peak Festive
          </button>
          <button
            onClick={() => setFilterType('muhurat')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
              filterType === 'muhurat'
                ? 'bg-[#c5a059] text-black font-semibold shadow-sm'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Auspicious Muhurat
          </button>
        </div>
      </div>

      {/* Legend Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs font-mono bg-[#16161a] px-4 py-3 rounded-xl border border-white/5">
        <div className="flex flex-wrap items-center gap-4 sm:gap-6">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-emerald-400/20" />
            <span className="text-[#a1a1aa]">Available Slots</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 ring-2 ring-amber-400/20" />
            <span className="text-[#a1a1aa]">Peak Festive / Transit</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#dfbb76] ring-2 ring-[#dfbb76]/30" />
            <span className="text-[#a1a1aa]">Auspicious Muhurat</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400 ring-2 ring-rose-400/20" />
            <span className="text-[#a1a1aa]">Reserved</span>
          </div>
        </div>

        <div className="text-[11px] text-[#71717a] hidden lg:block">
          * Capacities & event packages to be confirmed
        </div>
      </div>

      {/* Calendar Grid Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Interactive Month Grid */}
        <div className="lg:col-span-8 bg-[#161619] border border-white/5 rounded-xl p-5 space-y-4">
          {/* Month Navigation Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="font-playfair text-xl font-bold text-white">
                {monthData.monthName} {monthData.year}
              </span>
              <span className="text-xs font-mono text-[#a1a1aa] px-2.5 py-0.5 rounded bg-white/5 border border-white/10">
                {monthData.days.filter((d) => d.status === 'available').length} Available Days
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrevMonth}
                disabled={activeMonthIdx === 0}
                className="w-8 h-8 rounded-lg bg-[#1e1e24] border border-white/10 flex items-center justify-center text-[#a1a1aa] hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                aria-label="Previous Month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNextMonth}
                disabled={activeMonthIdx === BANQUET_CALENDAR_DATA.length - 1}
                className="w-8 h-8 rounded-lg bg-[#1e1e24] border border-white/10 flex items-center justify-center text-[#a1a1aa] hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                aria-label="Next Month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Day Names Grid */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2 text-center text-xs font-mono text-[#a1a1aa] border-b border-white/5 pb-2">
            {weekDays.map((day) => (
              <div key={day} className="py-1">
                {day}
              </div>
            ))}
          </div>

          {/* Dates Grid */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2">
            {/* Empty slots for start day offset */}
            {Array.from({ length: monthData.startDayOffset }).map((_, i) => (
              <div key={`empty-${i}`} className="h-12 sm:h-14 rounded-lg bg-transparent" />
            ))}

            {/* Actual day cells */}
            {monthData.days.map((day) => {
              const badge = getStatusBadge(day.status);
              const isMatchFilter = shouldHighlightDay(day);
              const isCurrentSelected =
                selectedDay?.date === day.date || selectedDateStr === day.date;

              return (
                <button
                  key={day.date}
                  onClick={() => setSelectedDay(day)}
                  className={`group relative h-12 sm:h-14 rounded-xl p-1 sm:p-1.5 flex flex-col justify-between text-left transition-all border ${
                    isCurrentSelected
                      ? 'border-[#dfbb76] bg-[#221f19] ring-2 ring-[#dfbb76]/30 shadow-lg'
                      : isMatchFilter
                      ? 'border-white/5 bg-[#1a1a1e] hover:border-white/20 hover:bg-[#202026]'
                      : 'border-white/5 bg-[#141417]/50 opacity-40 hover:opacity-80'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span
                      className={`text-xs font-mono font-medium ${
                        isCurrentSelected ? 'text-[#dfbb76]' : 'text-white/90'
                      }`}
                    >
                      {day.dayNumber}
                    </span>
                    <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                  </div>

                  {/* Micro label for events */}
                  {day.label ? (
                    <span
                      className={`text-[9px] font-mono leading-tight truncate block ${
                        day.status === 'muhurat'
                          ? 'text-[#dfbb76]'
                          : day.status === 'peak'
                          ? 'text-amber-300'
                          : day.status === 'booked'
                          ? 'text-rose-400'
                          : 'text-emerald-300'
                      }`}
                    >
                      {day.label}
                    </span>
                  ) : (
                    <span className="text-[9px] font-mono text-zinc-500">
                      {day.status === 'available' ? 'Open' : ''}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Date Detail Card */}
        <div className="lg:col-span-4 bg-[#161619] border border-white/10 rounded-xl p-5 sm:p-6 flex flex-col justify-between space-y-6">
          {selectedDay ? (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="space-y-2 border-b border-white/10 pb-4">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono uppercase tracking-widest text-[#dfbb76]">
                    SELECTED EVENT DATE
                  </span>
                  <span
                    className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono border ${
                      getStatusBadge(selectedDay.status).bg
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        getStatusBadge(selectedDay.status).dot
                      }`}
                    />
                    <span>{getStatusBadge(selectedDay.status).label}</span>
                  </span>
                </div>

                <h4 className="font-playfair text-xl sm:text-2xl text-white font-bold">
                  {new Date(selectedDay.date).toLocaleDateString('en-US', {
                    weekday: 'long',
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </h4>

                {selectedDay.occasionNote && (
                  <p className="text-xs text-[#a1a1aa] font-sans-ui bg-white/[0.02] border border-white/5 p-2.5 rounded-lg">
                    {selectedDay.occasionNote}
                  </p>
                )}
              </div>

              {/* Slot Availability Breakdown */}
              <div className="space-y-3">
                <span className="text-xs font-mono text-[#a1a1aa] block uppercase tracking-wider">
                  Session Slots (Capacity TBC)
                </span>

                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-[#1c1c22] border border-white/5 text-xs font-mono">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#dfbb76]" />
                      <span>Morning / Lunch (10am–3pm)</span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] uppercase font-semibold ${
                        selectedDay.morningSlot === 'open'
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                          : selectedDay.morningSlot === 'fast-filling'
                          ? 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
                          : 'bg-rose-950/80 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {selectedDay.morningSlot === 'open'
                        ? 'Open'
                        : selectedDay.morningSlot === 'fast-filling'
                        ? 'Fast Filling'
                        : 'Reserved'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-lg bg-[#1c1c22] border border-white/5 text-xs font-mono">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-[#dfbb76]" />
                      <span>Evening / Dinner (6pm–11pm)</span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] uppercase font-semibold ${
                        selectedDay.eveningSlot === 'open'
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                          : selectedDay.eveningSlot === 'fast-filling'
                          ? 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
                          : 'bg-rose-950/80 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {selectedDay.eveningSlot === 'open'
                        ? 'Open'
                        : selectedDay.eveningSlot === 'fast-filling'
                        ? 'Fast Filling'
                        : 'Reserved'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={() => {
                    onSelectDate(selectedDay.date);
                  }}
                  className="w-full gold-btn py-2.5 px-4 rounded-xl text-xs font-cinzel font-semibold text-black flex items-center justify-center gap-2 shadow-md"
                >
                  <span>Select Date for Enquiry Form</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() =>
                    onWhatsAppInquiry(
                      selectedDay.date,
                      selectedDay.occasionNote || selectedDay.label
                    )
                  }
                  className="w-full emerald-glass-btn py-2.5 px-4 rounded-xl text-xs font-mono text-[#e6ca92] flex items-center justify-center gap-2 border border-emerald-500/30"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp Availability Check</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center space-y-3 p-4">
              <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[#dfbb76]">
                <CalendarIcon className="w-6 h-6" />
              </div>
              <h5 className="font-playfair text-lg text-white font-semibold">
                Select Any Date on the Calendar
              </h5>
              <p className="text-xs text-[#a1a1aa] leading-relaxed max-w-xs font-sans-ui">
                Click any day in {monthData.monthName} to inspect morning and evening slot availability, pilgrim transit notes, or apply directly to your inquiry form.
              </p>
            </div>
          )}

          {/* Quick Notice */}
          <div className="text-[11px] text-[#71717a] border-t border-white/5 pt-3 font-mono flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 shrink-0 text-[#dfbb76]" />
            <span>Dates marked reserved are exclusive family celebrations.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
