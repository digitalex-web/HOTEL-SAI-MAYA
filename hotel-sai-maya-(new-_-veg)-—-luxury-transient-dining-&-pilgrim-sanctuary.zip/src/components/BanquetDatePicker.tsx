import React, { useState, useRef, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Sparkles,
  Info,
  Clock,
  X
} from 'lucide-react';
import { BANQUET_CALENDAR_DATA } from '../data/restaurantData';
import { BanquetCalendarDate, BanquetDateStatus } from '../types';

interface BanquetDatePickerProps {
  value: string;
  onChange: (dateStr: string, statusInfo?: { status: BanquetDateStatus; label?: string; note?: string }) => void;
  required?: boolean;
}

export const BanquetDatePicker: React.FC<BanquetDatePickerProps> = ({
  value,
  onChange,
  required = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeMonthIdx, setActiveMonthIdx] = useState(0); // 0 = Oct 2026, 1 = Nov 2026
  const containerRef = useRef<HTMLDivElement>(null);

  const monthData = BANQUET_CALENDAR_DATA[activeMonthIdx] || BANQUET_CALENDAR_DATA[0];

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  // Find date record across all months
  const findDateRecord = (dateStr: string): BanquetCalendarDate | undefined => {
    for (const m of BANQUET_CALENDAR_DATA) {
      const found = m.days.find((d) => d.date === dateStr);
      if (found) return found;
    }
    return undefined;
  };

  const selectedRecord = value ? findDateRecord(value) : undefined;

  const getStatusBadge = (status: BanquetDateStatus) => {
    switch (status) {
      case 'available':
        return {
          bg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
          dot: 'bg-emerald-400',
          label: 'Available'
        };
      case 'peak':
        return {
          bg: 'bg-amber-500/10 border-amber-500/30 text-amber-300',
          dot: 'bg-amber-400 animate-pulse',
          label: 'Peak Transit'
        };
      case 'muhurat':
        return {
          bg: 'bg-yellow-500/15 border-[#dfbb76]/40 text-[#f7e7c4]',
          dot: 'bg-[#dfbb76]',
          label: 'Shubh Muhurat'
        };
      case 'booked':
        return {
          bg: 'bg-rose-500/10 border-rose-500/30 text-rose-400',
          dot: 'bg-rose-500',
          label: 'Reserved'
        };
      default:
        return {
          bg: 'bg-zinc-800 border-zinc-700 text-zinc-300',
          dot: 'bg-zinc-400',
          label: 'Available'
        };
    }
  };

  const handleSelectDay = (day: BanquetCalendarDate) => {
    onChange(day.date, {
      status: day.status,
      label: day.label,
      note: day.occasionNote
    });
    setIsOpen(false);
  };

  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div ref={containerRef} className="relative w-full">
      {/* Clickable Input Trigger */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-[#18181c] border border-white/10 hover:border-[#dfbb76]/50 rounded-xl px-4 py-3 text-xs sm:text-sm text-white cursor-pointer transition-all flex items-center justify-between shadow-inner"
      >
        <div className="flex items-center gap-2.5 overflow-hidden">
          <CalendarIcon className="w-4 h-4 text-[#dfbb76] shrink-0" />
          {value ? (
            <span className="font-mono font-medium text-white truncate">
              {value}
            </span>
          ) : (
            <span className="text-white/40 font-mono">Select celebration date...</span>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {selectedRecord && (
            <span
              className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono border ${
                getStatusBadge(selectedRecord.status).bg
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${getStatusBadge(selectedRecord.status).dot}`} />
              <span>{selectedRecord.label || getStatusBadge(selectedRecord.status).label}</span>
            </span>
          )}
          <span className="text-[11px] font-mono text-[#dfbb76] underline ml-1">
            {isOpen ? 'Close' : 'Calendar'}
          </span>
        </div>
      </div>

      {/* Popover Calendar View */}
      {isOpen && (
        <div className="absolute z-50 mt-2 inset-x-0 sm:right-auto sm:w-[380px] bg-[#141418] border border-[#dfbb76]/30 rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-200">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#dfbb76] block">
                BANQUET SCHEDULE
              </span>
              <h4 className="font-playfair text-base font-bold text-white">
                {monthData.monthName} {monthData.year}
              </h4>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setActiveMonthIdx(Math.max(0, activeMonthIdx - 1))}
                disabled={activeMonthIdx === 0}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white disabled:opacity-30 transition-colors"
                title="Previous Month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setActiveMonthIdx(Math.min(BANQUET_CALENDAR_DATA.length - 1, activeMonthIdx + 1))}
                disabled={activeMonthIdx === BANQUET_CALENDAR_DATA.length - 1}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white disabled:opacity-30 transition-colors"
                title="Next Month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#a1a1aa] hover:text-white transition-colors ml-1"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-1 pt-3 pb-1 text-center font-mono text-[10px] text-[#a1a1aa] uppercase">
            {weekDays.map((wd) => (
              <div key={wd} className="py-1">
                {wd}
              </div>
            ))}
          </div>

          {/* Calendar Day Grid */}
          <div className="grid grid-cols-7 gap-1 pt-1">
            {/* Empty slots for month start offset */}
            {Array.from({ length: monthData.startDayOffset }).map((_, i) => (
              <div key={`empty-${i}`} className="h-9 rounded-lg opacity-10 bg-white/5" />
            ))}

            {/* Days */}
            {monthData.days.map((day) => {
              const isSelected = value === day.date;
              const isBooked = day.status === 'booked';
              const isMuhurat = day.status === 'muhurat';
              const isPeak = day.status === 'peak';

              return (
                <button
                  key={day.date}
                  type="button"
                  onClick={() => handleSelectDay(day)}
                  className={`relative h-9 rounded-lg flex flex-col items-center justify-center font-mono text-xs transition-all ${
                    isSelected
                      ? 'bg-[#dfbb76] text-black font-bold ring-2 ring-[#dfbb76] ring-offset-1 ring-offset-[#141418] shadow-lg'
                      : isBooked
                      ? 'bg-rose-950/40 text-rose-300/80 border border-rose-500/20 hover:border-rose-500/40'
                      : isMuhurat
                      ? 'bg-yellow-950/50 text-[#f7e7c4] border border-[#dfbb76]/30 hover:border-[#dfbb76]'
                      : isPeak
                      ? 'bg-amber-950/30 text-amber-300/90 border border-amber-500/20 hover:border-amber-500/40'
                      : 'bg-[#1a1a20] text-white hover:bg-white/10 border border-white/5'
                  }`}
                  title={`${day.date} - ${day.label || day.status}${day.occasionNote ? ` (${day.occasionNote})` : ''}`}
                >
                  <span className="text-[11px] leading-tight">{day.dayNumber}</span>
                  <span
                    className={`w-1.5 h-1.5 rounded-full mt-0.5 ${
                      isSelected
                        ? 'bg-black'
                        : isBooked
                        ? 'bg-rose-400'
                        : isMuhurat
                        ? 'bg-[#dfbb76]'
                        : isPeak
                        ? 'bg-amber-400'
                        : 'bg-emerald-400'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Color-Coded Legend */}
          <div className="pt-3 mt-3 border-t border-white/10 grid grid-cols-2 gap-2 text-[10px] font-mono">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Available</span>
            </div>
            <div className="flex items-center gap-1.5 text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-400" />
              <span>Booked / Reserved</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#dfbb76]">
              <span className="w-2 h-2 rounded-full bg-[#dfbb76]" />
              <span>Shubh Muhurat</span>
            </div>
            <div className="flex items-center gap-1.5 text-amber-400">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>Peak Transit / Fast</span>
            </div>
          </div>

          {/* Selected Date Preview Note */}
          {selectedRecord && (
            <div className="mt-3 p-2.5 rounded-lg bg-white/[0.03] border border-white/10 text-[11px] font-mono space-y-1">
              <div className="flex items-center justify-between text-white">
                <span className="font-semibold">{selectedRecord.date}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    getStatusBadge(selectedRecord.status).bg
                  }`}
                >
                  {selectedRecord.label || getStatusBadge(selectedRecord.status).label}
                </span>
              </div>
              {selectedRecord.occasionNote ? (
                <p className="text-[#a1a1aa] text-[10px] leading-relaxed">
                  {selectedRecord.occasionNote}
                </p>
              ) : (
                <p className="text-emerald-400 text-[10px]">
                  ✓ Good availability for morning and evening banquet celebrations.
                </p>
              )}
              {selectedRecord.status === 'booked' && (
                <p className="text-rose-300 text-[10px] pt-1">
                  ⚠️ Note: Date has prior bookings. Contact manager to check for alternate hours or standby slots.
                </p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
