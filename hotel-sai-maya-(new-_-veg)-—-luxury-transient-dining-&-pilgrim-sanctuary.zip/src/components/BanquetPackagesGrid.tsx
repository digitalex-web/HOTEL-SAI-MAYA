import React, { useState } from 'react';
import {
  Sparkles,
  Check,
  X,
  ChevronRight,
  MessageSquare,
  Crown,
  ShieldCheck,
  Star,
  Clock,
  Users,
  Utensils,
  Layers,
  ArrowRight,
  Building2
} from 'lucide-react';
import { RESTAURANT_METADATA, triggerWhatsAppBanquetInquiry } from '../data/restaurantData';

export interface BanquetPackageTier {
  id: string;
  name: string;
  tier: 'Silver' | 'Gold' | 'Platinum' | 'Pilgrim';
  tagline: string;
  pricePerGuest: number;
  guestCapacity: string;
  hallDuration: string;
  badge?: string;
  isPopular?: boolean;
  highlightColor: string;
  borderColor: string;
  features: string[];
  inclusions: {
    welcomeDrink: string;
    starters: string;
    mainCourse: string;
    breads: string;
    riceDal: string;
    sweets: string;
    liveCounters: string;
    jainDietary: boolean;
    hallDuration: string;
    stageDecor: string;
    soundSystem: string;
    greenRoom: string;
    banquetStaff: string;
    valetParking: string;
    wifiStream: boolean;
  };
}

const BANQUET_TIERS: BanquetPackageTier[] = [
  {
    id: 'silver-tier',
    name: 'Silver Celebration',
    tier: 'Silver',
    tagline: 'Refined simplicity for intimate family birthdays, baby showers, and anniversary lunches.',
    pricePerGuest: 450,
    guestCapacity: '30 – 80 Guests',
    hallDuration: '4 Hours AC Hall',
    badge: 'Essential Tier',
    isPopular: false,
    highlightColor: 'from-slate-400 to-slate-200',
    borderColor: 'border-slate-500/30',
    features: [
      '4 Hours climate-controlled AC hall privileges',
      'Welcome Drink: Chilled Badam Thandai or Sol Kadhi',
      'Satvik Buffet: 2 Chef Choice Sabzis, Dal Tadka, Jeera Rice',
      'Assorted Tandoori Rotis, Naans & Fresh Salad',
      '1 Heritage Indian Sweet (Hot Gulab Jamun / Shrikhand)',
      'Classic banquet seating with fresh linen and table covers',
      'Standard sound system with 1 wireless microphone',
      'Dedicated private parking for all guest vehicles'
    ],
    inclusions: {
      welcomeDrink: '1 Choice (Badam Thandai or Sol Kadhi)',
      starters: '1 Starter (Veg Crispy / Harabhara)',
      mainCourse: '2 Premium Seasonal Veg Gravies',
      breads: 'Tandoori Roti & Naan Basket',
      riceDal: 'Jeera Rice + Yellow Dal Tadka',
      sweets: '1 Traditional Sweet (Gulab Jamun / Shrikhand)',
      liveCounters: 'Salad & Raita Bar',
      jainDietary: true,
      hallDuration: '4 Hours',
      stageDecor: 'Standard Floral Backdrop Stand',
      soundSystem: 'Standard PA + 1 Cordless Mic',
      greenRoom: 'Restroom Powder Area',
      banquetStaff: 'Buffet Attendants',
      valetParking: 'Self Parking (80+ bays)',
      wifiStream: false
    }
  },
  {
    id: 'gold-tier',
    name: 'Gold Royal Muhurat',
    tier: 'Gold',
    tagline: 'Our signature festive package for engagement ceremonies, jubilee milestones, and sacred pujas.',
    pricePerGuest: 750,
    guestCapacity: '60 – 180 Guests',
    hallDuration: '6 Hours AC Hall',
    badge: '★ Most Popular Choice',
    isPopular: true,
    highlightColor: 'from-[#dfbb76] to-[#f7e7c4]',
    borderColor: 'border-[#dfbb76]/60',
    features: [
      '6 Hours continuous celebration hall access',
      'Double Welcome Drink (Badam Thandai & Kokum Cooler)',
      '2 Hot Live Starters: Tandoori Paneer Tikka & Hara Bhara Kebab',
      'Imperial Satvik Feast: 3 Royal Sabzis, Paneer Pasanda, Dal Makhani',
      'Fragrant Dum Biryani, Steamed Rice, Traditional Varan-Bhaat',
      '2 Royal Sweets: Kesari Basundi & Warm Moong Dal Halwa',
      'Fresh floral entrance toran & ceremonial elevated stage dais',
      'Private air-conditioned Green Room for host/bride',
      'Dedicated Banquet Captain & uniformed table stewards',
      'Prioritized valet parking with executive coach escort'
    ],
    inclusions: {
      welcomeDrink: '2 Signature Drinks (Thandai & Kokum)',
      starters: '2 Hot Starters (Paneer Tikka + Veg Seekh)',
      mainCourse: '3 Royal Sabzis (Paneer, Seasonal, Kaju Curry)',
      breads: 'Butter Naan, Laccha Paratha & Missi Roti',
      riceDal: 'Dum Biryani, Steamed Rice & Dal Makhani',
      sweets: '2 Royal Sweets (Kesari Basundi & Moong Halwa)',
      liveCounters: 'Live Chaat or Dosa Station (Customizable)',
      jainDietary: true,
      hallDuration: '6 Hours',
      stageDecor: 'Floral Stage Arch + Ambient Lighting',
      soundSystem: 'Enhanced Sound + 2 Wireless Mics + Audio Jack',
      greenRoom: '1 Private Air-Conditioned Green Room',
      banquetStaff: 'Dedicated Captain & Uniformed Stewards',
      valetParking: 'Valet Assistance + Coach Ingress',
      wifiStream: true
    }
  },
  {
    id: 'platinum-tier',
    name: 'Platinum Grand Imperial',
    tier: 'Platinum',
    tagline: 'The ultimate luxury experience for wedding receptions, grand jubilees, and VIP pilgrimage celebrations.',
    pricePerGuest: 1150,
    guestCapacity: '100 – 300 Guests',
    hallDuration: 'Full Day Access (10 Hrs)',
    badge: 'Luxury All-Inclusive',
    isPopular: false,
    highlightColor: 'from-amber-200 via-[#dfbb76] to-yellow-100',
    borderColor: 'border-yellow-400/40',
    features: [
      'Full Day (up to 10 Hours) exclusive banquet privileges',
      'Artisanal Mocktail Bar: 3 Coolers & Fresh Mint Sparklers',
      '4 Hot Live Starters: Malai Paneer, Crispy Corn, Kothimbir Vadi, Seekh',
      'Royal 5-Course Multi-Cuisine Feast with Live Jowar Bhakri & Gir Ghee Station',
      '3 Artisanal Sweets + Live Hot Jalebi & Rabdi Counter',
      'Designer ceremonial stage backdrop with dynamic warm LED mood wash',
      'High-fidelity sound system with sound technician and 4 wireless mics',
      '2 Private Air-Conditioned VIP Suites / Bridal Dressing Lounges',
      'Dedicated Banquet Floor Manager & full butler hospitality brigade',
      'VIP Valet fleet escort & high-speed optical Wi-Fi for live streaming'
    ],
    inclusions: {
      welcomeDrink: '3 Signature Coolers & Mocktails Bar',
      starters: '4 Live Starters (Tandoori Malai, Crispy Corn, etc.)',
      mainCourse: '4 Multi-Cuisine & Regional Royal Dishes',
      breads: 'Live Tandoor Counter (Naans, Kulchas, Bhakris)',
      riceDal: 'Hyderabadi Veg Dum Biryani, Dal Maharani & Curd Rice',
      sweets: '3 Royal Sweets + Live Jalebi-Rabdi Station',
      liveCounters: 'Live Bhakri Counter + Live Dessert Station',
      jainDietary: true,
      hallDuration: 'Full Day (Up to 10 Hours)',
      stageDecor: 'Custom Designer Floral Mandap / Backdrop',
      soundSystem: 'Acoustic Sound Array + Tech + 4 Mics',
      greenRoom: '2 Executive VIP / Bridal Suites',
      banquetStaff: 'Banquet Floor Manager & Full Brigade',
      valetParking: 'Full Valet Service + Reserved Coach Bay',
      wifiStream: true
    }
  }
];

interface BanquetPackagesGridProps {
  onSelectPackage?: (tierName: string) => void;
}

export const BanquetPackagesGrid: React.FC<BanquetPackagesGridProps> = ({ onSelectPackage }) => {
  const [activeTab, setActiveTab] = useState<'cards' | 'matrix'>('cards');
  const [selectedTierId, setSelectedTierId] = useState<string>('gold-tier');

  const handlePackageClick = (tier: BanquetPackageTier) => {
    setSelectedTierId(tier.id);
    if (onSelectPackage) {
      onSelectPackage(tier.name);
    }
    const form = document.getElementById('banquet-inquiry-form');
    if (form) {
      form.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleWhatsAppQuote = (tier: BanquetPackageTier) => {
    triggerWhatsAppBanquetInquiry({
      additionalRequirements: `Inquiring for '${tier.name}' (${tier.tier} Tier @ ₹${tier.pricePerGuest}/guest). Please share detailed menu options and availability.`
    });
  };

  return (
    <div className="space-y-8">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#18181c] border border-[#dfbb76]/30 text-[#dfbb76] text-xs font-mono uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" />
            <span>PRICING & PACKAGE TIERS</span>
          </div>
          <h3 className="font-playfair text-2xl sm:text-3xl md:text-4xl text-white font-bold">
            Curated Celebration Packages
          </h3>
          <p className="text-xs sm:text-sm text-[#a1a1aa] max-w-xl font-sans-ui">
            Transparent pure-vegetarian packages tailored for intimate gatherings, sacred milestone ceremonies, and grand festive feasts.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-[#141418] border border-white/10 rounded-xl shrink-0 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('cards')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all ${
              activeTab === 'cards'
                ? 'bg-[#dfbb76] text-black font-semibold shadow-md'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Tier Cards View
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('matrix')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all ${
              activeTab === 'matrix'
                ? 'bg-[#dfbb76] text-black font-semibold shadow-md'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Compare Inclusions
          </button>
        </div>
      </div>

      {/* 1. Tiers Grid View */}
      {activeTab === 'cards' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          {BANQUET_TIERS.map((tier) => {
            const isGold = tier.isPopular;
            return (
              <div
                key={tier.id}
                className={`relative rounded-2xl bg-[#121216] border flex flex-col justify-between transition-all duration-300 hover:shadow-2xl ${
                  isGold
                    ? 'border-[#dfbb76] ring-1 ring-[#dfbb76]/50 shadow-[#dfbb76]/10 md:-translate-y-2'
                    : 'border-white/10 hover:border-white/20'
                }`}
              >
                {/* Popular Ribbon */}
                {isGold && (
                  <div className="absolute -top-3.5 inset-x-0 flex justify-center">
                    <span className="px-4 py-1 rounded-full bg-gradient-to-r from-[#c5a059] to-[#dfbb76] text-black text-[11px] font-mono font-bold tracking-wider uppercase shadow-md flex items-center gap-1.5">
                      <Crown className="w-3.5 h-3.5" />
                      <span>Most Popular Tier</span>
                    </span>
                  </div>
                )}

                <div className="p-6 sm:p-7 space-y-5">
                  {/* Top Badge & Tier Name */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-widest text-[#a1a1aa]">
                        {tier.tier} PACKAGE
                      </span>
                      <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-[#e6ca92]">
                        {tier.hallDuration}
                      </span>
                    </div>

                    <h4 className="font-playfair text-2xl text-white font-bold">
                      {tier.name}
                    </h4>

                    <p className="text-xs text-[#a1a1aa] leading-relaxed font-sans-ui min-h-[38px]">
                      {tier.tagline}
                    </p>
                  </div>

                  {/* Pricing Display */}
                  <div className="py-3 px-4 rounded-xl bg-white/[0.02] border border-white/5 flex items-baseline justify-between">
                    <div>
                      <span className="text-xs font-mono text-[#a1a1aa] block">Starting from</span>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl sm:text-3xl font-bold font-mono text-white">
                          ₹{tier.pricePerGuest}
                        </span>
                        <span className="text-xs font-mono text-[#a1a1aa]">/ guest</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-mono text-[#dfbb76] block">Capacity</span>
                      <span className="text-xs font-mono text-white font-medium">{tier.guestCapacity}</span>
                    </div>
                  </div>

                  {/* Key Features List */}
                  <div className="space-y-2.5 pt-2">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#dfbb76] block">
                      Package Inclusions:
                    </span>
                    <ul className="space-y-2 text-xs text-[#d1d1d6] font-sans-ui">
                      {tier.features.map((feat, fIdx) => (
                        <li key={fIdx} className="flex items-start gap-2.5 leading-snug">
                          <Check className="w-4 h-4 text-[#dfbb76] shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="p-6 sm:p-7 pt-0 space-y-2.5 border-t border-white/5 mt-4">
                  <button
                    type="button"
                    onClick={() => handlePackageClick(tier)}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-cinzel font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-2 ${
                      isGold
                        ? 'gold-btn text-black shadow-lg hover:shadow-[#dfbb76]/30'
                        : 'bg-white/10 hover:bg-white/15 text-white border border-white/10'
                    }`}
                  >
                    <span>Select {tier.tier} Tier</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleWhatsAppQuote(tier)}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-mono text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/20 border border-emerald-500/20 flex items-center justify-center gap-2 transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp Quotation</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 2. Inclusions Comparison Matrix View */}
      {activeTab === 'matrix' && (
        <div className="bg-[#121216] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
          <div className="p-5 sm:p-6 bg-[#16161c] border-b border-white/10 flex items-center justify-between">
            <div>
              <h4 className="font-playfair text-lg sm:text-xl font-bold text-white">
                Detailed Inclusions Comparison
              </h4>
              <p className="text-xs text-[#a1a1aa] font-mono">
                Compare venue duration, catering courses, decor, and operational amenities side-by-side
              </p>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full hidden sm:inline-block">
              100% Satvik & Jain Certified
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-white">
              <thead>
                <tr className="border-b border-white/10 bg-[#0e0e11] text-[#a1a1aa] font-mono text-[11px] uppercase tracking-wider">
                  <th className="py-3.5 px-4 sm:px-6 w-1/4">Inclusion Feature</th>
                  <th className="py-3.5 px-4 text-center">Silver Tier</th>
                  <th className="py-3.5 px-4 text-center bg-[#dfbb76]/5 text-[#dfbb76]">
                    Gold Tier (Popular)
                  </th>
                  <th className="py-3.5 px-4 text-center">Platinum Tier</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-sans-ui">
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 font-mono text-[#dfbb76] font-semibold">
                    Indicative Price
                  </td>
                  <td className="py-3 px-4 text-center font-mono font-bold text-white">₹450 / guest</td>
                  <td className="py-3 px-4 text-center font-mono font-bold text-[#dfbb76] bg-[#dfbb76]/5">
                    ₹750 / guest
                  </td>
                  <td className="py-3 px-4 text-center font-mono font-bold text-amber-200">
                    ₹1,150 / guest
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Hall AC Access Duration</td>
                  <td className="py-3 px-4 text-center">4 Hours</td>
                  <td className="py-3 px-4 text-center bg-[#dfbb76]/5 font-semibold text-white">
                    6 Hours
                  </td>
                  <td className="py-3 px-4 text-center font-semibold text-amber-300">
                    Full Day (Up to 10 Hrs)
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Ideal Guest Range</td>
                  <td className="py-3 px-4 text-center font-mono">30 – 80</td>
                  <td className="py-3 px-4 text-center font-mono bg-[#dfbb76]/5 text-white">60 – 180</td>
                  <td className="py-3 px-4 text-center font-mono">100 – 300+</td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Welcome Beverages</td>
                  <td className="py-3 px-4 text-center text-[#d1d1d6]">1 Choice (Thandai / Sol Kadhi)</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    2 Signature Drinks (Thandai & Kokum)
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    3 Mocktails & Fresh Sparklers Bar
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Hot Live Appetizers</td>
                  <td className="py-3 px-4 text-center text-[#d1d1d6]">1 Starter</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    2 Starters (Paneer Tikka + Kebab)
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    4 Live-Counter Hot Starters
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Main Course Curries</td>
                  <td className="py-3 px-4 text-center text-[#d1d1d6]">2 Sabzis + Dal Tadka</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    3 Royal Sabzis + Dal Makhani
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    4 Multi-Cuisine Curries + Royal Dal
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Live Cooking Stations</td>
                  <td className="py-3 px-4 text-center text-[#a1a1aa]">—</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    Live Chaat or Dosa Station
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    Live Jowar Bhakri & Jalebi Counters
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Traditional Sweets</td>
                  <td className="py-3 px-4 text-center text-[#d1d1d6]">1 Sweet (Gulab Jamun)</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    2 Royal Sweets (Basundi & Halwa)
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    3 Sweets + Hot Jalebi & Rabdi
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Jain Purity Separation</td>
                  <td className="py-3 px-4 text-center text-emerald-400">
                    <Check className="w-4 h-4 mx-auto" />
                  </td>
                  <td className="py-3 px-4 text-center text-emerald-400 bg-[#dfbb76]/5">
                    <Check className="w-4 h-4 mx-auto" />
                  </td>
                  <td className="py-3 px-4 text-center text-emerald-400">
                    <Check className="w-4 h-4 mx-auto" />
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Stage & Floral Setup</td>
                  <td className="py-3 px-4 text-center text-[#d1d1d6]">Standard Backdrop</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    Floral Toran & Ceremonial Dais
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    Designer Stage Arch + LED Uplighting
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Sound System & Mics</td>
                  <td className="py-3 px-4 text-center text-[#d1d1d6]">Basic PA + 1 Mic</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    Enhanced PA + 2 Wireless Mics
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    Acoustic Array + Tech + 4 Mics
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">VIP / Bridal Green Room</td>
                  <td className="py-3 px-4 text-center text-[#a1a1aa]">—</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    1 Private AC Green Room
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    2 Executive VIP Suites
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Dedicated Event Captain</td>
                  <td className="py-3 px-4 text-center text-[#a1a1aa]">—</td>
                  <td className="py-3 px-4 text-center text-emerald-400 bg-[#dfbb76]/5">
                    <Check className="w-4 h-4 mx-auto" />
                  </td>
                  <td className="py-3 px-4 text-center text-emerald-400">
                    <Check className="w-4 h-4 mx-auto" />
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Valet & Coach Parking</td>
                  <td className="py-3 px-4 text-center text-[#d1d1d6]">Self Parking (80+ bays)</td>
                  <td className="py-3 px-4 text-center text-white bg-[#dfbb76]/5">
                    Valet Assistance + Coach Bay
                  </td>
                  <td className="py-3 px-4 text-center text-white font-medium">
                    Full Valet Fleet Escort
                  </td>
                </tr>

                <tr className="hover:bg-white/[0.02]">
                  <td className="py-3 px-4 sm:px-6 text-[#a1a1aa]">Live Stream Wi-Fi</td>
                  <td className="py-3 px-4 text-center text-[#a1a1aa]">
                    <X className="w-4 h-4 mx-auto text-zinc-600" />
                  </td>
                  <td className="py-3 px-4 text-center text-emerald-400 bg-[#dfbb76]/5">
                    <Check className="w-4 h-4 mx-auto" />
                  </td>
                  <td className="py-3 px-4 text-center text-emerald-400">
                    <Check className="w-4 h-4 mx-auto" />
                  </td>
                </tr>

                {/* Bottom Action Row */}
                <tr className="bg-[#16161c]">
                  <td className="py-4 px-4 sm:px-6 font-mono text-xs text-white">Action</td>
                  <td className="py-4 px-4 text-center">
                    <button
                      type="button"
                      onClick={() => handlePackageClick(BANQUET_TIERS[0])}
                      className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-mono text-xs"
                    >
                      Choose Silver
                    </button>
                  </td>
                  <td className="py-4 px-4 text-center bg-[#dfbb76]/10">
                    <button
                      type="button"
                      onClick={() => handlePackageClick(BANQUET_TIERS[1])}
                      className="px-5 py-2 rounded-lg bg-[#dfbb76] hover:bg-[#c5a059] text-black font-cinzel font-bold text-xs"
                    >
                      Choose Gold
                    </button>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <button
                      type="button"
                      onClick={() => handlePackageClick(BANQUET_TIERS[2])}
                      className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-mono text-xs"
                    >
                      Choose Platinum
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
