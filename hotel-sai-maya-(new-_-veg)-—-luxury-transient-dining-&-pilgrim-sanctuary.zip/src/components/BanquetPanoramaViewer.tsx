import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  RotateCcw,
  Play,
  Pause,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Compass,
  Sparkles,
  MapPin,
  X,
  Info,
  ChevronRight,
  Eye,
  Camera,
  Layers
} from 'lucide-react';

interface PanoramaScene {
  id: string;
  name: string;
  subtitle: string;
  imageUrl: string;
  initialYaw: number;
  hotspots: {
    id: string;
    yaw: number; // in degrees (0 - 360)
    pitch: number; // in degrees (-45 to 45)
    title: string;
    category: string;
    description: string;
    badge: string;
    imageUrl?: string;
  }[];
}

const PANORAMA_SCENES: PanoramaScene[] = [
  {
    id: 'grand-hall',
    name: 'Grand Celebration Hall',
    subtitle: 'Central aisle perspective with warm ambient cove lighting and banquet clusters',
    imageUrl: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=2400&q=85',
    initialYaw: 180,
    hotspots: [
      {
        id: 'hs-stage',
        yaw: 185,
        pitch: 2,
        title: 'Elevated Ceremonial Stage',
        category: 'Mandap & Dais',
        description: '24ft wide carpeted ceremonial dais equipped with warm architectural focus spotlamps, brass auspicious urlis, and dedicated floral backdrop mounts.',
        badge: 'Stage Focus',
        imageUrl: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'hs-seating',
        yaw: 280,
        pitch: -12,
        title: 'Cluster Seating & Linen',
        category: 'Guest Seating',
        description: 'Heavy-gauge banquet chairs with golden champagne chair caps, velvet table drapes, and wide 5ft spacing allowing unobstructed mobility for elders.',
        badge: 'Comfortable Linen',
        imageUrl: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'hs-ac',
        yaw: 90,
        pitch: 22,
        title: 'Daikin Silent Climate Control',
        category: 'HVAC Infrastructure',
        description: 'High-tonnage centralized ductless air-conditioning maintaining a constant 22°C temperature even during peak summer highway afternoons.',
        badge: 'Climate Comfort'
      },
      {
        id: 'hs-entrance',
        yaw: 10,
        pitch: -5,
        title: 'Grand Highway Ingress',
        category: 'Reception & Foyer',
        description: 'Wide double-leaf entrance connected directly to our step-free ramp, private parking lot, and sanitized luxury powder suites.',
        badge: 'Wheelchair Friendly'
      }
    ]
  },
  {
    id: 'stage-view',
    name: 'Ceremonial Stage Vantage',
    subtitle: 'Perspective from the stage looking over guests, ceremonial lamps & flowers',
    imageUrl: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=2400&q=85',
    initialYaw: 0,
    hotspots: [
      {
        id: 'hs-guest-hall',
        yaw: 10,
        pitch: -5,
        title: 'Panoramic Guest Vista',
        category: 'Hall View',
        description: 'Clear, unobstructed line of sight across all 150+ seats. Zero pillar obstruction in the central celebration pavilion.',
        badge: 'Pillarless Hall'
      },
      {
        id: 'hs-audio',
        yaw: 75,
        pitch: -8,
        title: 'High-Clarity PA Sound System',
        category: 'Audio Visual',
        description: 'Surround studio-grade speakers tuned to prevent echo during sacred Vedic chantings, wedding vows, or speech addresses.',
        badge: 'Studio Audio'
      }
    ]
  },
  {
    id: 'buffet-corridor',
    name: 'Satvik Dining & Buffet Corridor',
    subtitle: 'Dedicated catering pavilion with separate Jain cookware stations',
    imageUrl: 'https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=2400&q=85',
    initialYaw: 90,
    hotspots: [
      {
        id: 'hs-buffet-counter',
        yaw: 85,
        pitch: -2,
        title: 'Pure-Veg Multi-Course Buffet',
        category: 'Satvik Dining',
        description: 'Double-sided copper and brass chafing stations with infrared food warmers keeping thali curries, rotis, and dal piping hot.',
        badge: '100% Pure Veg',
        imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'hs-jain-kitchen',
        yaw: 160,
        pitch: 4,
        title: 'Dedicated Jain Preparation Counter',
        category: 'Dietary Strictness',
        description: 'Strict adherence to Jain culinary vows: absolutely no root vegetables, separate utensils, and prepared with divine reverence.',
        badge: 'Jain Certified'
      }
    ]
  }
];

export const BanquetPanoramaViewer: React.FC = () => {
  const [activeSceneId, setActiveSceneId] = useState<string>('grand-hall');
  const [yaw, setYaw] = useState<number>(180);
  const [pitch, setPitch] = useState<number>(0);
  const [zoom, setZoom] = useState<number>(1);
  const [isAutoRotating, setIsAutoRotating] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [activeHotspot, setActiveHotspot] = useState<PanoramaScene['hotspots'][0] | null>(null);
  const [imageLoaded, setImageLoaded] = useState<boolean>(false);
  const [hasInteracted, setHasInteracted] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const isDraggingRef = useRef<boolean>(false);
  const lastMousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const velocityRef = useRef<{ yaw: number; pitch: number }>({ yaw: 0, pitch: 0 });
  const imageRef = useRef<HTMLImageElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  const activeScene = PANORAMA_SCENES.find((s) => s.id === activeSceneId) || PANORAMA_SCENES[0];

  // Preload scene image
  useEffect(() => {
    setImageLoaded(false);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = activeScene.imageUrl;
    img.onload = () => {
      imageRef.current = img;
      setImageLoaded(true);
      setYaw(activeScene.initialYaw);
      setPitch(0);
    };
  }, [activeSceneId, activeScene.imageUrl, activeScene.initialYaw]);

  // Handle Fullscreen Toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Main Canvas Rendering Loop
  const renderFrame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imageRef.current || !imageLoaded) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#0c0c0e';
    ctx.fillRect(0, 0, width, height);

    // Apply auto-rotation if idle
    if (isAutoRotating && !isDraggingRef.current) {
      setYaw((prev) => (prev + 0.12) % 360);
    }

    // Apply momentum inertia
    if (!isDraggingRef.current && (Math.abs(velocityRef.current.yaw) > 0.01 || Math.abs(velocityRef.current.pitch) > 0.01)) {
      setYaw((prev) => (prev + velocityRef.current.yaw + 360) % 360);
      setPitch((prev) => Math.max(-35, Math.min(35, prev + velocityRef.current.pitch)));
      velocityRef.current.yaw *= 0.92;
      velocityRef.current.pitch *= 0.92;
    }

    const img = imageRef.current;

    // Cylindrical / Equirectangular projection wrap
    // We map 360 degrees of Yaw across the image width
    const normalizedYaw = (yaw % 360 + 360) % 360;
    const sourceX = (normalizedYaw / 360) * img.width;
    const pitchOffset = (pitch / 90) * (height * 0.4);

    // Visible field of view width
    const fovAngle = 90 / zoom; // horizontal FOV in degrees
    const sourceWidth = (fovAngle / 360) * img.width;
    const sourceHeight = img.height;

    // Draw wrapped panorama slice
    // Handle wrap-around when sourceX + sourceWidth exceeds img.width
    const remainingWidth = img.width - sourceX;

    if (remainingWidth >= sourceWidth) {
      ctx.drawImage(
        img,
        sourceX,
        0,
        sourceWidth,
        sourceHeight,
        0,
        pitchOffset,
        width,
        height
      );
    } else {
      // Split into two draws for seamless wrap
      const part1SourceWidth = remainingWidth;
      const part1DestWidth = (part1SourceWidth / sourceWidth) * width;

      const part2SourceWidth = sourceWidth - part1SourceWidth;
      const part2DestWidth = width - part1DestWidth;

      ctx.drawImage(
        img,
        sourceX,
        0,
        part1SourceWidth,
        sourceHeight,
        0,
        pitchOffset,
        part1DestWidth,
        height
      );

      ctx.drawImage(
        img,
        0,
        0,
        part2SourceWidth,
        sourceHeight,
        part1DestWidth,
        pitchOffset,
        part2DestWidth,
        height
      );
    }

    // Ambient Lighting Vignette overlay
    const gradient = ctx.createRadialGradient(
      width / 2,
      height / 2,
      width * 0.25,
      width / 2,
      height / 2,
      width * 0.65
    );
    gradient.addColorStop(0, 'rgba(0,0,0,0)');
    gradient.addColorStop(1, 'rgba(8,8,10,0.55)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Draw Hotspot Markers directly on Canvas
    activeScene.hotspots.forEach((hs) => {
      // Calculate angle difference between camera Yaw and Hotspot Yaw
      let angleDiff = (hs.yaw - normalizedYaw + 540) % 360 - 180;

      // Only draw if within current Field of View
      if (Math.abs(angleDiff) < fovAngle / 2) {
        const screenX = width / 2 + (angleDiff / (fovAngle / 2)) * (width / 2);
        const screenY = height / 2 + pitchOffset - (hs.pitch / 45) * (height / 2);

        // Draw Gold Hotspot Glow Ring
        ctx.save();
        ctx.beginPath();
        ctx.arc(screenX, screenY, 14, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(223, 187, 118, 0.25)';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(screenX, screenY, 8, 0, Math.PI * 2);
        ctx.fillStyle = '#dfbb76';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.fill();
        ctx.stroke();

        // Hotspot Label Pin
        ctx.font = 'bold 11px monospace';
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = 'rgba(0,0,0,0.9)';
        ctx.shadowBlur = 4;
        ctx.fillText(hs.title, screenX + 16, screenY + 4);
        ctx.restore();
      }
    });

    animFrameIdRef.current = requestAnimationFrame(renderFrame);
  }, [yaw, pitch, zoom, isAutoRotating, imageLoaded, activeScene]);

  // Start & Stop Animation Frame
  useEffect(() => {
    animFrameIdRef.current = requestAnimationFrame(renderFrame);
    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    };
  }, [renderFrame]);

  // Resize canvas to match display size
  useEffect(() => {
    const handleResize = () => {
      if (!canvasRef.current || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      canvasRef.current.width = rect.width;
      canvasRef.current.height = rect.height;
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Mouse & Touch Controls
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
    velocityRef.current = { yaw: 0, pitch: 0 };
    setHasInteracted(true);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastMousePosRef.current.x;
    const dy = e.clientY - lastMousePosRef.current.y;

    const sensitivity = 0.22 / zoom;
    const yawDelta = -dx * sensitivity;
    const pitchDelta = dy * sensitivity;

    setYaw((prev) => (prev + yawDelta + 360) % 360);
    setPitch((prev) => Math.max(-35, Math.min(35, prev + pitchDelta)));

    velocityRef.current = { yaw: yawDelta * 0.4, pitch: pitchDelta * 0.4 };
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Touch Support
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      isDraggingRef.current = true;
      lastMousePosRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      velocityRef.current = { yaw: 0, pitch: 0 };
      setHasInteracted(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDraggingRef.current || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - lastMousePosRef.current.x;
    const dy = e.touches[0].clientY - lastMousePosRef.current.y;

    const sensitivity = 0.25 / zoom;
    const yawDelta = -dx * sensitivity;
    const pitchDelta = dy * sensitivity;

    setYaw((prev) => (prev + yawDelta + 360) % 360);
    setPitch((prev) => Math.max(-35, Math.min(35, prev + pitchDelta)));

    velocityRef.current = { yaw: yawDelta * 0.4, pitch: pitchDelta * 0.4 };
    lastMousePosRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  const handleTouchEnd = () => {
    isDraggingRef.current = false;
  };

  // Hotspot Click Detection
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const width = canvasRef.current.width;
    const height = canvasRef.current.height;
    const fovAngle = 90 / zoom;
    const normalizedYaw = (yaw % 360 + 360) % 360;
    const pitchOffset = (pitch / 90) * (height * 0.4);

    // Check if clicked near any hotspot
    for (const hs of activeScene.hotspots) {
      const angleDiff = (hs.yaw - normalizedYaw + 540) % 360 - 180;
      if (Math.abs(angleDiff) < fovAngle / 2) {
        const screenX = width / 2 + (angleDiff / (fovAngle / 2)) * (width / 2);
        const screenY = height / 2 + pitchOffset - (hs.pitch / 45) * (height / 2);

        const dist = Math.hypot(clickX - screenX, clickY - screenY);
        if (dist < 28) {
          setActiveHotspot(hs);
          return;
        }
      }
    }
  };

  // Compass heading direction
  const getCompassHeading = (deg: number) => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(((deg % 360 + 360) % 360) / 45) % 8;
    return directions[index];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#18181c] border border-[#dfbb76]/30 text-[#dfbb76] text-xs font-mono uppercase tracking-widest">
            <Camera className="w-3.5 h-3.5" />
            <span>VIRTUAL SANCTUARY TOUR</span>
          </div>
          <h3 className="font-playfair text-2xl sm:text-3xl md:text-4xl text-white font-bold">
            Interactive 360° Panorama Tour
          </h3>
          <p className="text-xs sm:text-sm text-[#a1a1aa] max-w-xl font-sans-ui">
            Virtually step inside Hotel Sai Maya's celebration spaces. Drag or swipe in any direction to explore our grand hall, ceremonial stage, and pure-veg buffet arrangements.
          </p>
        </div>

        {/* Scene Vantage Switcher Buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-[#141418] border border-white/10 rounded-xl shrink-0 self-start sm:self-auto overflow-x-auto max-w-full">
          {PANORAMA_SCENES.map((scene) => {
            const isSelected = activeSceneId === scene.id;
            return (
              <button
                key={scene.id}
                type="button"
                onClick={() => {
                  setActiveSceneId(scene.id);
                  setActiveHotspot(null);
                }}
                className={`px-3.5 py-2 rounded-lg text-xs font-mono transition-all whitespace-nowrap ${
                  isSelected
                    ? 'bg-[#dfbb76] text-black font-semibold shadow-md'
                    : 'text-[#a1a1aa] hover:text-white'
                }`}
              >
                {scene.name.replace(' Vantage', '').replace(' Corridor', '')}
              </button>
            );
          })}
        </div>
      </div>

      {/* 360 Panorama Stage Container */}
      <div
        ref={containerRef}
        className={`relative w-full rounded-2xl overflow-hidden border border-[#dfbb76]/30 bg-black shadow-2xl transition-all ${
          isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : 'aspect-[16/9] min-h-[420px] max-h-[580px]'
        }`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Canvas Engine */}
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          className="w-full h-full cursor-grab active:cursor-grabbing block"
        />

        {/* Loading Overlay */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center space-y-3 z-30">
            <div className="w-8 h-8 border-2 border-[#dfbb76] border-t-transparent rounded-full animate-spin" />
            <span className="text-xs font-mono text-[#dfbb76] tracking-wider uppercase">
              Loading 360° Spherical Panoramic Scene...
            </span>
          </div>
        )}

        {/* Interaction Hint (Fades after first interaction) */}
        {!hasInteracted && imageLoaded && (
          <div className="absolute inset-x-0 bottom-16 flex justify-center pointer-events-none z-20">
            <div className="px-4 py-2 rounded-full bg-black/70 backdrop-blur-md border border-white/20 text-[#e6ca92] text-xs font-mono flex items-center gap-2 shadow-2xl animate-pulse">
              <Eye className="w-3.5 h-3.5 text-[#dfbb76]" />
              <span>Click & Drag to pan 360° • Click glowing pins to inspect venue details</span>
            </div>
          </div>
        )}

        {/* Top Floating Control Bar */}
        <div className="absolute top-4 inset-x-4 flex items-center justify-between pointer-events-none z-20">
          {/* Active Scene Title Badge */}
          <div className="pointer-events-auto px-3.5 py-1.5 rounded-xl bg-black/75 backdrop-blur-md border border-white/15 text-white text-xs font-mono shadow-xl flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#dfbb76]" />
            <span className="font-semibold">{activeScene.name}</span>
            <span className="text-white/40">|</span>
            <span className="text-[#dfbb76]">{getCompassHeading(yaw)} ({Math.round(yaw)}°)</span>
          </div>

          {/* Quick Actions (Zoom, Auto-Rotate, Fullscreen) */}
          <div className="pointer-events-auto flex items-center gap-1.5 p-1 bg-black/75 backdrop-blur-md border border-white/15 rounded-xl shadow-xl text-white">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(2.0, z + 0.25))}
              className="p-2 rounded-lg hover:bg-white/10 text-white/90 hover:text-white transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.75, z - 0.25))}
              className="p-2 rounded-lg hover:bg-white/10 text-white/90 hover:text-white transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setIsAutoRotating(!isAutoRotating)}
              className={`p-2 rounded-lg transition-colors ${
                isAutoRotating ? 'bg-[#dfbb76] text-black font-bold' : 'hover:bg-white/10 text-white/90'
              }`}
              title={isAutoRotating ? 'Pause Auto-Rotation' : 'Start Auto-Rotation'}
            >
              {isAutoRotating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={toggleFullscreen}
              className="p-2 rounded-lg hover:bg-white/10 text-white/90 hover:text-white transition-colors"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Virtual Tour'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Hotspot Inspection Detail Modal / Popover */}
        {activeHotspot && (
          <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:max-w-md bg-[#16161c]/95 backdrop-blur-xl border border-[#dfbb76]/50 rounded-2xl p-5 shadow-2xl z-30 animate-in fade-in zoom-in-95 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#dfbb76] block">
                  {activeHotspot.category}
                </span>
                <h4 className="font-playfair text-lg text-white font-bold">
                  {activeHotspot.title}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setActiveHotspot(null)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#a1a1aa] hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {activeHotspot.imageUrl && (
              <div className="h-32 rounded-xl overflow-hidden border border-white/10 relative">
                <img
                  src={activeHotspot.imageUrl}
                  alt={activeHotspot.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm text-[10px] font-mono text-[#dfbb76]">
                  {activeHotspot.badge}
                </div>
              </div>
            )}

            <p className="text-xs text-[#a1a1aa] leading-relaxed font-sans-ui">
              {activeHotspot.description}
            </p>

            <div className="pt-2 flex items-center justify-between border-t border-white/10 text-[11px] font-mono">
              <span className="text-emerald-400 flex items-center gap-1">
                <span>Verified Sanctuary Specification</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  const form = document.getElementById('banquet-inquiry-form');
                  if (form) form.scrollIntoView({ behavior: 'smooth' });
                  setActiveHotspot(null);
                }}
                className="text-[#dfbb76] hover:underline flex items-center gap-1"
              >
                <span>Inquire for this feature</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
