import React, { useState } from 'react';
import {
  Users,
  Layers,
  Sparkles,
  ChevronRight,
  Maximize2,
  CheckCircle2,
  ArrowRight,
  Eye,
  Utensils,
  Mic,
  Monitor
} from 'lucide-react';

export type LayoutStyle = 'theater' | 'ushape' | 'banquet';

interface LayoutDetails {
  id: LayoutStyle;
  name: string;
  tagline: string;
  maxCapacity: string;
  optimalRange: string;
  idealFor: string[];
  sightlines: string;
  minglingLevel: string;
  buffetAccess: string;
  dimensions: string;
  features: string[];
}

const LAYOUT_CONFIGS: Record<LayoutStyle, LayoutDetails> = {
  theater: {
    id: 'theater',
    name: 'Theater Style',
    tagline: 'Maximum seated capacity with forward-facing sightlines toward the elevated dais.',
    maxCapacity: '150 Guests',
    optimalRange: '70 – 150 Guests',
    idealFor: [
      'Spiritual Satsangs & Bhajan Mandalis',
      'Yatra Tour Group Orientations',
      'Award Ceremonies & Keynote Addresses',
      'Pre-wedding Sangeet Audience Viewing'
    ],
    sightlines: '100% Direct to Stage',
    minglingLevel: 'Low (Structured Focus)',
    buffetAccess: 'Post-session separate dining enclosure',
    dimensions: 'Full Hall Lengthwise Flow',
    features: [
      'Central 5ft aisle for ceremonial processions',
      'Dual 3.5ft perimeter egress aisles',
      'Elevated carpeted stage with speaker podium',
      'Acoustically balanced speaker placement'
    ]
  },
  ushape: {
    id: 'ushape',
    name: 'U-Shape Style',
    tagline: 'Collaborative perimeter seating with an open focal center for discussion and interactive rituals.',
    maxCapacity: '45 Guests',
    optimalRange: '20 – 45 Guests',
    idealFor: [
      'Family Council & Senior Elder Roundtables',
      'Intimate Pre-Wedding Rituals (Sakharpuda)',
      'Corporate Strategy Retreats',
      'Pilgrim Tour Organizer Committee Meets'
    ],
    sightlines: '95% Face-to-Face & Screen',
    minglingLevel: 'Medium-High (Conversational)',
    buffetAccess: 'Direct access or in-hall service',
    dimensions: 'Focused Hall Center Configuration',
    features: [
      'Continuous linen-draped executive tables',
      'Direct visual contact between all family members',
      'Open front for presentation display or ceremonial altar',
      'Dedicated microphone points along table perimeter'
    ]
  },
  banquet: {
    id: 'banquet',
    name: 'Banquet Style',
    tagline: 'Circular dining clusters designed for social mingling, joyful feasts, and festive celebrations.',
    maxCapacity: '100 Guests',
    optimalRange: '40 – 100 Guests',
    idealFor: [
      'Birthday & Golden Jubilee Feasts',
      'Wedding Receptions & Engagement Dinners',
      'Multi-Generational Joint Family Reunions',
      'Celebratory Post-Darshan Luncheons'
    ],
    sightlines: '90% Multi-Angle Visibility',
    minglingLevel: 'Very High (Social & Dining)',
    buffetAccess: 'Seamless flow to live satvik buffet',
    dimensions: 'Distributed Spatial Layout',
    features: [
      'Round banquet tables seating 6 to 8 guests each',
      'Wide walkways preventing congestion during dining',
      'Direct sightlines to main stage and photo backdrop',
      'Dedicated perimeter space for live food counters'
    ]
  }
};

interface BanquetSeatLayoutSelectorProps {
  onSelectLayout?: (layoutName: string, capacity: string) => void;
}

export const BanquetSeatLayoutSelector: React.FC<BanquetSeatLayoutSelectorProps> = ({
  onSelectLayout
}) => {
  const [activeLayout, setActiveLayout] = useState<LayoutStyle>('banquet');
  const [hoveredElement, setHoveredElement] = useState<string | null>(null);

  const current = LAYOUT_CONFIGS[activeLayout];

  const handleApplyLayout = () => {
    if (onSelectLayout) {
      onSelectLayout(current.name, current.maxCapacity);
    }
    const form = document.getElementById('banquet-inquiry-form');
    if (form) {
      form.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#18181c] border border-[#dfbb76]/30 text-[#dfbb76] text-xs font-mono uppercase tracking-widest">
            <Layers className="w-3.5 h-3.5" />
            <span>INTERACTIVE SPACE PLANNING</span>
          </div>
          <h3 className="font-playfair text-2xl sm:text-3xl md:text-4xl text-white font-bold">
            Interactive Seating Layout Selector
          </h3>
          <p className="text-xs sm:text-sm text-[#a1a1aa] max-w-xl font-sans-ui">
            Preview how our climate-controlled celebration hall transforms to suit your specific event type, from formal satsangs to joyful festive dining.
          </p>
        </div>

        {/* Layout Style Selector Buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-[#141418] border border-white/10 rounded-xl shrink-0 self-start sm:self-auto">
          {(['theater', 'ushape', 'banquet'] as LayoutStyle[]).map((layoutKey) => {
            const isSelected = activeLayout === layoutKey;
            const config = LAYOUT_CONFIGS[layoutKey];
            return (
              <button
                key={layoutKey}
                type="button"
                onClick={() => setActiveLayout(layoutKey)}
                className={`px-3.5 py-2 rounded-lg text-xs font-mono transition-all flex items-center gap-2 ${
                  isSelected
                    ? 'bg-[#dfbb76] text-black font-semibold shadow-md'
                    : 'text-[#a1a1aa] hover:text-white'
                }`}
              >
                <span>{config.name.replace(' Style', '')}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded ${
                  isSelected ? 'bg-black/20 text-black' : 'bg-white/10 text-white/70'
                }`}>
                  {config.maxCapacity.replace(' Guests', '')}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Interactive Stage Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#121216] border border-white/10 rounded-2xl p-6 sm:p-8 shadow-2xl">
        {/* Left: Interactive 2D Floor Plan SVG Blueprint */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center relative bg-[#0c0c0f] border border-white/10 rounded-xl p-4 sm:p-6 min-h-[380px] overflow-hidden">
          {/* Blueprint Grid Watermark */}
          <div
            className="absolute inset-0 opacity-[0.04] pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, #dfbb76 1px, transparent 0)',
              backgroundSize: '20px 20px'
            }}
          />

          {/* Interactive Tooltip Overlay */}
          {hoveredElement && (
            <div className="absolute top-4 left-4 z-20 px-3 py-1.5 rounded-lg bg-black/80 backdrop-blur-md border border-[#dfbb76]/40 text-[#dfbb76] text-[11px] font-mono shadow-lg animate-in fade-in">
              {hoveredElement}
            </div>
          )}

          {/* Dimensions Marker */}
          <div className="absolute bottom-3 right-4 text-[10px] font-mono text-[#a1a1aa]/60 flex items-center gap-2">
            <span>Hall Area: ~2,400 sq.ft</span>
            <span>•</span>
            <span>Scale: 1:50</span>
          </div>

          {/* Blueprint SVG Layouts */}
          <div className="w-full max-w-[500px] aspect-[4/3] flex items-center justify-center">
            {activeLayout === 'theater' && (
              <svg viewBox="0 0 500 380" className="w-full h-full select-none">
                {/* Boundary & Walls */}
                <rect x="15" y="15" width="470" height="350" rx="12" fill="#141419" stroke="#33333e" strokeWidth="2" />

                {/* Stage Area (Top) */}
                <g
                  onMouseEnter={() => setHoveredElement('Elevated Stage & Ceremonial Dais (24ft x 10ft)')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer group"
                >
                  <rect x="80" y="30" width="340" height="60" rx="6" fill="#252017" stroke="#dfbb76" strokeWidth="2" />
                  <text x="250" y="60" fill="#dfbb76" fontSize="13" fontFamily="Cinzel, serif" fontWeight="bold" textAnchor="middle">
                    ELEVATED CEREMONIAL STAGE / DAIS
                  </text>
                  <text x="250" y="76" fill="#e6ca92" fontSize="9" fontFamily="monospace" textAnchor="middle">
                    Carpeted with Auspicious Floral Backdrop & Backdrop Lighting
                  </text>

                  {/* Speaker Podium */}
                  <rect x="105" y="42" width="22" height="18" rx="2" fill="#dfbb76" />
                  <circle cx="116" cy="40" r="3" fill="#fff" />
                </g>

                {/* Central Aisle */}
                <line x1="250" y1="100" x2="250" y2="330" stroke="#dfbb76" strokeWidth="1.5" strokeDasharray="4 4" opacity="0.6" />
                <text x="250" y="325" fill="#dfbb76" fontSize="9" fontFamily="monospace" textAnchor="middle">
                  CENTRAL AISLE (5 FT)
                </text>

                {/* Seating Rows (Left & Right Blocks) */}
                {Array.from({ length: 6 }).map((_, rowIdx) => {
                  const y = 115 + rowIdx * 32;
                  return (
                    <g key={`row-${rowIdx}`}>
                      {/* Left Block (5 seats per row) */}
                      {Array.from({ length: 5 }).map((_, colIdx) => {
                        const x = 60 + colIdx * 34;
                        return (
                          <rect
                            key={`L-${rowIdx}-${colIdx}`}
                            x={x}
                            y={y}
                            width="24"
                            height="20"
                            rx="4"
                            fill="#1e1e26"
                            stroke="#48485a"
                            strokeWidth="1"
                            className="hover:fill-[#dfbb76] hover:stroke-[#dfbb76] transition-colors cursor-pointer"
                            onMouseEnter={() => setHoveredElement(`Guest Chair - Row ${rowIdx + 1}, Seat L${colIdx + 1}`)}
                            onMouseLeave={() => setHoveredElement(null)}
                          />
                        );
                      })}

                      {/* Right Block (5 seats per row) */}
                      {Array.from({ length: 5 }).map((_, colIdx) => {
                        const x = 275 + colIdx * 34;
                        return (
                          <rect
                            key={`R-${rowIdx}-${colIdx}`}
                            x={x}
                            y={y}
                            width="24"
                            height="20"
                            rx="4"
                            fill="#1e1e26"
                            stroke="#48485a"
                            strokeWidth="1"
                            className="hover:fill-[#dfbb76] hover:stroke-[#dfbb76] transition-colors cursor-pointer"
                            onMouseEnter={() => setHoveredElement(`Guest Chair - Row ${rowIdx + 1}, Seat R${colIdx + 1}`)}
                            onMouseLeave={() => setHoveredElement(null)}
                          />
                        );
                      })}
                    </g>
                  );
                })}

                {/* Main Entrance (Bottom) */}
                <g
                  onMouseEnter={() => setHoveredElement('Grand Entrance & Reception Lobby')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer"
                >
                  <rect x="200" y="355" width="100" height="10" rx="3" fill="#dfbb76" />
                  <text x="250" y="350" fill="#a1a1aa" fontSize="8" fontFamily="monospace" textAnchor="middle">
                    MAIN ENTRANCE / INGRESS
                  </text>
                </g>
              </svg>
            )}

            {activeLayout === 'ushape' && (
              <svg viewBox="0 0 500 380" className="w-full h-full select-none">
                {/* Boundary */}
                <rect x="15" y="15" width="470" height="350" rx="12" fill="#141419" stroke="#33333e" strokeWidth="2" />

                {/* Focal Presentation Altar/Screen (Top) */}
                <g
                  onMouseEnter={() => setHoveredElement('Presentation Altar & AV Screen')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer"
                >
                  <rect x="160" y="32" width="180" height="32" rx="6" fill="#252017" stroke="#dfbb76" strokeWidth="2" />
                  <text x="250" y="52" fill="#dfbb76" fontSize="11" fontFamily="Cinzel, serif" fontWeight="bold" textAnchor="middle">
                    FOCAL ALTAR / SCREEN
                  </text>
                </g>

                {/* U-Shape Configuration */}
                {/* Top Crossbar Table */}
                <g
                  onMouseEnter={() => setHoveredElement('Head Table (6 - 8 VIP Seats)')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer"
                >
                  <rect x="90" y="85" width="320" height="30" rx="4" fill="#202028" stroke="#dfbb76" strokeWidth="1.5" />
                  <text x="250" y="104" fill="#dfbb76" fontSize="10" fontFamily="monospace" textAnchor="middle">
                    EXECUTIVE HEAD TABLE
                  </text>
                  {/* Chairs outside the table */}
                  {Array.from({ length: 8 }).map((_, i) => (
                    <rect
                      key={`top-chair-${i}`}
                      x={102 + i * 38}
                      y="62"
                      width="20"
                      height="18"
                      rx="3"
                      fill="#1e1e26"
                      stroke="#48485a"
                    />
                  ))}
                </g>

                {/* Left Arm Table */}
                <g
                  onMouseEnter={() => setHoveredElement('Left Wing Seating Table (12 - 16 Seats)')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer"
                >
                  <rect x="90" y="115" width="35" height="190" rx="4" fill="#202028" stroke="#dfbb76" strokeWidth="1.5" />
                  {/* Chairs on outer side */}
                  {Array.from({ length: 6 }).map((_, i) => (
                    <rect
                      key={`left-chair-${i}`}
                      x={60}
                      y={125 + i * 30}
                      width="20"
                      height="20"
                      rx="3"
                      fill="#1e1e26"
                      stroke="#48485a"
                    />
                  ))}
                </g>

                {/* Right Arm Table */}
                <g
                  onMouseEnter={() => setHoveredElement('Right Wing Seating Table (12 - 16 Seats)')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer"
                >
                  <rect x="375" y="115" width="35" height="190" rx="4" fill="#202028" stroke="#dfbb76" strokeWidth="1.5" />
                  {/* Chairs on outer side */}
                  {Array.from({ length: 6 }).map((_, i) => (
                    <rect
                      key={`right-chair-${i}`}
                      x={420}
                      y={125 + i * 30}
                      width="20"
                      height="20"
                      rx="3"
                      fill="#1e1e26"
                      stroke="#48485a"
                    />
                  ))}
                </g>

                {/* Open Center Space */}
                <circle cx="250" cy="205" r="35" fill="none" stroke="#dfbb76" strokeWidth="1" strokeDasharray="4 4" opacity="0.4" />
                <text x="250" y="208" fill="#a1a1aa" fontSize="9" fontFamily="monospace" textAnchor="middle">
                  OPEN INTERACTION ZONE
                </text>

                {/* Entrance */}
                <rect x="200" y="355" width="100" height="10" rx="3" fill="#dfbb76" />
                <text x="250" y="350" fill="#a1a1aa" fontSize="8" fontFamily="monospace" textAnchor="middle">
                  MAIN ENTRANCE
                </text>
              </svg>
            )}

            {activeLayout === 'banquet' && (
              <svg viewBox="0 0 500 380" className="w-full h-full select-none">
                {/* Boundary */}
                <rect x="15" y="15" width="470" height="350" rx="12" fill="#141419" stroke="#33333e" strokeWidth="2" />

                {/* Celebration Stage & Photo Backdrop (Top) */}
                <g
                  onMouseEnter={() => setHoveredElement('Celebration Dais & Ceremonial Photo Stage')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer"
                >
                  <rect x="120" y="28" width="260" height="42" rx="6" fill="#252017" stroke="#dfbb76" strokeWidth="2" />
                  <text x="250" y="52" fill="#dfbb76" fontSize="12" fontFamily="Cinzel, serif" fontWeight="bold" textAnchor="middle">
                    CELEBRATION STAGE
                  </text>
                  <text x="250" y="64" fill="#e6ca92" fontSize="8" fontFamily="monospace" textAnchor="middle">
                    Stage for Cake Cutting, Sakharpuda & Felicitation
                  </text>
                </g>

                {/* Pure-Veg Buffet Station (Right Side) */}
                <g
                  onMouseEnter={() => setHoveredElement('100% Satvik Pure-Veg Buffet & Live Dessert Counter')}
                  onMouseLeave={() => setHoveredElement(null)}
                  className="cursor-pointer"
                >
                  <rect x="420" y="85" width="55" height="230" rx="6" fill="#13271a" stroke="#22c55e" strokeWidth="1.5" />
                  <text
                    x="450"
                    y="200"
                    fill="#4ade80"
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                    transform="rotate(90 450 200)"
                  >
                    SATVIK BUFFET & DESSERT COUNTER
                  </text>
                </g>

                {/* Circular Banquet Dining Tables (6 tables, 8 seats each) */}
                {[
                  { cx: 100, cy: 125, id: 'T1' },
                  { cx: 250, cy: 125, id: 'T2' },
                  { cx: 100, cy: 220, id: 'T3' },
                  { cx: 250, cy: 220, id: 'T4' },
                  { cx: 100, cy: 310, id: 'T5' },
                  { cx: 250, cy: 310, id: 'T6' }
                ].map((tbl) => (
                  <g
                    key={tbl.id}
                    className="cursor-pointer group"
                    onMouseEnter={() => setHoveredElement(`Round Banquet Table ${tbl.id} - 8 Seats with Satvik Service`)}
                    onMouseLeave={() => setHoveredElement(null)}
                  >
                    {/* Table Circle */}
                    <circle
                      cx={tbl.cx}
                      cy={tbl.cy}
                      r="26"
                      fill="#22222a"
                      stroke="#dfbb76"
                      strokeWidth="1.5"
                      className="group-hover:fill-[#2d281e] transition-colors"
                    />
                    <text x={tbl.cx} y={tbl.cy + 3} fill="#dfbb76" fontSize="9" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                      {tbl.id}
                    </text>

                    {/* 8 Chairs surrounding table */}
                    {Array.from({ length: 8 }).map((_, cIdx) => {
                      const angle = (cIdx * 45 * Math.PI) / 180;
                      const chairX = tbl.cx + Math.cos(angle) * 38;
                      const chairY = tbl.cy + Math.sin(angle) * 38;
                      return (
                        <circle
                          key={`chair-${tbl.id}-${cIdx}`}
                          cx={chairX}
                          cy={chairY}
                          r="6"
                          fill="#181820"
                          stroke="#525264"
                          strokeWidth="1"
                          className="group-hover:stroke-[#dfbb76] transition-colors"
                        />
                      );
                    })}
                  </g>
                ))}

                {/* Central Walkway Line */}
                <line x1="335" y1="80" x2="335" y2="340" stroke="#dfbb76" strokeWidth="1" strokeDasharray="3 3" opacity="0.3" />
                <text x="335" y="350" fill="#a1a1aa" fontSize="8" fontFamily="monospace" textAnchor="middle">
                  DINING CIRCULATION AISLE
                </text>

                {/* Entrance */}
                <rect x="150" y="355" width="80" height="10" rx="3" fill="#dfbb76" />
                <text x="190" y="350" fill="#a1a1aa" fontSize="8" fontFamily="monospace" textAnchor="middle">
                  MAIN ENTRANCE
                </text>
              </svg>
            )}
          </div>
        </div>

        {/* Right: Layout Specs & Inclusions Info Card */}
        <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-widest text-[#dfbb76]">
                CONFIGURATION BLUEPRINT
              </span>
              <span className="text-xs font-mono px-3 py-1 rounded-full bg-[#dfbb76]/10 border border-[#dfbb76]/30 text-[#e6ca92]">
                Capacity: {current.maxCapacity}
              </span>
            </div>

            <h4 className="font-playfair text-2xl sm:text-3xl text-white font-bold">
              {current.name}
            </h4>

            <p className="text-xs sm:text-sm text-[#a1a1aa] leading-relaxed font-sans-ui">
              {current.tagline}
            </p>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-3 pt-2 text-xs font-mono">
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[#a1a1aa] block text-[11px]">Recommended Group</span>
                <span className="text-white font-semibold">{current.optimalRange}</span>
              </div>
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[#a1a1aa] block text-[11px]">Stage Sightlines</span>
                <span className="text-emerald-400 font-semibold">{current.sightlines}</span>
              </div>
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[#a1a1aa] block text-[11px]">Mingling Dynamic</span>
                <span className="text-[#e6ca92] font-semibold">{current.minglingLevel}</span>
              </div>
              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[#a1a1aa] block text-[11px]">Buffet Flow</span>
                <span className="text-white font-semibold">{current.buffetAccess}</span>
              </div>
            </div>

            {/* Ideal Occasions */}
            <div className="space-y-2 pt-2">
              <span className="text-[11px] font-mono uppercase tracking-wider text-[#dfbb76] block">
                Best Suited For:
              </span>
              <ul className="space-y-1.5 text-xs text-[#d1d1d6] font-sans-ui">
                {current.idealFor.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#dfbb76] shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Bottom Action */}
          <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center gap-3">
            <button
              type="button"
              onClick={handleApplyLayout}
              className="w-full gold-btn py-3 px-6 rounded-xl font-cinzel font-semibold text-xs tracking-wider uppercase text-black flex items-center justify-center gap-2 shadow-lg"
            >
              <span>Apply {current.name} to Enquiry</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
