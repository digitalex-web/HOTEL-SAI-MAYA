import React, { useState } from 'react';
import {
  Sparkles,
  PartyPopper,
  HeartHandshake,
  Users,
  Briefcase,
  UtensilsCrossed,
  MapPin,
  Car,
  ShieldCheck,
  Calendar,
  Clock,
  Phone,
  MessageSquare,
  CheckCircle2,
  HelpCircle,
  ChevronRight,
  ArrowRight,
  AlertCircle,
  Building2,
  Sparkle,
  Send,
  RotateCcw,
  Check,
  BookmarkCheck,
  Download,
  Trash2,
  Copy,
  FileCheck,
  X,
  Shield
} from 'lucide-react';
import {
  RESTAURANT_METADATA,
  BANQUET_GALLERY_STAGES
} from '../data/restaurantData';
import { BanquetEventType, BanquetInquiryFormData, SavedBanquetEnquiry } from '../types';
import { useAdmin } from '../context/AdminContext';
import { BanquetCalendar } from './BanquetCalendar';
import { BanquetDatePicker } from './BanquetDatePicker';
import { BanquetPackagesGrid } from './BanquetPackagesGrid';
import { BanquetSeatLayoutSelector } from './BanquetSeatLayoutSelector';
import { BanquetPanoramaViewer } from './BanquetPanoramaViewer';

export interface BanquetSectionProps {
  onSubmitInquiry?: (inquiry: SavedBanquetEnquiry) => void;
  onSaveGuestInfo?: (guestInfo: SavedBanquetEnquiry) => void;
}

export const BanquetSection: React.FC<BanquetSectionProps> = ({
  onSubmitInquiry,
  onSaveGuestInfo
}) => {
  // Access Central Admin Context for live Enquiries integration
  let adminCtx: ReturnType<typeof useAdmin> | null = null;
  try {
    adminCtx = useAdmin();
  } catch {
    adminCtx = null;
  }

  // Gallery state
  const [activeStageId, setActiveStageId] = useState<string>('hall');

  // Inquiry form state
  const [formData, setFormData] = useState<BanquetInquiryFormData>({
    name: '',
    mobileNumber: '',
    eventType: 'Birthday Celebrations',
    eventDate: '',
    expectedGuests: '',
    preferredTime: 'Evening / Dinner (6:00 PM – 11:00 PM)',
    additionalRequirements: ''
  });

  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [autoFilledNotice, setAutoFilledNotice] = useState(false);

  // Form State Validation
  const [formErrors, setFormErrors] = useState<{
    name?: string;
    mobileNumber?: string;
    eventDate?: string;
    expectedGuests?: string;
    general?: string;
  }>({});
  const [touchedFields, setTouchedFields] = useState<Record<string, boolean>>({});
  const [submitAttempted, setSubmitAttempted] = useState(false);

  // Field validation rules
  const validateField = (field: string, value: string): string | undefined => {
    switch (field) {
      case 'name': {
        const trimmed = value.trim();
        if (!trimmed) {
          return 'Full name is required to register the banquet enquiry.';
        }
        if (trimmed.length < 2) {
          return 'Full name must be at least 2 characters long.';
        }
        if (!/^[a-zA-Z\s.'-]+$/.test(trimmed)) {
          return 'Name should contain letters and standard punctuation only.';
        }
        return undefined;
      }
      case 'mobileNumber': {
        const trimmed = value.trim();
        if (!trimmed) {
          return 'Mobile contact number is required.';
        }
        const digits = trimmed.replace(/\D/g, '');
        if (digits.length < 10) {
          return 'Please enter a valid 10-digit mobile number (e.g. +91 98220 76543).';
        }
        if (digits.length > 13) {
          return 'Mobile number exceeds maximum standard length.';
        }
        return undefined;
      }
      case 'eventDate': {
        const trimmed = value.trim();
        if (!trimmed) {
          return 'Please select a date for your banquet event.';
        }
        const selected = new Date(trimmed);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (!isNaN(selected.getTime()) && selected < today) {
          return 'Event date cannot be in the past.';
        }
        return undefined;
      }
      case 'expectedGuests': {
        const trimmed = value.trim();
        if (trimmed) {
          const num = parseInt(trimmed.replace(/\D/g, ''), 10);
          if (isNaN(num)) {
            return 'Please enter an estimated number of guests (e.g. 75).';
          }
          if (num < 5) {
            return 'Minimum banquet gathering is 5 guests.';
          }
          if (num > 350) {
            return 'Maximum hall capacity is 250 seated / 350 floating guests.';
          }
        }
        return undefined;
      }
      default:
        return undefined;
    }
  };

  const validateAll = (data: BanquetInquiryFormData) => {
    const errs: typeof formErrors = {};
    const nameErr = validateField('name', data.name);
    if (nameErr) errs.name = nameErr;

    const phoneErr = validateField('mobileNumber', data.mobileNumber);
    if (phoneErr) errs.mobileNumber = phoneErr;

    const dateErr = validateField('eventDate', data.eventDate);
    if (dateErr) errs.eventDate = dateErr;

    const guestsErr = validateField('expectedGuests', data.expectedGuests);
    if (guestsErr) errs.expectedGuests = guestsErr;

    return errs;
  };

  const handleFieldChange = (field: keyof BanquetInquiryFormData, value: string) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);

    if (touchedFields[field] || submitAttempted) {
      const fieldError = validateField(field, value);
      setFormErrors((prev) => {
        const next = { ...prev };
        if (fieldError) {
          next[field as keyof typeof formErrors] = fieldError;
        } else {
          delete next[field as keyof typeof formErrors];
        }
        return next;
      });
    }
  };

  const handleBlur = (field: string) => {
    setTouchedFields((prev) => ({ ...prev, [field]: true }));
    const error = validateField(field, (formData as any)[field] || '');
    setFormErrors((prev) => {
      const next = { ...prev };
      if (error) {
        next[field as keyof typeof formErrors] = error;
      } else {
        delete next[field as keyof typeof formErrors];
      }
      return next;
    });
  };

  const [savedEnquiries, setSavedEnquiries] = useState<SavedBanquetEnquiry[]>(() => {
    try {
      const saved = localStorage.getItem('hotel_sai_maya_banquet_enquiries');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [latestSavedEnquiry, setLatestSavedEnquiry] = useState<SavedBanquetEnquiry | null>(null);
  const [showSavedListModal, setShowSavedListModal] = useState(false);
  const [copiedRef, setCopiedRef] = useState(false);

  // Success notification message & feedback states
  const [successNotification, setSuccessNotification] = useState<{
    show: boolean;
    title: string;
    message: string;
    enquiry: SavedBanquetEnquiry;
  } | null>(null);
  const [showToast, setShowToast] = useState(false);
  const [showReceiptDetail, setShowReceiptDetail] = useState(false);

  // Temporary Success Feedback Modal State (Auto-appears upon submission and confirms data capture)
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [modalDismissProgress, setModalDismissProgress] = useState(100);
  const [isModalPaused, setIsModalPaused] = useState(false);
  const [isTimerDisabled, setIsTimerDisabled] = useState(false);

  // Auto-dismiss floating toast notification
  React.useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => {
        setShowToast(false);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  // Auto-dismiss temporary success modal with progress countdown bar (7 seconds)
  React.useEffect(() => {
    if (!showSuccessModal) return;

    const DURATION = 7000; // 7 seconds duration
    const INTERVAL = 50;
    let elapsed = 0;

    const interval = setInterval(() => {
      if (!isModalPaused && !isTimerDisabled) {
        elapsed += INTERVAL;
        const remainingPercent = Math.max(0, 100 - (elapsed / DURATION) * 100);
        setModalDismissProgress(remainingPercent);

        if (elapsed >= DURATION) {
          setShowSuccessModal(false);
          clearInterval(interval);
        }
      }
    }, INTERVAL);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowSuccessModal(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearInterval(interval);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [showSuccessModal, isModalPaused, isTimerDisabled]);

  const handleQuickFillSample = () => {
    // Generate an upcoming auspicious weekend date for Shirdi events
    const today = new Date();
    const futureDate = new Date(today);
    futureDate.setDate(today.getDate() + 18);
    const yyyy = futureDate.getFullYear();
    const mm = String(futureDate.getMonth() + 1).padStart(2, '0');
    const dd = String(futureDate.getDate()).padStart(2, '0');
    const sampleDate = `${yyyy}-${mm}-${dd}`;

    setFormData({
      name: 'Rajesh Patil',
      mobileNumber: '+91 98220 76543',
      eventType: 'Engagement & Family Functions',
      eventDate: sampleDate,
      expectedGuests: '85 Guests',
      preferredTime: 'Evening / Dinner (6:00 PM – 11:00 PM)',
      additionalRequirements: 'Selected Tier: Gold Royal Muhurat (₹850/guest) | Preferred Seating: Banquet Style (100 Guests) | Request 100% Jain Satvik buffet counter, audio mic setup, and elder-friendly ground floor seating.'
    });

    setFormErrors({});
    setTouchedFields({});
    setSubmitAttempted(false);
    setAutoFilledNotice(true);
    setTimeout(() => {
      setAutoFilledNotice(false);
    }, 4500);
  };

  const handleResetForm = () => {
    setFormData({
      name: '',
      mobileNumber: '',
      eventType: 'Birthday Celebrations',
      eventDate: '',
      expectedGuests: '',
      preferredTime: 'Evening / Dinner (6:00 PM – 11:00 PM)',
      additionalRequirements: ''
    });
    setFormErrors({});
    setTouchedFields({});
    setSubmitAttempted(false);
    setAutoFilledNotice(false);
  };

  const activeStage =
    BANQUET_GALLERY_STAGES.find((s) => s.id === activeStageId) ||
    BANQUET_GALLERY_STAGES[0];

  // Event types data
  const eventTypes: {
    type: BanquetEventType;
    icon: React.ReactNode;
    title: string;
    description: string;
    capacityNote: string;
  }[] = [
    {
      type: 'Birthday Celebrations',
      icon: <PartyPopper className="w-5 h-5 text-[#dfbb76]" />,
      title: 'Birthday Celebrations',
      description: 'Create a memorable celebration with family and friends in a warm, festive setting.',
      capacityNote: 'Guest capacity: To be confirmed'
    },
    {
      type: 'Engagement & Family Functions',
      icon: <HeartHandshake className="w-5 h-5 text-[#dfbb76]" />,
      title: 'Engagement & Family Functions',
      description: 'A convenient setting for intimate ceremonies, ring rituals, and auspicious family gatherings.',
      capacityNote: 'Auspicious rituals & stage layout (TBC)'
    },
    {
      type: 'Family Get-Togethers',
      icon: <Users className="w-5 h-5 text-[#dfbb76]" />,
      title: 'Family Get-Togethers',
      description: 'Bring everyone together for joyous reunion meals, golden jubilee lunches, and memorable moments.',
      capacityNote: 'Pure-veg multi-course dining'
    },
    {
      type: 'Meetings & Small Events',
      icon: <Briefcase className="w-5 h-5 text-[#dfbb76]" />,
      title: 'Meetings & Small Events',
      description: 'Suitable for gatherings, corporate meetings, pilgrim tour orientations, and private occasions.',
      capacityNote: 'Subject to venue availability'
    }
  ];

  // What guests can expect cards
  const guestExpectations = [
    {
      icon: <Building2 className="w-5 h-5 text-[#dfbb76]" />,
      title: 'Comfortable Event Space',
      desc: 'Ambient, well-ventilated indoor celebration hall providing an intimate, comfortable venue for social and spiritual events.',
      isVerified: true
    },
    {
      icon: <UtensilsCrossed className="w-5 h-5 text-emerald-400" />,
      title: 'Vegetarian Dining',
      desc: '100% Satvik, pure-vegetarian feast catering crafted fresh in our celebrated highway kitchens, with dedicated Jain options.',
      isVerified: true
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-emerald-400" />,
      title: 'Family-Friendly Environment',
      desc: 'A serene, wholesome pilgrim atmosphere that warmly respects elders, children, and multi-generational families.',
      isVerified: true
    },
    {
      icon: <MapPin className="w-5 h-5 text-[#dfbb76]" />,
      title: 'Convenient Location',
      desc: 'Strategic highway frontage on MH SH 10, located only 7 minutes from the sacred Sai Baba Samadhi Mandir in Shirdi.',
      isVerified: true
    },
    {
      icon: <Car className="w-5 h-5 text-[#dfbb76]" />,
      title: 'Parking Availability',
      desc: 'Expansive private parking grounds accommodating family cars, tempo travelers, and luxury pilgrim tour coaches.',
      isVerified: true
    },
    {
      icon: <HelpCircle className="w-5 h-5 text-amber-400" />,
      title: 'Custom Event Arrangements',
      desc: 'Special stage flower décor, audio-visual sound setup, customized buffet tiers, and ceremonial backdrops.',
      isVerified: false,
      unverifiedNote: 'To be confirmed on inquiry'
    }
  ];

  // Dedicated onSubmit handler for the banquet inquiry form with state validation
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault(); // Prevents default form submission and any page navigation
    setSubmitAttempted(true);

    // Validate form inputs against state rules
    const errors = validateAll(formData);
    setFormErrors(errors);
    setTouchedFields({
      name: true,
      mobileNumber: true,
      eventDate: true,
      expectedGuests: true
    });

    if (Object.keys(errors).length > 0) {
      // Focus/scroll to error summary alert
      setTimeout(() => {
        const errorEl = document.getElementById('banquet-validation-alert') || document.getElementById('banquet-inquiry-form');
        if (errorEl) {
          errorEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 50);
      return;
    }

    setIsSubmitting(true);

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const referenceCode = `HSM-BNQ-${randomSuffix}`;
    const timestamp = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      dateStyle: 'medium',
      timeStyle: 'short'
    });

    const newEnquiry: SavedBanquetEnquiry = {
      id: `bnq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      referenceCode,
      name: formData.name.trim(),
      mobileNumber: formData.mobileNumber.trim(),
      eventType: formData.eventType,
      eventDate: formData.eventDate,
      expectedGuests: formData.expectedGuests.trim() || 'To be confirmed during consultation',
      preferredTime: formData.preferredTime,
      additionalRequirements: formData.additionalRequirements.trim() || 'Standard Satvik Catering & Hall Setup',
      createdAt: timestamp,
      status: 'Saved & Registered'
    };

    // Save guest information to local state management
    setSavedEnquiries((prev) => {
      const updated = [newEnquiry, ...prev];
      try {
        localStorage.setItem('hotel_sai_maya_banquet_enquiries', JSON.stringify(updated));
      } catch (err) {
        console.error('Failed to save banquet enquiry to localStorage:', err);
      }
      return updated;
    });

    // Directly integrate into Admin Panel's Enquiries register
    if (adminCtx?.addEnquiry) {
      adminCtx.addEnquiry({
        id: newEnquiry.id,
        customerName: newEnquiry.name,
        mobileNumber: newEnquiry.mobileNumber,
        type: 'banquet',
        eventDate: newEnquiry.eventDate,
        expectedGuests: newEnquiry.expectedGuests,
        preferredTime: newEnquiry.preferredTime,
        requirements: `[${newEnquiry.eventType}] ${newEnquiry.additionalRequirements}`,
        status: 'new',
        createdAt: timestamp,
        referenceCode: newEnquiry.referenceCode,
        source: 'website_banquet',
        eventType: newEnquiry.eventType,
        totalAmountEstimate:
          !isNaN(Number(newEnquiry.expectedGuests)) && Number(newEnquiry.expectedGuests) > 0
            ? Number(newEnquiry.expectedGuests) * 550
            : 25000,
        history: [
          {
            id: `log-${Date.now()}`,
            timestamp,
            action: 'Website Banquet Inquiry Submitted',
            note: `Submitted through Website Banquet Form (Booking Ref: ${newEnquiry.referenceCode})`,
            staffName: 'Website Guest'
          }
        ]
      });
    }

    // Broadcast sync event for all active admin tabs
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('sai_maya_inquiry_submitted'));
    }

    setLatestSavedEnquiry(newEnquiry);
    setFormSubmitted(true);
    setIsSubmitting(false);

    // Clear validation error state after successful submission
    setFormErrors({});
    setTouchedFields({});
    setSubmitAttempted(false);

    // Displays a rich success notification message upon completion
    setSuccessNotification({
      show: true,
      title: 'Banquet Enquiry Successfully Submitted!',
      message: `Thank you, ${newEnquiry.name}! Your banquet enquiry for ${newEnquiry.eventType} on ${newEnquiry.eventDate} has been recorded and synced into our reservation register. Reference ID: ${newEnquiry.referenceCode}. Our Banquet Coordinator will call you at ${newEnquiry.mobileNumber} to confirm hall availability and customize your Satvik menu.`,
      enquiry: newEnquiry
    });
    setShowToast(true);
    setShowSuccessModal(true);
    setModalDismissProgress(100);
    setIsModalPaused(false);
    setIsTimerDisabled(false);

    // Call optional callbacks if provided
    onSubmitInquiry?.(newEnquiry);
    onSaveGuestInfo?.(newEnquiry);

    // Scroll to success feedback notification smoothly
    setTimeout(() => {
      const notificationEl = document.getElementById('banquet-success-notification') || document.getElementById('banquet-inquiry-form');
      if (notificationEl) {
        notificationEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 80);
  };

  // Switch to admin panel enquiry section directly
  const handleOpenAdminEnquiries = () => {
    try {
      if (adminCtx) {
        adminCtx.setActiveNav('enquiries');
        adminCtx.toggleAdminMode(true);
      } else {
        window.location.hash = '#admin';
      }
    } catch {
      window.location.hash = '#admin';
    }
  };

  // Backwards-compatible alias for onSubmit handler
  const handleSubmitInquiry = onSubmit;

  const handleDeleteSavedEnquiry = (id: string) => {
    try {
      const updated = savedEnquiries.filter((item) => item.id !== id);
      localStorage.setItem('hotel_sai_maya_banquet_enquiries', JSON.stringify(updated));
      setSavedEnquiries(updated);
      if (latestSavedEnquiry && latestSavedEnquiry.id === id) {
        setLatestSavedEnquiry(null);
      }
    } catch (err) {
      console.error('Failed to delete enquiry from localStorage:', err);
    }
  };

  const handleScrollToForm = () => {
    const el = document.getElementById('banquet-inquiry-form');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCalendarDateSelect = (dateStr: string) => {
    setFormData((prev) => ({ ...prev, eventDate: dateStr }));
    handleScrollToForm();
  };

  const handleCalendarWhatsAppInquiry = (dateStr: string, note?: string) => {
    const text = `Namaskar Hotel Sai Maya! I am inquiring about Banquet Hall availability for an event on ${dateStr}${note ? ` (${note})` : ''}. Please share slot details and satvik catering options.`;
    window.open(`https://wa.me/${RESTAURANT_METADATA.whatsappNumber}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handlePackageSelect = (tierName: string) => {
    setFormData((prev) => {
      const existingReqs = prev.additionalRequirements || '';
      const cleanReqs = existingReqs.replace(/Selected Tier: [^|]+(\| )?/, '').trim();
      return {
        ...prev,
        additionalRequirements: cleanReqs
          ? `Selected Tier: ${tierName} | ${cleanReqs}`
          : `Selected Tier: ${tierName}`
      };
    });
  };

  const handleLayoutSelect = (layoutName: string, capacity: string) => {
    setFormData((prev) => {
      const existingReqs = prev.additionalRequirements || '';
      const cleanReqs = existingReqs.replace(/Preferred Seating: [^|]+(\| )?/, '').trim();
      return {
        ...prev,
        additionalRequirements: cleanReqs
          ? `Preferred Seating: ${layoutName} (${capacity}) | ${cleanReqs}`
          : `Preferred Seating: ${layoutName} (${capacity})`
      };
    });
  };

  return (
    <section
      id="banquet"
      className="relative py-20 sm:py-28 bg-[#0a0a0c] border-t border-b border-white/10 overflow-hidden text-white"
    >
      {/* Background ambient lighting vignette */}
      <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-[#dfbb76]/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[500px] h-[500px] bg-emerald-900/5 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10 space-y-16 sm:space-y-20">
        {/* ============================================================ */}
        {/* 1. Header & Context Disclaimer */}
        {/* ============================================================ */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1c1a16] border border-[#dfbb76]/30 text-[#e6ca92] text-xs font-mono uppercase tracking-widest shadow-sm">
            <span className="text-base">🏛️</span>
            <span>Banquet Hall & Events</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#dfbb76] animate-pulse" />
          </div>

          <h2 className="font-playfair text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            Celebrate Your Special Moments at <br className="hidden sm:inline" />
            <span className="gold-text-glow text-transparent bg-clip-text bg-gradient-to-r from-[#dfbb76] via-[#f7e7c4] to-[#c5a059]">
              Hotel Sai Maya
            </span>
          </h2>

          <p className="text-sm sm:text-base text-[#a1a1aa] font-sans-ui leading-relaxed max-w-2xl mx-auto">
            A comfortable venue for <strong className="text-white font-medium">family celebrations, social gatherings and special occasions</strong>,
            supported by convenient dining and easy access for guests along the Shirdi pilgrimage corridor.
          </p>

          {/* Development / Verification Notice */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#16161a] border border-white/10 text-[11px] text-[#a1a1aa] font-mono">
            <AlertCircle className="w-3.5 h-3.5 text-[#dfbb76] shrink-0" />
            <span>Development Preview: Specific hall capacity, packages & pricing are marked as <strong>To be confirmed (TBC)</strong> pending final venue verification.</span>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 2. Visual Layout: Large Premium Split Section */}
        {/* ============================================================ */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center bg-[#121215]/80 p-6 sm:p-8 md:p-10 rounded-2xl border border-white/10 shadow-2xl relative">
          {/* Left: Large Banquet Hall Photograph */}
          <div className="lg:col-span-6 relative group overflow-hidden rounded-xl border border-white/10 aspect-[4/3] bg-[#1a1a1e]">
            <img
              src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=85"
              alt="Hotel Sai Maya Banquet Celebration Hall"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0e] via-[#0c0c0e]/30 to-transparent pointer-events-none" />

            {/* Overlaid Badges */}
            <div className="absolute top-4 left-4 flex flex-col gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-[#dfbb76]/40 text-[#dfbb76] text-xs font-mono font-medium shadow-md">
                <Sparkle className="w-3 h-3 text-[#dfbb76]" />
                Sanctuary Event Venue
              </span>
            </div>

            <div className="absolute bottom-4 inset-x-4 flex items-center justify-between text-xs text-white/90 bg-black/60 backdrop-blur-md px-4 py-2.5 rounded-lg border border-white/10 font-mono">
              <span className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#dfbb76]" />
                Event Space Specification
              </span>
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px]">
                Capacity: To be confirmed
              </span>
            </div>
          </div>

          {/* Right: Narrative & CTAs */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-3">
              <span className="text-xs font-mono tracking-[0.25em] text-[#dfbb76] uppercase">
                PRIVATE & FAMILY GATHERINGS
              </span>
              <blockquote className="font-playfair text-2xl sm:text-3xl text-white font-semibold leading-snug border-l-2 border-[#dfbb76] pl-4 italic">
                “Your Occasion. Your People. Your Moment.”
              </blockquote>
            </div>

            <p className="text-sm text-[#a1a1aa] leading-relaxed font-sans-ui">
              Whether you are bringing generations of family together for a sacred Shirdi pilgrimage celebration, marking an auspicious milestone, or hosting an intimate post-darshan feast, Hotel Sai Maya offers a dedicated, comfortable setting paired with our renowned pure-vegetarian dining hospitality.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2 text-xs font-mono text-[#a1a1aa]">
              <div className="p-3 rounded-lg bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[#dfbb76] block font-semibold">Catering Type</span>
                <span className="text-white">100% Satvik Pure Veg</span>
              </div>
              <div className="p-3 rounded-lg bg-white/[0.02] border border-white/5 space-y-1">
                <span className="text-[#dfbb76] block font-semibold">Hall Packages</span>
                <span className="text-amber-300">To be confirmed</span>
              </div>
            </div>

            {/* CTAs */}
            <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={handleScrollToForm}
                className="gold-btn py-3 px-6 rounded-xl font-cinzel font-semibold text-xs tracking-wider uppercase text-black flex items-center justify-center gap-2 shadow-lg"
              >
                <span>CHECK AVAILABILITY</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleScrollToForm}
                className="bg-white/5 hover:bg-white/10 text-[#dfbb76] border border-[#dfbb76]/40 py-3 px-6 rounded-xl font-cinzel font-semibold text-xs tracking-wider uppercase flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <BookmarkCheck className="w-4 h-4 text-[#dfbb76]" />
                <span>PLAN CELEBRATION</span>
              </button>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* Horizontal Gallery: Hall → Seating → Dining → Decoration → Event Setup */}
        {/* ============================================================ */}
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-[#dfbb76] block">
                VISUAL WALKTHROUGH
              </span>
              <h3 className="font-playfair text-xl sm:text-2xl text-white font-bold">
                Hall → Seating → Dining → Decoration → Event Setup
              </h3>
            </div>
            <p className="text-xs text-[#a1a1aa] font-mono">
              Select stage to explore venue arrangements
            </p>
          </div>

          {/* Stage selector tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {BANQUET_GALLERY_STAGES.map((stage, idx) => {
              const isActive = stage.id === activeStageId;
              return (
                <button
                  key={stage.id}
                  onClick={() => setActiveStageId(stage.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono transition-all whitespace-nowrap border ${
                    isActive
                      ? 'bg-[#dfbb76] text-black font-semibold border-[#dfbb76] shadow-md'
                      : 'bg-[#141417] text-[#a1a1aa] hover:text-white border-white/10 hover:border-white/20'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                    isActive ? 'bg-black text-[#dfbb76]' : 'bg-white/10 text-white'
                  }`}>
                    {idx + 1}
                  </span>
                  <span>{stage.label}</span>
                </button>
              );
            })}
          </div>

          {/* Active Stage Display Card */}
          <div className="bg-[#121215] border border-white/10 rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12">
            <div className="md:col-span-7 relative h-72 sm:h-96 md:h-full min-h-[300px] overflow-hidden bg-[#1a1a1e]">
              <img
                src={activeStage.image}
                alt={activeStage.title}
                className="w-full h-full object-cover transition-all duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-[#121215]/80 hidden md:block" />
              <div className="absolute bottom-3 left-3 px-3 py-1 rounded-md bg-black/80 backdrop-blur-sm border border-white/10 text-[11px] font-mono text-[#e6ca92]">
                Stage {BANQUET_GALLERY_STAGES.findIndex(s => s.id === activeStage.id) + 1} of 5: {activeStage.label}
              </div>
            </div>

            <div className="md:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] font-mono">
                  <AlertCircle className="w-3 h-3" />
                  <span>{activeStage.statusNote}</span>
                </div>

                <h4 className="font-playfair text-2xl text-white font-bold">
                  {activeStage.title}
                </h4>

                <p className="text-xs sm:text-sm text-[#a1a1aa] leading-relaxed font-sans-ui">
                  {activeStage.description}
                </p>

                <div className="space-y-2 text-xs text-[#a1a1aa] font-mono pt-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Pure-veg custom banquet dining coordination</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Dedicated parking for all guest vehicles</span>
                  </div>
                  <div className="flex items-center gap-2 text-amber-300/80">
                    <HelpCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>A/V, stage lighting & audio (To be confirmed)</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <button
                  onClick={handleScrollToForm}
                  className="text-xs text-[#dfbb76] font-mono font-medium hover:underline flex items-center gap-1"
                >
                  <span>Inquire for this setup</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
                <button
                  onClick={() => {
                    handlePackageSelect(activeStage.title);
                    handleScrollToForm();
                  }}
                  className="text-xs text-amber-300 font-mono hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <Sparkle className="w-3.5 h-3.5 text-[#dfbb76]" />
                  <span>Select & Fill Form</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 3. 🌐 Interactive 360° Virtual Tour Panorama */}
        {/* ============================================================ */}
        <div id="banquet-virtual-tour" className="scroll-mt-28">
          <BanquetPanoramaViewer />
        </div>

        {/* ============================================================ */}
        {/* 4. 📐 Interactive Seating Layout Selector (Theater, U-Shape, Banquet) */}
        {/* ============================================================ */}
        <div id="banquet-layouts" className="scroll-mt-28">
          <BanquetSeatLayoutSelector onSelectLayout={handleLayoutSelect} />
        </div>

        {/* ============================================================ */}
        {/* 5. Event Types Grid */}
        {/* ============================================================ */}
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <span className="text-[11px] font-mono uppercase tracking-widest text-[#dfbb76]">
              TAILORED OCCASIONS
            </span>
            <h3 className="font-playfair text-2xl sm:text-3xl text-white font-bold">
              Celebrate Meaningful Gatherings
            </h3>
            <p className="text-xs sm:text-sm text-[#a1a1aa]">
              Versatile hall spaces ready to accommodate family festivities and private milestones.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {eventTypes.map((evt, idx) => (
              <div
                key={idx}
                className="p-5 sm:p-6 rounded-xl bg-[#121215] border border-white/10 hover:border-[#dfbb76]/40 transition-all duration-300 flex flex-col justify-between space-y-4 group"
              >
                <div className="space-y-3">
                  <div className="w-10 h-10 rounded-lg bg-[#1a1a20] border border-white/10 flex items-center justify-center group-hover:border-[#dfbb76]/30 transition-colors">
                    {evt.icon}
                  </div>
                  <h4 className="font-cinzel text-base font-bold text-white group-hover:text-[#dfbb76] transition-colors">
                    {evt.title}
                  </h4>
                  <p className="text-xs text-[#a1a1aa] leading-relaxed">
                    {evt.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#dfbb76]">
                  <span className="text-white/50">{evt.capacityNote}</span>
                  <button
                    onClick={() => {
                      setFormData((prev) => ({ ...prev, eventType: evt.type }));
                      handleScrollToForm();
                    }}
                    className="hover:underline flex items-center gap-0.5"
                  >
                    <span>Book</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ============================================================ */}
        {/* 4. ✨ What Guests Can Expect (Icon Cards) */}
        {/* ============================================================ */}
        <div className="space-y-6">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-[11px] font-mono uppercase tracking-widest text-[#dfbb76]">
              AMENITIES & HOSPITALITY
            </span>
            <h3 className="font-playfair text-2xl sm:text-3xl text-white font-bold">
              ✨ What Guests Can Expect
            </h3>
            <p className="text-xs sm:text-sm text-[#a1a1aa]">
              Verified infrastructure alongside customizable arrangements tailored for your group.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {guestExpectations.map((item, idx) => (
              <div
                key={idx}
                className="p-5 rounded-xl bg-[#121215] border border-white/10 space-y-3 relative"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-lg bg-[#18181c] border border-white/10 flex items-center justify-center">
                    {item.icon}
                  </div>
                  {item.isVerified ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono">
                      <ShieldCheck className="w-3 h-3" />
                      Verified Facility
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-950/60 border border-amber-500/30 text-amber-300 text-[10px] font-mono">
                      <AlertCircle className="w-3 h-3" />
                      {item.unverifiedNote}
                    </span>
                  )}
                </div>

                <h4 className="font-cinzel text-sm font-bold text-white">
                  {item.title}
                </h4>

                <p className="text-xs text-[#a1a1aa] leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* ============================================================ */}
        {/* 7. 💎 Pricing & Package Display Grid (Silver, Gold, Platinum) */}
        {/* ============================================================ */}
        <div id="banquet-packages" className="scroll-mt-28">
          <BanquetPackagesGrid onSelectPackage={handlePackageSelect} />
        </div>

        {/* ============================================================ */}
        {/* 8. 📅 Upcoming Banquet Events & Peak Dates Calendar */}
        {/* ============================================================ */}
        <div id="banquet-calendar" className="scroll-mt-28">
          <BanquetCalendar
            onSelectDate={handleCalendarDateSelect}
            selectedDateStr={formData.eventDate}
            onWhatsAppInquiry={handleCalendarWhatsAppInquiry}
          />
        </div>

        {/* ============================================================ */}
        {/* 6. 💬 Banquet Inquiry Form: "Plan Your Event With Us" */}
        {/* ============================================================ */}
        <div
          id="banquet-inquiry-form"
          className="scroll-mt-28 bg-[#121215] border border-[#dfbb76]/30 rounded-2xl p-6 sm:p-10 shadow-2xl relative"
        >
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="text-center space-y-2">
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#dfbb76]">
                DIRECT RESERVATION DESK
              </span>
              <h3 className="font-playfair text-2xl sm:text-3xl md:text-4xl text-white font-bold">
                Plan Your Event With Us
              </h3>
              <p className="text-xs sm:text-sm text-[#a1a1aa] max-w-xl mx-auto font-sans-ui">
                Submit your proposed celebration details below. Our events concierge will review availability, arrange custom pure-veg menus, and confirm hall specifications with you.
              </p>
            </div>

            {/* Floating Toast Notification */}
            {showToast && successNotification && (
              <aside
                id="banquet-success-toast"
                role="status"
                aria-live="polite"
                aria-label="Banquet inquiry confirmation notification"
                className="fixed top-20 right-4 z-50 max-w-sm sm:max-w-md bg-[#121216]/95 border border-emerald-500/60 rounded-2xl p-4 shadow-2xl backdrop-blur-xl flex items-start gap-3 animate-in slide-in-from-top-4 duration-300"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      ✓ Data Captured
                    </span>
                    <span className="text-[10px] font-mono text-[#dfbb76] font-bold">
                      {successNotification.enquiry.referenceCode}
                    </span>
                  </div>
                  <p className="text-xs text-white/90 font-sans leading-snug">
                    Banquet inquiry saved for <strong className="text-white">{successNotification.enquiry.name}</strong> ({successNotification.enquiry.eventType} on {successNotification.enquiry.eventDate}).
                  </p>
                  <div className="flex items-center justify-between pt-1">
                    <p className="text-[11px] text-[#a1a1aa] font-mono truncate">
                      Coordinator will call {successNotification.enquiry.mobileNumber}
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setShowSuccessModal(true);
                        setModalDismissProgress(100);
                      }}
                      className="text-[11px] text-[#dfbb76] hover:underline font-mono shrink-0 ml-2 cursor-pointer"
                    >
                      Open Modal →
                    </button>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowToast(false)}
                  className="text-white/60 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
                  title="Close Notification"
                >
                  <X className="w-4 h-4" />
                </button>
              </aside>
            )}

            {/* Prominent Success Notification Banner Message */}
            {successNotification && successNotification.show && (
              <div
                id="banquet-success-notification"
                role="alert"
                aria-live="polite"
                className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-[#13221b] to-[#121c17] border-2 border-emerald-500/60 shadow-2xl space-y-4 animate-in fade-in duration-300 text-left"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-emerald-500/30">
                  <div className="flex items-start gap-3.5">
                    <div className="w-11 h-11 rounded-xl bg-emerald-900/80 border border-emerald-400 text-emerald-300 flex items-center justify-center shrink-0 mt-0.5 shadow-lg shadow-emerald-950">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-900/60 border border-emerald-400/40 text-emerald-300 text-[10px] font-mono uppercase tracking-wider font-semibold">
                        <Check className="w-3 h-3 text-emerald-400" />
                        LOCAL STATE RECORDED • NO EXTERNAL NAVIGATION
                      </div>
                      <h4 className="font-playfair text-xl sm:text-2xl text-white font-bold">
                        {successNotification.title}
                      </h4>
                      <p className="text-xs sm:text-sm text-emerald-100 font-sans leading-relaxed">
                        {successNotification.message}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-start shrink-0">
                    <div className="bg-black/50 border border-[#dfbb76]/60 rounded-xl px-3 py-1.5 flex items-center gap-2">
                      <span className="text-[10px] text-[#a1a1aa] font-mono">REF:</span>
                      <span className="font-mono text-xs sm:text-sm font-bold text-[#dfbb76]">
                        {successNotification.enquiry.referenceCode}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(successNotification.enquiry.referenceCode);
                          setCopiedRef(true);
                          setTimeout(() => setCopiedRef(false), 2000);
                        }}
                        className="p-1 rounded bg-white/10 hover:bg-white/20 text-white transition-colors"
                        title="Copy Reference"
                      >
                        {copiedRef ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => setSuccessNotification(null)}
                      className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors cursor-pointer"
                      title="Dismiss Alert"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Quick Guest Information Pill Breakdown */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-xs font-mono">
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-[#a1a1aa] block">GUEST</span>
                    <span className="text-white font-medium truncate block">{successNotification.enquiry.name}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-[#a1a1aa] block">CONTACT</span>
                    <span className="text-emerald-300 font-semibold truncate block">{successNotification.enquiry.mobileNumber}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-[#a1a1aa] block">EVENT TYPE</span>
                    <span className="text-white truncate block">{successNotification.enquiry.eventType}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-[#a1a1aa] block">DATE</span>
                    <span className="text-[#dfbb76] font-bold block">{successNotification.enquiry.eventDate}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-[#a1a1aa] block">GUESTS</span>
                    <span className="text-white block">{successNotification.enquiry.expectedGuests}</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-[#a1a1aa] block">STATUS</span>
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      Saved
                    </span>
                  </div>
                </div>

                {/* Reassurance and Next Step Guidance */}
                <div className="p-3.5 rounded-xl bg-black/50 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5 text-emerald-100">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
                    <span>
                      <strong>Next Step:</strong> Our Banquet Coordinator will connect with you via call/WhatsApp within <strong>2 hours</strong> to finalize dates, hall arrangement, and Satvik catering menu.
                    </span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                    <a
                      href={`https://wa.me/919822076543?text=${encodeURIComponent(`Namaste Hotel Sai Maya! I have submitted a banquet enquiry for ${successNotification.enquiry.eventType} on ${successNotification.enquiry.eventDate}. Reference ID: ${successNotification.enquiry.referenceCode}. Host: ${successNotification.enquiry.name}.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/40 border border-emerald-500/50 text-emerald-300 font-mono text-[11px] flex items-center gap-1.5 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      <span>WhatsApp Coordinator</span>
                    </a>
                    <a
                      href="tel:+919822076543"
                      className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-[11px] flex items-center gap-1.5 transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#dfbb76]" />
                      <span>Call Concierge</span>
                    </a>
                  </div>
                </div>

                {/* Action buttons inside notification */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowReceiptDetail(!showReceiptDetail)}
                      className="py-2 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 text-white font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <FileCheck className="w-3.5 h-3.5 text-[#dfbb76]" />
                      <span>{showReceiptDetail ? 'Hide Full Receipt' : 'View Full Receipt Details'}</span>
                    </button>

                    {savedEnquiries.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setShowSavedListModal(true)}
                        className="py-2 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 text-[#dfbb76] font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <BookmarkCheck className="w-3.5 h-3.5" />
                        <span>Saved Enquiries Register ({savedEnquiries.length})</span>
                      </button>
                    )}

                    <button
                      type="button"
                      id="reopen-floating-success-modal-btn"
                      onClick={() => {
                        setShowSuccessModal(true);
                        setModalDismissProgress(100);
                        setIsModalPaused(false);
                        setIsTimerDisabled(false);
                      }}
                      className="py-2 px-3.5 rounded-xl bg-emerald-600/25 hover:bg-emerald-600/40 border border-emerald-500/50 text-emerald-300 font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="Open the floating success confirmation modal"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>View Confirmation Modal</span>
                    </button>

                    <button
                      type="button"
                      id="view-in-admin-enquiries-btn"
                      onClick={handleOpenAdminEnquiries}
                      className="py-2 px-3.5 rounded-xl bg-[#dfbb76]/20 hover:bg-[#dfbb76]/30 border border-[#dfbb76]/50 text-[#dfbb76] font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="View this inquiry in the Admin Panel Enquiry Manager"
                    >
                      <Shield className="w-3.5 h-3.5 text-[#dfbb76]" />
                      <span>View in Admin Enquiries →</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSuccessNotification(null);
                      handleResetForm();
                    }}
                    className="py-2 px-4 rounded-xl gold-btn text-black font-cinzel font-semibold text-xs tracking-wider uppercase flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>+ Clear Form for New Inquiry</span>
                  </button>
                </div>
              </div>
            )}

            {/* Optional Full Detailed Confirmation Card */}
            {showReceiptDetail && latestSavedEnquiry && (
              <div className="p-6 sm:p-8 rounded-2xl bg-[#151519] border border-emerald-500/40 text-left space-y-6 animate-in fade-in zoom-in duration-300 shadow-2xl">
                {/* Verified Header & Booking Ref */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
                  <div className="flex items-center gap-3.5">
                    <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-emerald-950/90 border border-emerald-500/60 text-emerald-400 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-950/60">
                      <BookmarkCheck className="w-7 h-7" />
                    </div>
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono uppercase tracking-wider mb-1 font-semibold">
                        <Check className="w-3 h-3 text-emerald-400" />
                        ENQUIRY SAVED & REGISTERED
                      </div>
                      <h4 className="font-playfair text-xl sm:text-2xl text-white font-bold">
                        Banquet Event Request Confirmed
                      </h4>
                      <p className="text-xs text-[#a1a1aa] font-mono">
                        Saved in Hotel Sai Maya System • {latestSavedEnquiry.createdAt}
                      </p>
                    </div>
                  </div>

                  {/* Reference ID Badge */}
                  <div className="bg-[#1c1c22] border border-[#dfbb76]/40 rounded-xl p-3 sm:text-right shrink-0">
                    <span className="text-[10px] text-[#a1a1aa] font-mono block uppercase">Booking Reference</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-base sm:text-lg font-bold text-[#dfbb76] tracking-wider">
                        {latestSavedEnquiry.referenceCode}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(latestSavedEnquiry.referenceCode);
                          setCopiedRef(true);
                          setTimeout(() => setCopiedRef(false), 2000);
                        }}
                        className="p-1.5 rounded-md bg-white/5 hover:bg-white/10 text-white/80 hover:text-white transition-colors"
                        title="Copy Reference Code"
                      >
                        {copiedRef ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Saved Information Breakdown Table/Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5 p-4 rounded-xl bg-[#0f0f13] border border-white/5 font-mono text-xs">
                  <div className="space-y-1">
                    <span className="text-[11px] text-[#71717a] uppercase block">Host / Organizer</span>
                    <span className="text-white font-sans font-medium text-sm">{latestSavedEnquiry.name}</span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[11px] text-[#71717a] uppercase block">Contact Mobile</span>
                    <span className="text-[#dfbb76] font-semibold">{latestSavedEnquiry.mobileNumber}</span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[11px] text-[#71717a] uppercase block">Celebration Type</span>
                    <span className="text-white font-sans">{latestSavedEnquiry.eventType}</span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[11px] text-[#71717a] uppercase block">Reserved Event Date</span>
                    <span className="text-emerald-400 font-semibold">{latestSavedEnquiry.eventDate}</span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[11px] text-[#71717a] uppercase block">Expected Guests</span>
                    <span className="text-white font-sans">{latestSavedEnquiry.expectedGuests}</span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[11px] text-[#71717a] uppercase block">Preferred Time Slot</span>
                    <span className="text-white font-sans text-[11px]">{latestSavedEnquiry.preferredTime}</span>
                  </div>
                </div>

                {/* Additional requirements notes */}
                {latestSavedEnquiry.additionalRequirements && (
                  <div className="p-4 rounded-xl bg-[#0f0f13] border border-white/5 space-y-1">
                    <span className="text-[10px] font-mono text-[#71717a] uppercase block">Saved Package & Catering Specifications</span>
                    <p className="text-xs text-white/90 font-sans leading-relaxed">
                      {latestSavedEnquiry.additionalRequirements}
                    </p>
                  </div>
                )}

                {/* Direct Concierge Confirmation Notice */}
                <div className="flex items-start gap-3 p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-[#c4c4cc]">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-semibold text-white font-sans">
                      Form Data Saved Directly in Sanctuary Register
                    </p>
                    <p className="text-[#a1a1aa] font-sans">
                      Your banquet event enquiry has been permanently recorded in local persistence. Our Banquet Captain will contact you at <strong className="text-white">{latestSavedEnquiry.mobileNumber}</strong> to finalize stage setup and Satvik menu options.
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-mono flex items-center gap-2 transition-colors cursor-pointer"
                    >
                      <Download className="w-4 h-4 text-[#dfbb76]" />
                      <span>Print Confirmation</span>
                    </button>
                    {savedEnquiries.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setShowSavedListModal(true)}
                        className="py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-[#dfbb76] font-mono flex items-center gap-2 transition-colors cursor-pointer"
                      >
                        <FileCheck className="w-4 h-4" />
                        <span>View Saved Register ({savedEnquiries.length})</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={handleOpenAdminEnquiries}
                      className="py-2.5 px-4 rounded-xl bg-[#dfbb76]/20 hover:bg-[#dfbb76]/30 border border-[#dfbb76]/40 text-xs text-[#dfbb76] font-mono flex items-center gap-2 transition-colors cursor-pointer"
                      title="Open Central Admin Panel Enquiry Section"
                    >
                      <Shield className="w-4 h-4" />
                      <span>View in Admin Enquiries →</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowReceiptDetail(false)}
                    className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-mono transition-colors cursor-pointer"
                  >
                    <span>Close Receipt Details</span>
                  </button>
                </div>
              </div>
            )}

            <form id="banquet-inquiry-form-element" onSubmit={onSubmit} noValidate className="space-y-6">
                {/* Auto-Fill / Quick Test Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-white/[0.03] border border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#dfbb76] animate-pulse" />
                    <span className="text-xs text-[#a1a1aa] font-mono">
                      Fast-Track Banquet Booking:
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      id="quick-fill-enquiry-btn"
                      onClick={handleQuickFillSample}
                      className="px-3.5 py-1.5 rounded-lg bg-[#dfbb76]/20 hover:bg-[#dfbb76]/30 border border-[#dfbb76]/50 text-[#dfbb76] hover:text-white text-xs font-mono font-semibold transition-all flex items-center gap-1.5 hover:scale-105 active:scale-95 shadow-sm"
                      title="Click to automatically populate the form with realistic event details"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#dfbb76]" />
                      <span>✨ Auto-Fill Sample Enquiry</span>
                    </button>
                    {(formData.name || formData.mobileNumber || formData.eventDate) && (
                      <button
                        type="button"
                        id="reset-enquiry-btn"
                        onClick={handleResetForm}
                        className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#a1a1aa] hover:text-white text-xs font-mono transition-colors flex items-center gap-1"
                        title="Clear all fields"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Clear</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Validation Error Summary Alert Banner */}
                {submitAttempted && Object.keys(formErrors).length > 0 && (
                  <div
                    id="banquet-validation-alert"
                    role="alert"
                    aria-live="assertive"
                    className="p-4 rounded-xl bg-rose-950/70 border border-rose-500/60 text-rose-200 text-xs font-mono space-y-2 animate-in fade-in slide-in-from-top-2 shadow-xl"
                  >
                    <div className="flex items-center gap-2 text-rose-300 font-semibold text-sm">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>Please correct the required fields to submit your enquiry:</span>
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-rose-200/90 pl-1 text-[11px] sm:text-xs">
                      {formErrors.name && <li><strong>Host Name:</strong> {formErrors.name}</li>}
                      {formErrors.mobileNumber && <li><strong>Mobile:</strong> {formErrors.mobileNumber}</li>}
                      {formErrors.eventDate && <li><strong>Event Date:</strong> {formErrors.eventDate}</li>}
                      {formErrors.expectedGuests && <li><strong>Expected Guests:</strong> {formErrors.expectedGuests}</li>}
                    </ul>
                  </div>
                )}

                {/* Auto-fill notification alert */}
                {autoFilledNotice && (
                  <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-300 text-xs font-mono flex items-center justify-between gap-2 animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Sample details loaded! You can modify any field or click the <strong>Submit</strong> button below.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setAutoFilledNotice(false)}
                      className="text-emerald-400/70 hover:text-emerald-300 text-[10px]"
                    >
                      ✕
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name */}
                  <div className="space-y-1.5">
                    <label htmlFor="enquiry-name" className="text-xs font-mono text-[#a1a1aa] block flex items-center justify-between">
                      <span>Full Name <span className="text-rose-400">*</span></span>
                      {formData.name && !formErrors.name && (
                        <span className="text-[10px] text-emerald-400 font-mono">✓ Filled</span>
                      )}
                    </label>
                    <input
                      id="enquiry-name"
                      type="text"
                      required
                      placeholder="e.g. Rajesh Patil"
                      value={formData.name}
                      onChange={(e) => handleFieldChange('name', e.target.value)}
                      onBlur={() => handleBlur('name')}
                      aria-invalid={Boolean(formErrors.name && (touchedFields.name || submitAttempted))}
                      aria-describedby={formErrors.name ? 'enquiry-name-error' : undefined}
                      className={`w-full bg-[#18181c] border rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-white/20 focus:outline-none transition-colors ${
                        formErrors.name && (touchedFields.name || submitAttempted)
                          ? 'border-rose-500/80 focus:border-rose-500 bg-rose-950/15 ring-1 ring-rose-500/30'
                          : formData.name && !formErrors.name
                          ? 'border-emerald-500/50 focus:border-emerald-400'
                          : 'border-white/10 focus:border-[#dfbb76]'
                      }`}
                    />
                    {formErrors.name && (touchedFields.name || submitAttempted) && (
                      <p id="enquiry-name-error" className="text-xs text-rose-400 font-mono flex items-center gap-1.5 mt-1 animate-in fade-in">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{formErrors.name}</span>
                      </p>
                    )}
                  </div>

                  {/* Mobile Number */}
                  <div className="space-y-1.5">
                    <label htmlFor="enquiry-phone" className="text-xs font-mono text-[#a1a1aa] block flex items-center justify-between">
                      <span>Mobile Number <span className="text-rose-400">*</span></span>
                      {formData.mobileNumber && !formErrors.mobileNumber && (
                        <span className="text-[10px] text-emerald-400 font-mono">✓ Filled</span>
                      )}
                    </label>
                    <input
                      id="enquiry-phone"
                      type="tel"
                      required
                      placeholder="e.g. +91 98220 76543"
                      value={formData.mobileNumber}
                      onChange={(e) => handleFieldChange('mobileNumber', e.target.value)}
                      onBlur={() => handleBlur('mobileNumber')}
                      aria-invalid={Boolean(formErrors.mobileNumber && (touchedFields.mobileNumber || submitAttempted))}
                      aria-describedby={formErrors.mobileNumber ? 'enquiry-phone-error' : undefined}
                      className={`w-full bg-[#18181c] border rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-white/20 focus:outline-none transition-colors ${
                        formErrors.mobileNumber && (touchedFields.mobileNumber || submitAttempted)
                          ? 'border-rose-500/80 focus:border-rose-500 bg-rose-950/15 ring-1 ring-rose-500/30'
                          : formData.mobileNumber && !formErrors.mobileNumber
                          ? 'border-emerald-500/50 focus:border-emerald-400'
                          : 'border-white/10 focus:border-[#dfbb76]'
                      }`}
                    />
                    {formErrors.mobileNumber && (touchedFields.mobileNumber || submitAttempted) && (
                      <p id="enquiry-phone-error" className="text-xs text-rose-400 font-mono flex items-center gap-1.5 mt-1 animate-in fade-in">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{formErrors.mobileNumber}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Event Type */}
                  <div className="space-y-1.5">
                    <label htmlFor="enquiry-event-type" className="text-xs font-mono text-[#a1a1aa] block">
                      Event Type <span className="text-rose-400">*</span>
                    </label>
                    <select
                      id="enquiry-event-type"
                      value={formData.eventType}
                      onChange={(e) => handleFieldChange('eventType', e.target.value as BanquetEventType)}
                      className="w-full bg-[#18181c] border border-white/10 rounded-xl px-3 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-[#dfbb76] transition-colors"
                    >
                      <option value="Birthday Celebrations">🎂 Birthday Celebrations</option>
                      <option value="Engagement & Family Functions">💍 Engagement & Family Functions</option>
                      <option value="Family Get-Togethers">👨‍👩‍👧‍👦 Family Get-Togethers</option>
                      <option value="Meetings & Small Events">🏢 Meetings & Small Events</option>
                      <option value="Other Occasions">✨ Other Occasions</option>
                    </select>
                  </div>

                  {/* Event Date */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-[#a1a1aa] block flex items-center justify-between">
                      <span>Event Date <span className="text-rose-400">*</span></span>
                      {formData.eventDate && !formErrors.eventDate && (
                        <span className="text-[10px] text-emerald-400 font-mono">✓ {formData.eventDate}</span>
                      )}
                    </label>
                    <div className={`rounded-xl transition-all ${
                      formErrors.eventDate && (touchedFields.eventDate || submitAttempted)
                        ? 'ring-1 ring-rose-500/80 rounded-xl'
                        : ''
                    }`}>
                      <BanquetDatePicker
                        value={formData.eventDate}
                        onChange={(dateStr) => handleFieldChange('eventDate', dateStr)}
                        required
                      />
                    </div>
                    {formErrors.eventDate && (touchedFields.eventDate || submitAttempted) && (
                      <p id="enquiry-date-error" className="text-xs text-rose-400 font-mono flex items-center gap-1.5 mt-1 animate-in fade-in">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{formErrors.eventDate}</span>
                      </p>
                    )}
                  </div>

                  {/* Expected Guests */}
                  <div className="space-y-1.5">
                    <label htmlFor="enquiry-guests" className="text-xs font-mono text-[#a1a1aa] block flex items-center justify-between">
                      <span>Expected Guests</span>
                      <span className="text-[10px] text-amber-300">TBC</span>
                    </label>
                    <input
                      id="enquiry-guests"
                      type="text"
                      placeholder="e.g. 50 - 100 guests"
                      value={formData.expectedGuests}
                      onChange={(e) => handleFieldChange('expectedGuests', e.target.value)}
                      onBlur={() => handleBlur('expectedGuests')}
                      aria-invalid={Boolean(formErrors.expectedGuests && (touchedFields.expectedGuests || submitAttempted))}
                      aria-describedby={formErrors.expectedGuests ? 'enquiry-guests-error' : undefined}
                      className={`w-full bg-[#18181c] border rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-white/20 focus:outline-none transition-colors ${
                        formErrors.expectedGuests && (touchedFields.expectedGuests || submitAttempted)
                          ? 'border-rose-500/80 focus:border-rose-500 bg-rose-950/15 ring-1 ring-rose-500/30'
                          : 'border-white/10 focus:border-[#dfbb76]'
                      }`}
                    />
                    {formErrors.expectedGuests && (touchedFields.expectedGuests || submitAttempted) && (
                      <p id="enquiry-guests-error" className="text-xs text-rose-400 font-mono flex items-center gap-1.5 mt-1 animate-in fade-in">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{formErrors.expectedGuests}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Preferred Time */}
                <div className="space-y-1.5">
                  <label htmlFor="enquiry-time-slot" className="text-xs font-mono text-[#a1a1aa] block">
                    Preferred Time Slot
                  </label>
                  <select
                    id="enquiry-time-slot"
                    value={formData.preferredTime}
                    onChange={(e) => handleFieldChange('preferredTime', e.target.value as any)}
                    className="w-full bg-[#18181c] border border-white/10 rounded-xl px-3 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-[#dfbb76] transition-colors"
                  >
                    <option value="Morning / Lunch (10:00 AM – 3:00 PM)">Morning / Lunch (10:00 AM – 3:00 PM)</option>
                    <option value="Evening / Dinner (6:00 PM – 11:00 PM)">Evening / Dinner (6:00 PM – 11:00 PM)</option>
                    <option value="Full Day Slot">Full Day Slot</option>
                    <option value="Flexible">Flexible / Timing to be discussed</option>
                  </select>
                </div>

                {/* Additional Requirements */}
                <div className="space-y-1.5">
                  <label htmlFor="enquiry-requirements" className="text-xs font-mono text-[#a1a1aa] block">
                    Additional Requirements & Catering Preferences
                  </label>
                  <textarea
                    id="enquiry-requirements"
                    rows={3}
                    placeholder="e.g., Jain satvik buffet counter, elder-friendly seating, audio mic setup, special dessert arrangements..."
                    value={formData.additionalRequirements}
                    onChange={(e) => handleFieldChange('additionalRequirements', e.target.value)}
                    className="w-full bg-[#18181c] border border-white/10 rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-white/20 focus:outline-none focus:border-[#dfbb76] transition-colors resize-none"
                  />
                  <p className="text-[11px] text-[#71717a] font-mono">
                    * Note: Audio-visual setup, floral decorations, and customized packages are subject to availability and will be confirmed during consultation.
                  </p>
                </div>

                {/* Form Submission Actions & Prominent Submit Button */}
                <div className="pt-4 border-t border-white/10 space-y-4">
                  {/* Readiness status bar with state validation feedback */}
                  <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-[#16161a] border border-white/5 text-xs font-mono">
                    <div className="flex items-center gap-2.5 text-[#a1a1aa]">
                      <span>Checklist:</span>
                      <span className={formErrors.name && (touchedFields.name || submitAttempted) ? 'text-rose-400 font-semibold' : formData.name && !formErrors.name ? 'text-emerald-400 font-semibold' : 'text-amber-400/80'}>
                        Name {formErrors.name && (touchedFields.name || submitAttempted) ? '✗' : formData.name && !formErrors.name ? '✓' : '•'}
                      </span>
                      <span>·</span>
                      <span className={formErrors.mobileNumber && (touchedFields.mobileNumber || submitAttempted) ? 'text-rose-400 font-semibold' : formData.mobileNumber && !formErrors.mobileNumber ? 'text-emerald-400 font-semibold' : 'text-amber-400/80'}>
                        Mobile {formErrors.mobileNumber && (touchedFields.mobileNumber || submitAttempted) ? '✗' : formData.mobileNumber && !formErrors.mobileNumber ? '✓' : '•'}
                      </span>
                      <span>·</span>
                      <span className={formErrors.eventDate && (touchedFields.eventDate || submitAttempted) ? 'text-rose-400 font-semibold' : formData.eventDate && !formErrors.eventDate ? 'text-emerald-400 font-semibold' : 'text-amber-400/80'}>
                        Date {formErrors.eventDate && (touchedFields.eventDate || submitAttempted) ? '✗' : formData.eventDate && !formErrors.eventDate ? '✓' : '•'}
                      </span>
                    </div>

                    {formData.name && formData.mobileNumber && formData.eventDate && !formErrors.name && !formErrors.mobileNumber && !formErrors.eventDate ? (
                      <span className="text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-0.5 rounded-full text-[11px] flex items-center gap-1 font-semibold">
                        <Check className="w-3 h-3 text-emerald-400" />
                        Validated & Ready to Submit!
                      </span>
                    ) : (
                      <span className="text-amber-400/80 text-[11px]">
                        Please fill required * fields with valid details
                      </span>
                    )}
                  </div>

                  {/* Dedicated Save & Submit Button */}
                  <div className="space-y-3">
                    <button
                      id="banquet-submit-btn"
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 px-6 rounded-xl font-cinzel font-bold text-sm sm:text-base tracking-wider uppercase text-black bg-gradient-to-r from-[#dfbb76] via-[#f7e7c4] to-[#dfbb76] hover:from-[#f7e7c4] hover:to-[#dfbb76] flex items-center justify-center gap-2.5 shadow-2xl hover:shadow-[#dfbb76]/30 hover:scale-[1.01] active:scale-[0.99] transition-all disabled:opacity-50 cursor-pointer border border-[#dfbb76]"
                    >
                      {isSubmitting ? (
                        <span className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                          <span>SAVING & RECORDING ENQUIRY...</span>
                        </span>
                      ) : (
                        <>
                          <BookmarkCheck className="w-5 h-5 text-black" />
                          <span>SAVE & SUBMIT BANQUET ENQUIRY</span>
                        </>
                      )}
                    </button>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] font-mono text-[#71717a]">
                      <span className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        Direct Local Database Recording • No External Messaging Required
                      </span>

                      {savedEnquiries.length > 0 && (
                        <button
                          type="button"
                          id="view-saved-enquiries-btn"
                          onClick={() => setShowSavedListModal(true)}
                          className="text-[#dfbb76] hover:text-white underline flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <FileCheck className="w-3.5 h-3.5 text-[#dfbb76]" />
                          <span>View Saved Enquiries ({savedEnquiries.length})</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <p className="text-center text-[11px] font-mono text-[#71717a]">
                    🔒 Pure Satvik & Jain Certified Catering • Recorded directly in Hotel Sai Maya reservation system.
                  </p>
                </div>
              </form>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 6. 🔥 Strong Conversion Banner (Bottom of the section) */}
        {/* ============================================================ */}
        <div className="relative rounded-2xl overflow-hidden border border-[#dfbb76]/30 bg-gradient-to-r from-[#171410] via-[#1c1813] to-[#12141a] p-8 sm:p-12 shadow-2xl">
          <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-[#dfbb76]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-3 text-center md:text-left max-w-xl">
              <span className="text-xs font-mono tracking-widest text-[#dfbb76] uppercase">
                HOTEL SAI MAYA CELEBRATIONS DESK
              </span>
              <h3 className="font-playfair text-2xl sm:text-3xl md:text-4xl text-white font-bold leading-tight">
                Planning a Celebration? <br className="hidden sm:inline" />
                Let's Make It Special.
              </h3>
              <p className="text-sm text-[#a1a1aa] font-sans-ui">
                Save your inquiry using our online form and our banquet team will coordinate your arrangements.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 w-full md:w-auto">
              <a
                href={`tel:${RESTAURANT_METADATA.phone.replace(/[^0-9+]/g, '')}`}
                className="w-full sm:w-auto gold-btn py-3.5 px-7 rounded-xl font-cinzel font-semibold text-xs tracking-wider uppercase text-black flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <Phone className="w-4 h-4" />
                <span>📞 Call Concierge</span>
              </a>

              <button
                type="button"
                onClick={handleScrollToForm}
                className="w-full sm:w-auto bg-white/5 hover:bg-white/10 text-[#dfbb76] border border-[#dfbb76]/40 py-3.5 px-7 rounded-xl font-cinzel font-semibold text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <BookmarkCheck className="w-4 h-4" />
                <span>Fill Enquiry Form</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 🎉 Modal: Floating Success Confirmation Modal */}
      {/* ============================================================ */}
      {showSuccessModal && (latestSavedEnquiry || successNotification?.enquiry) && (() => {
        const item = latestSavedEnquiry || successNotification!.enquiry;
        return (
          <div
            id="banquet-success-modal-backdrop"
            role="dialog"
            aria-modal="true"
            aria-labelledby="success-modal-title"
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setShowSuccessModal(false);
              }
            }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
          >
            <div
              id="banquet-success-modal"
              onMouseEnter={() => setIsModalPaused(true)}
              onMouseLeave={() => setIsModalPaused(false)}
              className="relative w-full max-w-xl bg-gradient-to-b from-[#1c1c24] via-[#141418] to-[#0f0f13] border-2 border-emerald-400/80 rounded-3xl shadow-[0_25px_80px_rgba(0,0,0,0.95),0_0_55px_rgba(16,185,129,0.35)] overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col"
            >
              {/* Top Accent Gradient Ribbon */}
              <div className="h-1.5 w-full bg-gradient-to-r from-emerald-400 via-[#dfbb76] to-emerald-400 animate-pulse" />

              {/* Floating Success Header */}
              <div className="p-6 pb-4 border-b border-emerald-500/20 bg-gradient-to-r from-emerald-950/50 via-[#16221d]/40 to-transparent flex items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="relative">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-950/90 border-2 border-emerald-400 text-emerald-300 flex items-center justify-center shrink-0 shadow-xl shadow-emerald-950/70">
                      <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                    </div>
                    <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-black" />
                    </span>
                  </div>
                  <div>
                    <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-emerald-900/70 border border-emerald-400/50 text-emerald-300 text-[10px] font-mono uppercase tracking-wider font-semibold mb-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>INQUIRY CAPTURED & REGISTERED</span>
                    </div>
                    <h3 id="success-modal-title" className="font-playfair text-xl sm:text-2xl font-bold text-white tracking-wide">
                      Banquet Enquiry Confirmed!
                    </h3>
                    <p className="text-xs text-emerald-200/90 font-sans mt-0.5">
                      Hotel Sai Maya Reservations Desk • Shirdi
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  id="close-success-modal-btn"
                  onClick={() => setShowSuccessModal(false)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer"
                  title="Dismiss Modal (ESC)"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body: Captured Details & Visual Feedback */}
              <div className="p-6 space-y-4 font-sans text-xs max-h-[60vh] overflow-y-auto">
                <p className="text-xs sm:text-sm text-emerald-100 font-sans leading-relaxed">
                  Namaste <strong className="text-white font-semibold">{item.name}</strong>! Your banquet inquiry has been successfully captured and registered into the Hotel Sai Maya reservation system.
                </p>

                {/* Booking Reference Code Highlight Ticket */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-black/80 to-[#181820] border-2 border-[#dfbb76]/60 flex items-center justify-between gap-3 shadow-inner">
                  <div>
                    <span className="text-[10px] font-mono text-[#a1a1aa] block uppercase tracking-wider">
                      Official Booking Reference
                    </span>
                    <span className="font-mono text-lg sm:text-xl font-bold text-[#dfbb76] tracking-wider block mt-0.5">
                      {item.referenceCode}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 mt-0.5">
                      <Check className="w-3 h-3 text-emerald-400" />
                      Status: Active in Hotel Database
                    </span>
                  </div>

                  <button
                    type="button"
                    id="modal-copy-ref-btn"
                    onClick={() => {
                      navigator.clipboard.writeText(item.referenceCode);
                      setCopiedRef(true);
                      setTimeout(() => setCopiedRef(false), 2000);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-white/15 active:scale-95"
                  >
                    {copiedRef ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span className="text-emerald-400 font-bold">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 text-[#dfbb76]" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Data Summary Grid */}
                <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/5">
                    <span className="text-[10px] text-[#71717a] block uppercase tracking-wider">Host / Contact</span>
                    <span className="text-white font-semibold block truncate mt-0.5">{item.name}</span>
                    <span className="text-emerald-400 text-[11px] block">{item.mobileNumber}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/5">
                    <span className="text-[10px] text-[#71717a] block uppercase tracking-wider">Event & Date</span>
                    <span className="text-white font-semibold block truncate mt-0.5">{item.eventType}</span>
                    <span className="text-[#dfbb76] text-[11px] font-bold block">{item.eventDate}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/5">
                    <span className="text-[10px] text-[#71717a] block uppercase tracking-wider">Guests & Time Slot</span>
                    <span className="text-white block truncate mt-0.5">{item.expectedGuests}</span>
                    <span className="text-[#a1a1aa] text-[11px] block truncate">{item.preferredTime}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/5">
                    <span className="text-[10px] text-[#71717a] block uppercase tracking-wider">Registry Sync</span>
                    <span className="text-emerald-400 font-semibold flex items-center gap-1.5 mt-0.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      Captured & Synced
                    </span>
                    <span className="text-[10px] text-[#a1a1aa] block mt-0.5">Admin Desk Synced</span>
                  </div>
                </div>

                {/* Coordinator SLA Notice with WhatsApp Link */}
                <div className="p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-100 text-xs space-y-2">
                  <div className="flex items-start gap-2.5">
                    <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">
                      <strong>Immediate Coordinator SLA:</strong> Our Banquet Coordinator will call you at <strong>{item.mobileNumber}</strong> within <strong>2 hours</strong> to review hall seating, stage audio-visual decor, and pure Satvik catering menu selections.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 pt-1 border-t border-emerald-500/20">
                    <a
                      href={`https://wa.me/919822076543?text=${encodeURIComponent(`Namaste Hotel Sai Maya! I have submitted a banquet enquiry for ${item.eventType} on ${item.eventDate}. Reference ID: ${item.referenceCode}. Host: ${item.name}.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/40 text-emerald-300 font-mono text-[11px] flex items-center gap-1.5 transition-colors border border-emerald-500/40"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      <span>WhatsApp Coordinator Now</span>
                    </a>
                    <a
                      href="tel:+919822076543"
                      className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-[11px] flex items-center gap-1.5 transition-colors border border-white/10"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#dfbb76]" />
                      <span>+91 98220 76543</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="p-4 border-t border-white/10 bg-[#141418] flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    id="modal-view-receipt-btn"
                    onClick={() => {
                      setShowSuccessModal(false);
                      setShowReceiptDetail(true);
                      setTimeout(() => {
                        const el = document.getElementById('banquet-success-notification');
                        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }, 100);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-white/10"
                  >
                    <FileCheck className="w-3.5 h-3.5 text-[#dfbb76]" />
                    <span>View Full Receipt</span>
                  </button>

                  <button
                    type="button"
                    id="modal-open-admin-btn"
                    onClick={() => {
                      setShowSuccessModal(false);
                      handleOpenAdminEnquiries();
                    }}
                    className="px-3 py-2 rounded-xl bg-[#dfbb76]/20 hover:bg-[#dfbb76]/30 text-[#dfbb76] font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-[#dfbb76]/40"
                    title="View this enquiry in Admin Panel"
                  >
                    <Shield className="w-3.5 h-3.5 text-[#dfbb76]" />
                    <span>Admin Desk →</span>
                  </button>

                  <button
                    type="button"
                    id="modal-toggle-keep-open-btn"
                    onClick={() => setIsTimerDisabled(!isTimerDisabled)}
                    className={`px-3 py-2 rounded-xl font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer border ${
                      isTimerDisabled
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                        : 'bg-white/5 hover:bg-white/10 text-white/70 border-white/10'
                    }`}
                    title={isTimerDisabled ? 'Resume countdown' : 'Keep modal open'}
                  >
                    <span>{isTimerDisabled ? '⏸ Timer Paused' : 'Keep Open'}</span>
                  </button>
                </div>

                <button
                  type="button"
                  id="modal-dismiss-confirm-btn"
                  onClick={() => setShowSuccessModal(false)}
                  className="px-5 py-2.5 rounded-xl gold-btn text-black font-cinzel font-bold text-xs tracking-wider uppercase flex items-center gap-1.5 cursor-pointer shadow-lg active:scale-95"
                >
                  <Check className="w-4 h-4" />
                  <span>Got it, Thanks!</span>
                </button>
              </div>

              {/* Auto-Dismiss Progress Bar & Countdown Footer */}
              {!isTimerDisabled ? (
                <>
                  <div className="relative w-full h-1.5 bg-white/5 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 via-[#dfbb76] to-emerald-400 transition-all ease-linear"
                      style={{ width: `${modalDismissProgress}%` }}
                    />
                  </div>
                  <div className="px-4 py-1.5 bg-black/70 text-[10px] font-mono text-[#a1a1aa] flex items-center justify-between">
                    <span>Auto-closing in a few seconds...</span>
                    <span className="text-[#dfbb76]">{isModalPaused ? '⏸ Paused (hovering)' : 'Hover to pause • Press ESC to close'}</span>
                  </div>
                </>
              ) : (
                <div className="px-4 py-1.5 bg-black/70 text-[10px] font-mono text-amber-400/90 flex items-center justify-between">
                  <span>Modal kept open for your convenience</span>
                  <button
                    type="button"
                    onClick={() => setIsTimerDisabled(false)}
                    className="underline text-white hover:text-amber-300 cursor-pointer"
                  >
                    Resume auto-close
                  </button>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* ============================================================ */}
      {/* 📋 Modal: Saved Banquet Enquiries Register */}
      {/* ============================================================ */}
      {showSavedListModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-[#141418] border border-[#dfbb76]/40 rounded-3xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col">
            {/* Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#141418] to-[#1c1c22]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#dfbb76]/20 border border-[#dfbb76]/40 flex items-center justify-center text-[#dfbb76]">
                  <BookmarkCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-playfair text-lg sm:text-xl font-bold text-white">
                    Saved Banquet Enquiries Register
                  </h3>
                  <span className="text-[11px] text-[#dfbb76] font-mono">
                    {savedEnquiries.length} {savedEnquiries.length === 1 ? 'Record' : 'Records'} Saved in Local Database
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowSavedListModal(false)}
                className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content List */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              {savedEnquiries.length === 0 ? (
                <div className="text-center py-12 space-y-3">
                  <BookmarkCheck className="w-10 h-10 text-[#71717a] mx-auto" />
                  <p className="text-sm text-[#a1a1aa] font-mono">
                    No saved banquet enquiries found yet.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setShowSavedListModal(false);
                      handleScrollToForm();
                    }}
                    className="text-xs text-[#dfbb76] underline font-mono"
                  >
                    Submit a new event enquiry
                  </button>
                </div>
              ) : (
                savedEnquiries.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-[#1a1a20] border border-white/10 hover:border-[#dfbb76]/40 transition-colors space-y-3 font-mono text-xs"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-white/10">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 text-[10px] font-semibold">
                          {item.status}
                        </span>
                        <span className="text-[#dfbb76] font-bold text-sm tracking-wider">
                          {item.referenceCode}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(item.referenceCode);
                            setCopiedRef(true);
                            setTimeout(() => setCopiedRef(false), 2000);
                          }}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#a1a1aa] hover:text-white transition-colors"
                          title="Copy Reference"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteSavedEnquiry(item.id)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                          title="Delete Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-[#71717a] block text-[10px]">ORGANIZER</span>
                        <span className="text-white font-sans font-medium">{item.name} ({item.mobileNumber})</span>
                      </div>
                      <div>
                        <span className="text-[#71717a] block text-[10px]">EVENT & DATE</span>
                        <span className="text-white font-sans">{item.eventType} • <strong className="text-emerald-400">{item.eventDate}</strong></span>
                      </div>
                      <div>
                        <span className="text-[#71717a] block text-[10px]">GUESTS & TIME</span>
                        <span className="text-white font-sans">{item.expectedGuests} • {item.preferredTime}</span>
                      </div>
                      <div>
                        <span className="text-[#71717a] block text-[10px]">SAVED AT</span>
                        <span className="text-[#a1a1aa]">{item.createdAt}</span>
                      </div>
                    </div>

                    {item.additionalRequirements && (
                      <div className="p-2.5 rounded-xl bg-black/30 border border-white/5 text-[11px] font-sans text-[#c4c4cc]">
                        {item.additionalRequirements}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-white/10 bg-[#121216] flex items-center justify-between">
              {savedEnquiries.length > 0 ? (
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm('Clear all saved banquet inquiries?')) {
                      localStorage.removeItem('hotel_sai_maya_banquet_enquiries');
                      setSavedEnquiries([]);
                      setLatestSavedEnquiry(null);
                    }
                  }}
                  className="text-xs text-rose-400/80 hover:text-rose-300 font-mono transition-colors"
                >
                  Clear All Records
                </button>
              ) : <div />}

              <button
                type="button"
                onClick={() => setShowSavedListModal(false)}
                className="py-2 px-5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-mono font-medium transition-colors cursor-pointer"
              >
                Close Register
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
