import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, MessageSquare, Sparkles, Clock, Car, User, Users, BookmarkCheck, CheckCircle2, Copy, Check } from 'lucide-react';
import { CartItem } from '../types';
import { triggerWhatsAppOrder } from '../data/restaurantData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (itemId: string, newQty: number) => void;
  onUpdateDietary: (itemId: string, pref: 'Standard Satvik' | 'Strict Jain' | 'Mild Spices' | 'Extra Desi Ghee') => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onUpdateDietary,
  onClearCart,
}) => {
  const [guestName, setGuestName] = useState('');
  const [partySize, setPartySize] = useState('4');
  const [eta, setEta] = useState('In 15–20 Mins');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [specialRequest, setSpecialRequest] = useState('');
  const [savedOrder, setSavedOrder] = useState<{
    referenceCode: string;
    guestName: string;
    totalAmount: number;
    itemCount: number;
    eta: string;
    timestamp: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, curr) => acc + curr.item.price * curr.quantity, 0);

  const handleSaveOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const referenceCode = `HSM-ORD-${randomSuffix}`;
    const timestamp = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      dateStyle: 'medium',
      timeStyle: 'short'
    });

    const newOrder = {
      referenceCode,
      guestName: guestName.trim() || 'Esteemed Highway Guest',
      partySize,
      eta,
      vehicleNumber,
      specialRequest,
      totalAmount: subtotal,
      itemCount: items.reduce((a, c) => a + c.quantity, 0),
      items: items.map((i) => ({
        name: i.item.name,
        quantity: i.quantity,
        price: i.item.price,
        dietaryPreference: i.dietaryPreference
      })),
      timestamp,
      status: 'Saved in Kitchen Queue'
    };

    try {
      const existing = localStorage.getItem('hotel_sai_maya_saved_orders');
      const list = existing ? JSON.parse(existing) : [];
      list.unshift(newOrder);
      localStorage.setItem('hotel_sai_maya_saved_orders', JSON.stringify(list));
    } catch (err) {
      console.error('Failed to save order to localStorage:', err);
    }

    setSavedOrder({
      referenceCode,
      guestName: newOrder.guestName,
      totalAmount: subtotal,
      itemCount: newOrder.itemCount,
      eta,
      timestamp
    });
    onClearCart();
  };

  const handleCopyOrderRef = () => {
    if (!savedOrder) return;
    navigator.clipboard.writeText(`Hotel Sai Maya Order Ref: ${savedOrder.referenceCode} - ₹${savedOrder.totalAmount}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCloseAndReset = () => {
    setSavedOrder(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-in fade-in duration-300">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      ></div>

      {/* Slide-out drawer panel */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#141416] border-l border-white/10 shadow-2xl flex flex-col justify-between">
          {/* Drawer Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#dfbb76]/20 border border-[#dfbb76]/40 flex items-center justify-center text-[#dfbb76]">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-serif-title text-lg font-bold text-white">
                  Express Highway Tray
                </h3>
                <span className="text-[11px] text-[#a1a1aa] font-mono">
                  {items.length} Culinary Item{items.length !== 1 ? 's' : ''} Selected
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/80 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Content Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {savedOrder ? (
              <div className="text-center py-10 space-y-4 animate-in fade-in zoom-in duration-200">
                <div className="w-16 h-16 rounded-full bg-emerald-950 border border-emerald-500/60 flex items-center justify-center text-emerald-400 mx-auto shadow-lg shadow-emerald-950/50">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="space-y-1">
                  <span className="inline-block px-3 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono font-semibold">
                    ✓ ORDER RECORD SAVED
                  </span>
                  <h4 className="text-xl font-serif-title font-bold text-white">
                    Order Registered Successfully!
                  </h4>
                  <p className="text-xs text-[#a1a1aa] max-w-xs mx-auto">
                    Your advance food order has been securely saved and dispatched to the highway kitchen.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-[#1a1a20] border border-white/10 text-left font-mono text-xs space-y-2.5">
                  <div className="flex items-center justify-between pb-2 border-b border-white/10">
                    <span className="text-[#a1a1aa]">Order Reference</span>
                    <span className="text-[#dfbb76] font-bold text-sm">{savedOrder.referenceCode}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#a1a1aa]">Guest</span>
                    <span className="text-white font-sans">{savedOrder.guestName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#a1a1aa]">Total Amount</span>
                    <span className="text-emerald-400 font-bold">₹{savedOrder.totalAmount}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#a1a1aa]">Kitchen ETA</span>
                    <span className="text-white">{savedOrder.eta}</span>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-white/10 text-[11px] text-[#71717a]">
                    <span>Saved At</span>
                    <span>{savedOrder.timestamp}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleCopyOrderRef}
                    className="flex-1 py-3 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-mono flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-[#dfbb76]" />}
                    <span>{copied ? 'Copied!' : 'Copy Reference'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleCloseAndReset}
                    className="flex-1 py-3 px-4 rounded-xl gold-btn text-black font-semibold text-xs font-cinzel tracking-wider uppercase flex items-center justify-center cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : items.length === 0 ? (
              <div className="text-center py-20">
                <ShoppingBag className="w-12 h-12 text-[#dfbb76]/30 mx-auto mb-3" />
                <h4 className="text-base font-serif-title font-semibold text-white mb-1">
                  Your Dining Tray is Empty
                </h4>
                <p className="text-xs text-[#a1a1aa] max-w-xs mx-auto mb-6">
                  Browse our Royal Thalis, slow-fire Punjabi tandoor gravies, or highway express starters to begin your order.
                </p>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-full gold-shimmer-btn text-black font-semibold text-xs uppercase tracking-wider"
                >
                  Explore Menu
                </button>
              </div>
            ) : (
              <>
                {/* Items List */}
                <div className="space-y-4">
                  {items.map((cartItem) => (
                    <div
                      key={cartItem.item.id}
                      className="p-4 rounded-2xl bg-[#1a1a1e] border border-white/5 flex flex-col gap-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <h4 className="font-serif-title text-sm font-semibold text-white leading-snug">
                            {cartItem.item.name}
                          </h4>
                          <span className="text-xs text-[#dfbb76] font-mono font-bold">
                            ₹{cartItem.item.price} each
                          </span>
                        </div>

                        {/* Quantity Controls */}
                        <div className="flex items-center gap-2 bg-[#0c0c0e] px-2 py-1 rounded-full border border-white/10">
                          <button
                            onClick={() => onUpdateQuantity(cartItem.item.id, cartItem.quantity - 1)}
                            className="text-[#a1a1aa] hover:text-white p-1"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-semibold text-white w-4 text-center">
                            {cartItem.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(cartItem.item.id, cartItem.quantity + 1)}
                            className="text-[#a1a1aa] hover:text-white p-1"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Dietary Customization Selector */}
                      <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                        <span className="text-[11px] text-[#a1a1aa]">Preparation:</span>
                        <select
                          value={cartItem.dietaryPreference}
                          onChange={(e) =>
                            onUpdateDietary(cartItem.item.id, e.target.value as any)
                          }
                          className="bg-[#0c0c0e] border border-white/10 text-[#dfbb76] text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-[#dfbb76]"
                        >
                          <option value="Standard Satvik">Standard Satvik</option>
                          {cartItem.item.isJainAvailable && (
                            <option value="Strict Jain">Strict Jain (No Root Veg)</option>
                          )}
                          <option value="Mild Spices">Mild Spices (Low Chilis)</option>
                          <option value="Extra Desi Ghee">Extra Gir Cow Ghee</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Highway Transit Details Form */}
                <div className="p-4 rounded-2xl bg-[#0c0c0e]/80 border border-white/10 space-y-3">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#dfbb76] block mb-1">
                    TRANSIT INGRESS COORDINATION
                  </span>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-[#a1a1aa] block mb-1">Guest Name</label>
                      <input
                        type="text"
                        value={guestName}
                        onChange={(e) => setGuestName(e.target.value)}
                        placeholder="e.g. Rajesh Patil"
                        className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#dfbb76]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-[#a1a1aa] block mb-1">Party Size</label>
                      <input
                        type="number"
                        min="1"
                        max="60"
                        value={partySize}
                        onChange={(e) => setPartySize(e.target.value)}
                        className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#dfbb76]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-[#a1a1aa] block mb-1">Estimated ETA</label>
                      <input
                        type="text"
                        value={eta}
                        onChange={(e) => setEta(e.target.value)}
                        placeholder="e.g. 15 Mins"
                        className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#dfbb76]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-[#a1a1aa] block mb-1">Vehicle No. (Optional)</label>
                      <input
                        type="text"
                        value={vehicleNumber}
                        onChange={(e) => setVehicleNumber(e.target.value)}
                        placeholder="MH 12 AB 1234"
                        className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#dfbb76]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-[#a1a1aa] block mb-1">Special Highway Request</label>
                    <input
                      type="text"
                      value={specialRequest}
                      onChange={(e) => setSpecialRequest(e.target.value)}
                      placeholder="e.g. Urgent 15-min turnaround, keep table for 6"
                      className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#dfbb76]"
                    />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Drawer Footer & WhatsApp Action */}
          {items.length > 0 && (
            <div className="p-6 border-t border-white/10 bg-[#141416] space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#a1a1aa]">Estimated Subtotal</span>
                <span className="font-cinzel text-xl font-bold text-[#dfbb76]">
                  ₹{subtotal}
                </span>
              </div>
              <p className="text-[10px] text-[#a1a1aa]/80">
                *Taxes calculated at billing. 100% Satvik preparation verified.
              </p>

              <button
                id="cart-submit-btn"
                onClick={handleSaveOrder}
                className="w-full gold-shimmer-btn py-3.5 px-4 rounded-2xl text-black font-semibold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
              >
                <BookmarkCheck className="w-4 h-4 text-black" />
                <span>CONFIRM & SAVE PRE-ORDER</span>
              </button>

              <button
                onClick={onClearCart}
                className="w-full py-1 text-center text-[11px] text-[#a1a1aa] hover:text-rose-400 transition-colors"
              >
                Clear Entire Tray
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
