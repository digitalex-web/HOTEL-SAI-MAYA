import React from 'react';
import { Sparkles, Phone, MessageSquare, Instagram, MapPin, Clock, Award, ShieldCheck, Heart } from 'lucide-react';
import { RESTAURANT_METADATA, triggerWhatsAppOrder } from '../data/restaurantData';

interface FooterProps {
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  return (
    <footer className="bg-[#08080a] border-t border-white/10 pt-16 pb-24 md:pb-16 px-4 sm:px-6 relative text-white/80">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-14 border-b border-white/10">
          {/* Brand Column */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#dfbb76] to-[#c5a059] flex items-center justify-center text-black font-cinzel font-bold text-base shadow-md">
                <Sparkles className="w-5 h-5 text-[#0c0c0e]" />
              </div>
              <div>
                <span className="font-cinzel text-lg font-bold tracking-wider text-white flex items-center gap-2">
                  HOTEL SAI MAYA <span className="text-[#dfbb76] text-xs font-normal">★ NEW</span>
                </span>
                <p className="text-[10px] tracking-[0.2em] text-[#a1a1aa] uppercase font-mono">
                  100% Pure Veg • Highway Sanctuary
                </p>
              </div>
            </div>

            <p className="text-xs text-[#a1a1aa] leading-relaxed font-sans-ui">
              A serene transient dining haven bridging authentic Khandeshi Maharashtrian culinary heritage with royal clay tandoor delicacies on the sacred Shirdi pilgrimage trail.
            </p>

            {/* Certifications badges */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <span className="inline-flex items-center gap-1 text-[10px] uppercase font-semibold px-3 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-emerald-300">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                100% Satvik Verified
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] uppercase font-semibold px-3 py-1 rounded-full bg-[#1a1a1e] border border-[#dfbb76]/30 text-[#dfbb76]">
                <Award className="w-3 h-3" />
                4.8★ Pilgrim Rating
              </span>
            </div>
          </div>

          {/* Rapid Links Column */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-cinzel font-semibold tracking-widest text-[#dfbb76] uppercase">
              EXPERIENCES
            </h4>
            <ul className="space-y-2 text-xs text-[#a1a1aa]">
              <li><a href="#philosophy" className="hover:text-white transition-colors">Sanctuary Ethos</a></li>
              <li><a href="#menu" className="hover:text-white transition-colors">Royal Thali Tasting</a></li>
              <li><a href="#banquet" className="hover:text-white transition-colors text-[#dfbb76]">🏛️ Banquet & Events (TBC)</a></li>
              <li><a href="#reviews" className="hover:text-white transition-colors">Verified Guest Reviews</a></li>
              <li><a href="#transit" className="hover:text-white transition-colors">15-Min Aarti Synchronizer</a></li>
              <li><a href="#transit" className="hover:text-white transition-colors">Luxury Coach Bays</a></li>
            </ul>
          </div>

          {/* Social & Instagram Column */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-cinzel font-semibold tracking-widest text-[#dfbb76] uppercase">
              LIVE CHRONICLE
            </h4>
            <p className="text-xs text-[#a1a1aa]">
              Follow our daily farm-to-table journey, woodfire tandoor preparations, and pilgrim stories on Instagram.
            </p>
            <a
              href={`https://instagram.com/${RESTAURANT_METADATA.instagramHandle.replace('@', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-xs font-mono text-[#dfbb76] hover:underline"
            >
              <Instagram className="w-4 h-4" />
              <span>{RESTAURANT_METADATA.instagramHandle}</span>
            </a>
            <div className="text-[11px] text-[#a1a1aa] font-mono">
              Continuous Highway Operation: <span className="text-white">6:00 AM – 11:30 PM</span>
            </div>
          </div>

          {/* Location & Ingress Column */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-cinzel font-semibold tracking-widest text-[#dfbb76] uppercase">
              HIGHWAY ADDRESS
            </h4>
            <p className="text-xs text-[#a1a1aa] leading-relaxed flex items-start gap-1.5">
              <MapPin className="w-4 h-4 text-[#dfbb76] shrink-0 mt-0.5" />
              <span>{RESTAURANT_METADATA.address}</span>
            </p>
            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => triggerWhatsAppOrder()}
                className="emerald-glass-btn text-[#e6ca92] text-xs font-semibold py-2 px-3 rounded-xl flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                <span>Instant Highway Concierge</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom credits */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#a1a1aa]">
          <div>
            © {new Date().getFullYear()} Hotel Sai Maya (New / Veg). All Rights Reserved. Shirdi–Kopargaon Corridor.
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="text-[#dfbb76] font-mono">Jai Sai Ram</span>
            <span>•</span>
            <span>100% Shudh Shakahari</span>
            <span>•</span>
            <button
              type="button"
              onClick={onOpenAdmin}
              className="text-[#c5a059] hover:text-[#dfbb76] underline underline-offset-4 cursor-pointer transition-colors"
            >
              Management Portal
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
