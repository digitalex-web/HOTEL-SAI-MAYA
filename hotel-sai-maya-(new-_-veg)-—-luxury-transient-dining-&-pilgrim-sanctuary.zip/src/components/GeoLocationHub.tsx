import React, { useState } from 'react';
import { MapPin, Navigation, Phone, MessageSquare, ExternalLink, Compass, Clock, Car, Train, Utensils } from 'lucide-react';
import { ROUTE_PROXIMITIES, RESTAURANT_METADATA, triggerWhatsAppOrder } from '../data/restaurantData';

export const GeoLocationHub: React.FC = () => {
  const [selectedOrigin, setSelectedOrigin] = useState<string>('mumbai');

  const originCorridors = [
    {
      id: 'mumbai',
      city: 'Mumbai / Thane',
      distance: '240 km',
      driveTime: '3.5 – 4 hrs',
      route: 'Samruddhi Mahamarg (Expressway) to Shirdi Interchange, exit onto MH SH 10',
      landmarkAdvice: 'Take the Shirdi Interchange exit; Hotel Sai Maya is located directly on MH SH 10, 14 km ahead on your right.',
    },
    {
      id: 'pune',
      city: 'Pune / PCMC',
      distance: '185 km',
      driveTime: '3.5 hrs',
      route: 'Pune–Nashik NH 60 to Sangamner bypass, direct onto MH SH 10',
      landmarkAdvice: 'Clear dual carriageway via Sangamner. Enter the Shirdi corridor with zero inner-city bottleneck.',
    },
    {
      id: 'nashik',
      city: 'Nashik / Trimbakeshwar',
      distance: '85 km',
      driveTime: '1 hr 45 min',
      route: 'Nashik–Sinnar–Shirdi State Highway corridor',
      landmarkAdvice: 'Ideal post-Trimbakeshwar lunch stop before afternoon Sai Samadhi darshan queue.',
    },
    {
      id: 'aurangabad',
      city: 'Chhatrapati Sambhajinagar',
      distance: '110 km',
      driveTime: '2 hrs',
      route: 'Samruddhi Mahamarg / Vaijapur–Kopargaon corridor',
      landmarkAdvice: 'Direct flyover access into Kopargaon bypass leading straight to our private gated entrance.',
    }
  ];

  const currentCorridor = originCorridors.find((c) => c.id === selectedOrigin) || originCorridors[0];

  return (
    <section id="location" className="py-24 px-4 sm:px-6 relative bg-[#0c0c0e] border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-[0.25em] text-[#dfbb76] uppercase font-cinzel mb-3">
            <MapPin className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>INTERACTIVE GEO-NAVIGATION & LOCATION HUB</span>
          </div>
          <h2 className="font-serif-title text-3xl sm:text-5xl font-bold tracking-tight text-[#f4f4f5] leading-tight mb-4">
            Positioned at the <span className="italic font-editorial gold-gradient-text font-normal">Spiritual Crossroads</span>.
          </h2>
          <p className="text-sm sm:text-base text-[#a1a1aa] font-sans-ui leading-relaxed">
            Conveniently situated on the prominent Shirdi–Kopargaon Highway Corridor (MH SH 10), minutes from major transport junctions, the Samruddhi Expressway, and the sacred Temple precinct.
          </p>
        </div>

        {/* 4 Landmark Proximity Matrix Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {ROUTE_PROXIMITIES.map((route, idx) => (
            <div
              key={idx}
              className="p-5 rounded-2xl bg-[#141416]/90 border border-white/10 hover:border-[#dfbb76]/40 transition-all duration-300 shadow-xl"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="w-9 h-9 rounded-xl bg-[#1a1a1e] border border-white/10 flex items-center justify-center text-[#dfbb76]">
                  {route.icon === 'Compass' && <Compass className="w-4 h-4" />}
                  {route.icon === 'Utensils' && <Utensils className="w-4 h-4" />}
                  {route.icon === 'Train' && <Train className="w-4 h-4" />}
                  {route.icon === 'Navigation' && <Navigation className="w-4 h-4" />}
                </div>
                <span className="text-xs font-cinzel font-bold text-[#dfbb76] px-2.5 py-0.5 rounded-full bg-[#dfbb76]/10 border border-[#dfbb76]/20">
                  {route.drivingTime}
                </span>
              </div>
              <h3 className="font-serif-title text-sm font-semibold text-white mb-1">
                {route.landmark}
              </h3>
              <div className="text-xs text-[#a1a1aa] font-mono mb-2">{route.distance}</div>
              <p className="text-[11px] text-[#a1a1aa]/80 leading-relaxed font-sans-ui">
                {route.routeHighlight}
              </p>
            </div>
          ))}
        </div>

        {/* Interactive Map & Origin Planner Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left: Dark Styled Map Frame */}
          <div className="lg:col-span-7 rounded-3xl overflow-hidden border border-white/10 shadow-2xl relative min-h-[380px] bg-[#141416]">
            {/* Embedded Google Maps with Dark Filter */}
            <iframe
              title="Hotel Sai Maya Location Map"
              src={RESTAURANT_METADATA.googleMapsEmbedUrl}
              className="w-full h-full min-h-[420px] filter invert-[90%] hue-rotate-180 contrast-[88%] brightness-[92%] opacity-85 hover:opacity-100 transition-opacity"
              style={{ border: 0 }}
              allowFullScreen={true}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>

            {/* Map Floating HUD Overlay */}
            <div className="absolute bottom-4 left-4 right-4 p-4 rounded-2xl bg-[#0c0c0e]/90 backdrop-blur-xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xl">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                  <MapPin className="w-3.5 h-3.5 text-[#dfbb76]" />
                  <span>Hotel Sai Maya (New / Veg)</span>
                </div>
                <p className="text-[11px] text-[#a1a1aa] font-mono mt-0.5">
                  MH SH 10, Shirdi–Kopargaon Corridor, Maharashtra
                </p>
              </div>

              <a
                href={RESTAURANT_METADATA.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="gold-shimmer-btn text-black font-semibold text-xs uppercase tracking-wider px-4 py-2 rounded-full flex items-center gap-1.5 whitespace-nowrap shadow-md"
              >
                <Navigation className="w-3.5 h-3.5 text-black" />
                <span>Start Live Navigation</span>
              </a>
            </div>
          </div>

          {/* Right: En-Route City Planner & Concierge Hotline */}
          <div className="lg:col-span-5 flex flex-col justify-between p-6 sm:p-8 rounded-3xl bg-[#141416]/90 border border-white/10 shadow-2xl">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-cinzel font-semibold tracking-wider text-[#dfbb76] uppercase">
                  HIGHWAY ROUTE ADVISOR
                </span>
                <span className="text-[10px] text-[#a1a1aa] font-mono">Live Route Ingress</span>
              </div>

              <h3 className="font-serif-title text-xl font-bold text-white mb-3">
                Select Your Traveling Departure Point:
              </h3>

              {/* City Selection Tabs */}
              <div className="grid grid-cols-2 gap-2 mb-6">
                {originCorridors.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedOrigin(c.id)}
                    className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                      selectedOrigin === c.id
                        ? 'bg-[#dfbb76]/20 border-[#dfbb76] text-white font-medium shadow-md'
                        : 'bg-[#1a1a1e] border-white/5 text-[#a1a1aa] hover:border-white/10'
                    }`}
                  >
                    <div className="font-semibold text-white text-xs">{c.city}</div>
                    <div className="text-[10px] text-[#dfbb76] font-mono">{c.driveTime}</div>
                  </button>
                ))}
              </div>

              {/* Selected Route Guidance Card */}
              <div className="p-4 rounded-2xl bg-[#0c0c0e]/80 border border-white/10 mb-6">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-[#a1a1aa]">Corridor Route:</span>
                  <span className="text-white font-semibold">{currentCorridor.distance}</span>
                </div>
                <div className="text-xs text-white/90 font-medium mb-2 font-mono">
                  {currentCorridor.route}
                </div>
                <p className="text-[11px] text-[#a1a1aa] leading-relaxed italic">
                  "{currentCorridor.landmarkAdvice}"
                </p>
              </div>
            </div>

            {/* Direct Assistance Triggers */}
            <div className="flex flex-col gap-2.5 pt-4 border-t border-white/10">
              <a
                href={`tel:${RESTAURANT_METADATA.phone.replace(/\s+/g, '')}`}
                className="w-full py-3 px-4 rounded-xl bg-[#1a1a1e] border border-white/10 hover:border-[#dfbb76]/40 text-white text-xs font-semibold tracking-wider uppercase flex items-center justify-center gap-2 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-[#dfbb76]" />
                <span>Highway Hotline: {RESTAURANT_METADATA.phone}</span>
              </a>

              <button
                onClick={() =>
                  triggerWhatsAppOrder({
                    specialRequest: `Highway route assistance requested from ${currentCorridor.city} en route on MH SH 10.`,
                  })
                }
                className="w-full py-3 px-4 rounded-xl emerald-glass-btn text-[#e6ca92] text-xs font-semibold tracking-wider uppercase flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                <span>WhatsApp Live Route Assistance</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
