import React from 'react';
import { Sparkles, MessageSquare, ChevronDown, Award, Star, ShieldCheck, Clock, MapPin, Navigation } from 'lucide-react';
import { RESTAURANT_METADATA } from '../data/restaurantData';
import { useAdmin } from '../context/AdminContext';

interface HeroSectionProps {
  onExploreMenu: () => void;
  onOpenWhatsApp: () => void;
  onOpenReservation: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreMenu,
  onOpenWhatsApp,
  onOpenReservation,
}) => {
  const { heroConfig } = useAdmin();

  return (
    <section className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center pt-28 pb-16 px-4 sm:px-6 overflow-hidden bg-[#0c0c0e]">
      {/* Cinematic Background with Atmospheric Vignette */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Ambient Dark Food & Architecture Image */}
        <img
          src={heroConfig?.heroImage || "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=2000&q=80"}
          alt="Atmospheric Indian Dining Sanctuary"
          className="w-full h-full object-cover object-center opacity-25 scale-105 filter blur-[1px] brightness-75 transition-transform duration-10000 ease-out"
        />
        
        {/* Layered Vignettes & Radial Spotlights */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0e] via-[#0c0c0e]/80 to-[#0c0c0e]/60"></div>
        <div className="absolute inset-0 bg-radial-gold opacity-90"></div>
        <div className="absolute inset-0 bg-radial-emerald opacity-30"></div>
        
        {/* Luxury subtle grain overlay texture */}
        <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-5xl mx-auto text-center flex flex-col items-center">
        {/* Editorial Eyebrow with Pure Veg Jewel Marker */}
        <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#141416]/80 border border-[#dfbb76]/30 backdrop-blur-xl shadow-lg mb-6 animate-in fade-in slide-in-from-bottom-3 duration-700">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 border border-emerald-200 shadow-[0_0_8px_rgba(52,211,153,0.8)]"></span>
          <span className="text-[10px] sm:text-xs font-semibold tracking-[0.25em] text-[#e6ca92] uppercase font-cinzel">
            PALLADIUM PURITY • 100% PURE VEGETARIAN CULINARY SANCTUARY
          </span>
        </div>

        {/* Cinematic Headline */}
        <h1 className="font-serif-title text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-[#f4f4f5] leading-[1.12] max-w-4xl mb-6">
          {heroConfig?.title || 'A Refined Culinary Pause on Your Sacred Pilgrimage.'}
        </h1>

        {/* Sub-narrative detailing the bridge between Khandeshi heritage & slow-fire tandoor */}
        <p className="text-sm sm:text-base md:text-lg text-[#a1a1aa] font-sans-ui max-w-2xl leading-relaxed mb-10 font-normal">
          {heroConfig?.subtitle || 'Elegantly bridging authentic Khandeshi Maharashtrian heritage with royal slow-fire North Indian tandoor recipes. Designed exclusively for the discerning highway traveler seeking immaculate Satvik purity, rapid darshan synchronicity, and tranquil sanctuary on the Shirdi–Kopargaon corridor.'}
        </p>

        {/* Primary Action Hub */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md mb-14">
          <button
            id="hero-explore-menu-btn"
            onClick={onExploreMenu}
            className="w-full sm:w-auto gold-shimmer-btn text-black font-semibold text-xs sm:text-sm uppercase tracking-widest px-8 py-4 rounded-full flex items-center justify-center gap-2 shadow-2xl transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-black" />
            <span>{heroConfig?.primaryCtaText || 'Explore Chef’s Tasting Menu'}</span>
          </button>

          <button
            id="hero-whatsapp-concierge-btn"
            onClick={onOpenWhatsApp}
            className="w-full sm:w-auto emerald-glass-btn text-[#e6ca92] font-semibold text-xs sm:text-sm uppercase tracking-wider px-7 py-4 rounded-full flex items-center justify-center gap-2 shadow-xl cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <span>{heroConfig?.secondaryCtaText || 'Direct Highway Concierge'}</span>
          </button>
        </div>

        {/* Quick Stats Banner (Frosted Glassmorphic Counters) */}
        <div className="w-full grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 p-4 sm:p-5 rounded-3xl bg-[#141416]/60 backdrop-blur-2xl border border-white/10 shadow-2xl">
          {/* Stat 1 */}
          <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-[#c5a059]/30 transition-all">
            <div className="flex items-center gap-1 text-[#dfbb76] mb-1">
              <Award className="w-4 h-4" />
              <span className="font-cinzel text-lg sm:text-xl font-bold tracking-tight">100%</span>
            </div>
            <span className="text-[11px] sm:text-xs text-[#a1a1aa] font-medium tracking-wide">
              Satvik & Shudh Shakahari
            </span>
          </div>

          {/* Stat 2 */}
          <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-[#c5a059]/30 transition-all">
            <div className="flex items-center gap-1 text-[#dfbb76] mb-1">
              <Star className="w-4 h-4 fill-[#dfbb76]" />
              <span className="font-cinzel text-lg sm:text-xl font-bold tracking-tight">4.8★</span>
            </div>
            <span className="text-[11px] sm:text-xs text-[#a1a1aa] font-medium tracking-wide">
              Pilgrim & Traveler Index
            </span>
          </div>

          {/* Stat 3 */}
          <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-[#c5a059]/30 transition-all">
            <div className="flex items-center gap-1 text-[#dfbb76] mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span className="font-cinzel text-lg sm:text-xl font-bold tracking-tight">45+</span>
            </div>
            <span className="text-[11px] sm:text-xs text-[#a1a1aa] font-medium tracking-wide">
              Secured Luxury & Coach Bays
            </span>
          </div>

          {/* Stat 4 */}
          <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-[#c5a059]/30 transition-all">
            <div className="flex items-center gap-1 text-emerald-400 mb-1">
              <Clock className="w-4 h-4" />
              <span className="font-cinzel text-lg sm:text-xl font-bold tracking-tight text-[#dfbb76]">7 Mins</span>
            </div>
            <span className="text-[11px] sm:text-xs text-[#a1a1aa] font-medium tracking-wide">
              To Sai Baba Samadhi Mandir
            </span>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="mt-10 flex flex-col items-center text-[#a1a1aa]/60 hover:text-[#dfbb76] cursor-pointer transition-colors" onClick={onExploreMenu}>
          <span className="text-[10px] uppercase tracking-[0.2em] mb-1 font-mono">Scroll to Sensory Experience</span>
          <ChevronDown className="w-4 h-4 animate-bounce text-[#c5a059]" />
        </div>
      </div>
    </section>
  );
};
