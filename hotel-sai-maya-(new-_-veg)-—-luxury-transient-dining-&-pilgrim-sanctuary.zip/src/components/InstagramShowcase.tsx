import React, { useState } from 'react';
import { Instagram, CheckCircle, ExternalLink, Play, Heart, MessageCircle, Sparkles } from 'lucide-react';
import { INSTAGRAM_STORIES, RESTAURANT_METADATA } from '../data/restaurantData';
import { InstagramStoryItem } from '../types';
import { StoryModal } from './StoryModal';

export const InstagramShowcase: React.FC = () => {
  const [selectedStory, setSelectedStory] = useState<InstagramStoryItem | null>(null);

  return (
    <section id="instagram" className="py-24 px-4 sm:px-6 relative bg-[#0c0c0e] border-t border-white/5">
      {/* Background ambient lighting */}
      <div className="absolute left-1/4 bottom-10 w-96 h-96 bg-[#c5a059]/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header & Instagram Handle Badge with Verified Mark */}
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-[0.25em] text-[#dfbb76] uppercase font-cinzel mb-3">
              <Instagram className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>THE VISUAL CHRONICLE • LIVE FROM OUR KITCHEN</span>
            </div>
            <h2 className="font-serif-title text-3xl sm:text-5xl font-bold tracking-tight text-[#f4f4f5] leading-tight">
              Captured in the <span className="italic font-editorial gold-gradient-text font-normal">Heat of Dawn</span>.
            </h2>
          </div>

          {/* Verified Instagram Handle Pill */}
          <div className="flex flex-wrap items-center gap-3">
            <a
              href={`https://instagram.com/${RESTAURANT_METADATA.instagramHandle.replace('@', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              id="instagram-follow-badge"
              className="group flex items-center gap-3 px-4 py-2.5 rounded-full bg-[#141416]/90 border border-[#dfbb76]/30 hover:border-[#dfbb76] backdrop-blur-xl shadow-lg transition-all"
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white">
                <Instagram className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1">
                  <span className="font-mono text-xs font-semibold text-white group-hover:text-[#dfbb76] transition-colors">
                    {RESTAURANT_METADATA.instagramHandle}
                  </span>
                  <CheckCircle className="w-3 h-3 text-blue-400 fill-blue-400/30" />
                </div>
                <span className="text-[10px] text-[#a1a1aa] font-medium">
                  {RESTAURANT_METADATA.instagramFollowers} Pilgrims & Connoisseurs
                </span>
              </div>
              <ExternalLink className="w-3.5 h-3.5 text-[#a1a1aa] group-hover:text-white transition-colors ml-1" />
            </a>
          </div>
        </div>

        {/* 4 Realistic Story / Reel Carousel Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {INSTAGRAM_STORIES.map((story) => (
            <div
              key={story.id}
              onClick={() => setSelectedStory(story)}
              className="group relative h-96 rounded-3xl overflow-hidden cursor-pointer border border-white/10 hover:border-[#dfbb76]/60 transition-all duration-500 shadow-xl bg-[#141416]"
            >
              {/* Image Background */}
              <img
                src={story.image}
                alt={story.title}
                loading="lazy"
                className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 brightness-85 group-hover:brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0e] via-[#0c0c0e]/30 to-transparent"></div>

              {/* Story Pill Badge */}
              <div className="absolute top-4 left-4 z-20">
                <span className="text-[10px] font-semibold tracking-wider px-2.5 py-1 rounded-full bg-black/60 border border-white/20 text-[#e6ca92] uppercase backdrop-blur-md">
                  {story.badge}
                </span>
              </div>

              {/* Reel Play Micro Icon */}
              <div className="absolute top-4 right-4 z-20 w-7 h-7 rounded-full bg-black/50 border border-white/20 flex items-center justify-center text-white/90 group-hover:scale-110 transition-transform">
                <Play className="w-3 h-3 fill-white ml-0.5" />
              </div>

              {/* Bottom Details */}
              <div className="absolute bottom-0 inset-x-0 p-5 z-20 flex flex-col justify-end">
                <span className="text-[10px] text-[#dfbb76] font-mono mb-1">{story.timestamp}</span>
                <h3 className="font-serif-title text-base font-semibold text-white mb-2 leading-snug group-hover:text-[#dfbb76] transition-colors">
                  {story.title}
                </h3>
                <p className="text-[11px] text-[#a1a1aa] line-clamp-2 leading-relaxed mb-3">
                  {story.caption}
                </p>

                {/* Engagement Bar */}
                <div className="flex items-center justify-between pt-2 border-t border-white/10 text-white/70 text-xs">
                  <span className="flex items-center gap-1 hover:text-rose-400">
                    <Heart className="w-3.5 h-3.5" />
                    {story.likes}
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-3.5 h-3.5" />
                    {story.comments}
                  </span>
                  <span className="text-[10px] text-[#dfbb76] uppercase tracking-wider font-semibold font-mono">
                    View Reel
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Story Modal */}
      {selectedStory && (
        <StoryModal
          story={selectedStory}
          onClose={() => setSelectedStory(null)}
        />
      )}
    </section>
  );
};
