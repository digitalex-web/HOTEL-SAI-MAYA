import React from 'react';
import { Phone, MessageSquare, ShoppingBag, Sparkles } from 'lucide-react';
import { RESTAURANT_METADATA } from '../data/restaurantData';

interface MobileBottomDockProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenWhatsApp: () => void;
  onOpenReservation: () => void;
}

export const MobileBottomDock: React.FC<MobileBottomDockProps> = ({
  cartCount,
  onOpenCart,
  onOpenWhatsApp,
  onOpenReservation,
}) => {
  return (
    <aside aria-label="Mobile Navigation and Concierge Dock" className="md:hidden fixed bottom-0 inset-x-0 z-40 p-3 bg-gradient-to-t from-black via-[#0c0c0e]/95 to-transparent pointer-events-none">
      <div className="max-w-md mx-auto p-2 rounded-2xl bg-[#141416]/95 backdrop-blur-2xl border border-white/15 shadow-[0_-10px_35px_rgba(0,0,0,0.8)] pointer-events-auto flex items-center gap-2">
        {/* Direct Concierge Call button */}
        <a
          href={`tel:${RESTAURANT_METADATA.phone.replace(/\s+/g, '')}`}
          id="mobile-dock-call-btn"
          aria-label="Call Highway Concierge"
          className="flex-1 py-3 px-2 rounded-xl bg-[#1a1a1e] border border-white/10 active:scale-95 transition-all text-white flex items-center justify-center gap-1.5 shadow-md"
        >
          <Phone className="w-3.5 h-3.5 text-[#dfbb76]" />
          <div className="flex flex-col text-left">
            <span className="text-[10px] uppercase font-mono text-[#dfbb76] leading-none">Concierge</span>
            <span className="text-xs font-semibold text-white leading-tight">Call Desk</span>
          </div>
        </a>

        {/* Instant WhatsApp Order / Highway Ingress */}
        <button
          onClick={onOpenWhatsApp}
          id="mobile-dock-whatsapp-btn"
          aria-label="Direct WhatsApp Order or Highway Ingress"
          className="flex-1 py-3 px-2 rounded-xl emerald-glass-btn active:scale-95 transition-all text-[#e6ca92] flex items-center justify-center gap-1.5 shadow-md"
        >
          <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
          <div className="flex flex-col text-left">
            <span className="text-[10px] uppercase font-mono text-emerald-300 leading-none">Instant</span>
            <span className="text-xs font-semibold text-white leading-tight">WhatsApp Ingress</span>
          </div>
        </button>

        {/* Cart / Tray floating trigger if items are in cart */}
        {cartCount > 0 && (
          <button
            onClick={onOpenCart}
            id="mobile-dock-cart-btn"
            aria-label="View Order Tray"
            className="p-3 rounded-xl gold-shimmer-btn active:scale-95 text-black flex items-center justify-center relative shadow-lg"
          >
            <ShoppingBag className="w-4 h-4 text-black" />
            <span className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-black shadow">
              {cartCount}
            </span>
          </button>
        )}
      </div>
    </aside>
  );
};
