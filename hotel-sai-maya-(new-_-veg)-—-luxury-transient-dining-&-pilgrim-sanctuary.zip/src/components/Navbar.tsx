import React, { useState, useEffect } from 'react';
import { Sparkles, Phone, MessageSquare, ShoppingBag, Menu, X, Clock, MapPin } from 'lucide-react';
import { RESTAURANT_METADATA } from '../data/restaurantData';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenReservation: () => void;
  onOpenWhatsApp: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenReservation,
  onOpenWhatsApp,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: "Philosophy", href: "#philosophy" },
    { name: "Curated Menu", href: "#menu" },
    { name: "Banquet & Events", href: "#banquet" },
    { name: "VIP Transit", href: "#transit" },
    { name: "Reviews", href: "#reviews" },
    { name: "Highway Hub", href: "#location" },
  ];

  return (
    <>
      {/* Top micro-announcement banner */}
      <div className="bg-[#141416]/90 border-b border-white/5 py-1.5 px-4 text-center text-xs tracking-wider text-[#dfbb76] font-medium hidden sm:flex items-center justify-center gap-6">
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          HIGHWAY STATUS: KITCHEN OPEN & SERVING ON MH SH 10
        </span>
        <span className="text-white/20">•</span>
        <span className="flex items-center gap-1 text-white/70">
          <Clock className="w-3 h-3 text-[#dfbb76]" />
          15-Min Rush Darshan Priority Available
        </span>
        <span className="text-white/20">•</span>
        <span className="flex items-center gap-1 text-white/70">
          <MapPin className="w-3 h-3 text-[#dfbb76]" />
          7 Mins to Sai Baba Samadhi Mandir
        </span>
      </div>

      {/* Main floating capsule navbar */}
      <header className="fixed top-2 sm:top-8 inset-x-0 z-50 px-4 sm:px-6 pointer-events-none">
        <div className="max-w-6xl mx-auto flex items-center justify-between pointer-events-auto">
          {/* Brand Monogram capsule */}
          <a
            href="#"
            id="brand-logo"
            className="flex items-center gap-3 bg-[#0c0c0e]/85 backdrop-blur-2xl px-4 py-2.5 rounded-full border border-white/10 hover:border-[#c5a059]/40 transition-all shadow-xl group"
          >
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#dfbb76] to-[#c5a059] flex items-center justify-center text-black font-cinzel font-bold text-sm shadow-md group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4 text-[#0c0c0e]" />
            </div>
            <div className="flex flex-col">
              <span className="font-cinzel text-sm sm:text-base font-semibold tracking-wider text-[#f4f4f5] flex items-center gap-1.5">
                SAI MAYA <span className="text-[#c5a059] text-xs font-normal">★ NEW</span>
              </span>
              <span className="text-[9px] tracking-[0.2em] text-[#a1a1aa] uppercase font-mono">
                Shirdi Sanctuary • Pure Veg
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links Capsule */}
          <nav className="hidden lg:flex items-center gap-1 bg-[#0c0c0e]/75 backdrop-blur-2xl px-5 py-2 rounded-full border border-white/10 shadow-xl">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="relative px-3.5 py-1.5 text-xs font-medium uppercase tracking-widest text-[#f4f4f5]/80 hover:text-[#dfbb76] transition-colors group"
              >
                {link.name}
                <span className="absolute bottom-0 left-3 right-3 h-[1.5px] bg-[#c5a059] scale-x-0 group-hover:scale-x-100 transition-transform origin-center duration-300"></span>
              </a>
            ))}
          </nav>

          {/* Actions: Cart Pill + Reserve Button */}
          <div className="flex items-center gap-2.5">
            {/* Express Cart / Tray button */}
            <button
              id="open-cart-btn"
              onClick={onOpenCart}
              aria-label="View Express Order Tray"
              className="relative bg-[#141416]/85 backdrop-blur-xl border border-white/10 hover:border-[#c5a059]/50 text-white p-2.5 rounded-full transition-all flex items-center justify-center shadow-lg"
            >
              <ShoppingBag className="w-4 h-4 text-[#dfbb76]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-[#0c0c0e] shadow-sm">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Reserve Table / Pre-Order Capsule Button */}
            <button
              id="nav-reserve-btn"
              onClick={onOpenReservation}
              className="hidden sm:inline-flex items-center gap-2 gold-shimmer-btn text-black font-semibold text-xs tracking-wider uppercase px-5 py-2.5 rounded-full shadow-lg transition-transform hover:scale-[1.02] active:scale-[0.98]"
            >
              <Sparkles className="w-3.5 h-3.5 text-black" />
              <span>Reserve Table / Pre-Order</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden bg-[#141416]/85 backdrop-blur-xl border border-white/10 text-white p-2.5 rounded-full"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Panel */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 max-w-sm mx-auto bg-[#141416]/95 backdrop-blur-2xl border border-white/10 rounded-2xl p-5 shadow-2xl pointer-events-auto transition-all animate-in fade-in slide-in-from-top-2">
            <div className="flex flex-col gap-3">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 text-sm font-medium tracking-wider text-white/90 hover:text-[#dfbb76] hover:bg-white/5 rounded-lg transition-colors"
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-3 border-t border-white/10 flex flex-col gap-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenReservation();
                  }}
                  className="w-full gold-shimmer-btn text-black font-semibold text-xs uppercase tracking-wider py-3 rounded-xl text-center shadow-lg"
                >
                  Reserve Table / Pre-Order
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenWhatsApp();
                  }}
                  className="w-full emerald-glass-btn text-[#e6ca92] text-xs font-medium tracking-wider py-2.5 rounded-xl text-center flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  Direct WhatsApp Concierge
                </button>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
