import React from 'react';
import { Flame, Sparkles, Heart, Shield, CheckCircle2 } from 'lucide-react';

export const PhilosophySection: React.FC = () => {
  return (
    <section id="philosophy" className="py-24 px-4 sm:px-6 relative bg-[#0c0c0e] border-t border-b border-white/5 overflow-hidden">
      {/* Subtle radial ambient light */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-[#c5a059]/5 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute left-0 bottom-0 w-80 h-80 bg-emerald-950/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Visual Storytelling Collage */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-3xl overflow-hidden border border-white/10 shadow-2xl group">
              <img
                src="https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=1200&q=85"
                alt="Traditional brass spices and pure ghee cooking"
                className="w-full h-[460px] object-cover object-center group-hover:scale-105 transition-transform duration-700 filter brightness-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0e] via-transparent to-transparent"></div>

              {/* Floating luxury testimonial badge */}
              <div className="absolute bottom-6 left-6 right-6 p-5 rounded-2xl bg-[#141416]/90 backdrop-blur-xl border border-white/10 shadow-xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-full bg-[#c5a059]/20 border border-[#dfbb76]/40 flex items-center justify-center text-[#dfbb76]">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-xs font-cinzel font-semibold tracking-wider text-[#f4f4f5]">KHANDESH TO PUNJAB CORRIDOR</h2>
                    <p className="text-[11px] text-[#a1a1aa]">Wood-fire cooked with zero artificial essences</p>
                  </div>
                </div>
                <p className="text-xs text-white/80 italic font-editorial leading-relaxed">
                  "Every grain of Indrayani rice and drop of stone-ground masala honors the sanctity of your pilgrimage to Sai Baba’s feet."
                </p>
              </div>
            </div>

            {/* Accent decorative floating element */}
            <div className="hidden sm:block absolute -top-5 -left-5 p-4 rounded-2xl bg-[#1a1a1e]/90 border border-[#c5a059]/30 backdrop-blur-xl shadow-2xl max-w-xs">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-1">
                <CheckCircle2 className="w-4 h-4" />
                <span>100% Satvik Certified</span>
              </div>
              <p className="text-[11px] text-[#a1a1aa]">
                Strictly Vegetarian • Dedicated Jain Preparation Area • Freshly Churned White Butter
              </p>
            </div>
          </div>

          {/* Right Column: Editorial Philosophy Content */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-[0.25em] text-[#dfbb76] uppercase font-cinzel mb-4">
              <Flame className="w-4 h-4 text-[#c5a059]" />
              <span>THE SANCTUARY ETHOS</span>
            </div>

            <h2 className="font-serif-title text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#f4f4f5] leading-tight mb-6">
              Where Ancient Khandeshi Heritage Meets Royal Clay Tandoor.
            </h2>

            <p className="text-sm sm:text-base text-[#a1a1aa] font-sans-ui leading-relaxed mb-6">
              For decades, travelers speeding along State Highway 10 endured rushed roadside meals compromising on hygiene, oil quality, and authentic taste. <strong className="text-white">Hotel Sai Maya (New / Veg)</strong> was conceived as a tranquil architectural oasis—redefining transient highway hospitality.
            </p>

            <p className="text-sm sm:text-base text-[#a1a1aa] font-sans-ui leading-relaxed mb-8">
              We source our vegetables daily at 6:00 AM from fertile farms hugging the Godavari river basin. Our gravies simmer over slow woodfire embers, spiced exclusively with roasted whole coriander, dry coconut, dagad phool (stone flower), and cold-pressed peanut oil.
            </p>

            {/* 3 Pillar Feature Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-[#141416]/70 border border-white/5 hover:border-[#c5a059]/30 transition-all">
                <div className="text-[#dfbb76] font-cinzel text-sm font-semibold mb-1">Satvik Purity</div>
                <p className="text-xs text-[#a1a1aa] leading-normal">
                  No onion, garlic, or root vegetable options available across all signature preparations.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#141416]/70 border border-white/5 hover:border-[#c5a059]/30 transition-all">
                <div className="text-[#dfbb76] font-cinzel text-sm font-semibold mb-1">Heavy Kansa Metal</div>
                <p className="text-xs text-[#a1a1aa] leading-normal">
                  Thalis served on authentic bell metal dinnerware that promotes holistic digestive health.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#141416]/70 border border-white/5 hover:border-[#c5a059]/30 transition-all">
                <div className="text-[#dfbb76] font-cinzel text-sm font-semibold mb-1">Transit Grace</div>
                <p className="text-xs text-[#a1a1aa] leading-normal">
                  Rapid service protocols engineered to preserve your temple darshan schedule.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
