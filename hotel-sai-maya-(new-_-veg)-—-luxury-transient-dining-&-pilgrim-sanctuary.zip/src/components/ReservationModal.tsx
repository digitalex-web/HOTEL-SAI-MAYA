import React, { useState } from 'react';
import { X, Sparkles, Calendar, Clock, Users, Car, Phone, User, CheckCircle2, BookmarkCheck, Copy, Check } from 'lucide-react';
import { RESTAURANT_METADATA } from '../data/restaurantData';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({ isOpen, onClose }) => {
  const [guestName, setGuestName] = useState('');
  const [phone, setPhone] = useState('');
  const [partySize, setPartySize] = useState('4');
  const [arrivalDate, setArrivalDate] = useState('Today');
  const [arrivalTime, setArrivalTime] = useState('12:30 PM');
  const [vehicleType, setVehicleType] = useState('Luxury SUV (Fortuner / EV / Sedan)');
  const [darshanSlot, setDarshanSlot] = useState('Madhyan Aarti (12:00 PM)');
  const [dietaryType, setDietaryType] = useState('100% Satvik Standard');
  const [notes, setNotes] = useState('');
  const [submittedBooking, setSubmittedBooking] = useState<{
    referenceCode: string;
    guestName: string;
    phone: string;
    partySize: string;
    arrivalDate: string;
    arrivalTime: string;
    vehicleType: string;
    darshanSlot: string;
    dietaryType: string;
    notes: string;
    timestamp: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const referenceCode = `HSM-RES-${randomSuffix}`;
    const timestamp = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      dateStyle: 'medium',
      timeStyle: 'short'
    });

    const newBooking = {
      referenceCode,
      guestName: guestName || 'Esteemed Pilgrim',
      phone,
      partySize,
      arrivalDate,
      arrivalTime,
      vehicleType,
      darshanSlot,
      dietaryType,
      notes,
      timestamp
    };

    // Save strictly to local storage
    try {
      const existing = localStorage.getItem('hotel_sai_maya_table_reservations');
      const list = existing ? JSON.parse(existing) : [];
      list.unshift(newBooking);
      localStorage.setItem('hotel_sai_maya_table_reservations', JSON.stringify(list));
    } catch (err) {
      console.error('Could not save to localStorage:', err);
    }

    setSubmittedBooking(newBooking);
  };

  const handleCopyConfirmation = () => {
    if (!submittedBooking) return;
    const text = `Hotel Sai Maya Table Reservation\nRef: ${submittedBooking.referenceCode}\nGuest: ${submittedBooking.guestName}\nParty: ${submittedBooking.partySize} Guests\nArrival: ${submittedBooking.arrivalDate} at ${submittedBooking.arrivalTime}\nDietary: ${submittedBooking.dietaryType}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleResetAndClose = () => {
    setSubmittedBooking(null);
    setGuestName('');
    setPhone('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="relative w-full max-w-lg bg-[#141416] border border-[#dfbb76]/30 rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#141416] to-[#1a1a1e]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#dfbb76]/20 border border-[#dfbb76]/40 flex items-center justify-center text-[#dfbb76]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif-title text-xl font-bold text-white">
                Reserve Table / Pre-Order
              </h3>
              <span className="text-[11px] text-[#dfbb76] font-mono">
                Hotel Sai Maya • Highway Transit Sanctuary
              </span>
            </div>
          </div>

          <button
            onClick={handleResetAndClose}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/80 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        {submittedBooking ? (
          <div className="p-6 sm:p-8 space-y-5 animate-in fade-in zoom-in duration-200">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-full bg-emerald-950 border border-emerald-500/60 flex items-center justify-center text-emerald-400 mx-auto shadow-lg shadow-emerald-950/50">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <span className="inline-block px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono font-semibold">
                ✓ RESERVATION SAVED IN REGISTER
              </span>
              <h4 className="text-xl font-serif-title font-bold text-white">
                Table Reserved Successfully!
              </h4>
              <p className="text-xs text-[#a1a1aa] max-w-sm mx-auto">
                Your reservation details have been securely recorded in the Hotel Sai Maya dining system.
              </p>
            </div>

            {/* Receipt Card */}
            <div className="p-4 rounded-2xl bg-[#18181c] border border-white/10 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-[#a1a1aa]">Reference ID</span>
                <span className="text-[#dfbb76] font-bold text-sm tracking-wider">{submittedBooking.referenceCode}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#a1a1aa]">Guest Name</span>
                <span className="text-white font-sans font-medium">{submittedBooking.guestName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#a1a1aa]">Contact Phone</span>
                <span className="text-white">{submittedBooking.phone}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#a1a1aa]">Party Size & Slot</span>
                <span className="text-white font-sans">{submittedBooking.partySize} Guests • {submittedBooking.arrivalTime}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#a1a1aa]">Dietary Standard</span>
                <span className="text-emerald-400 font-sans">{submittedBooking.dietaryType}</span>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-white/10 text-[11px] text-[#71717a]">
                <span>Saved At</span>
                <span>{submittedBooking.timestamp}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleCopyConfirmation}
                className="flex-1 py-3 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-mono flex items-center justify-center gap-2 transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-[#dfbb76]" />}
                <span>{copied ? 'Copied Receipt!' : 'Copy Reference'}</span>
              </button>

              <button
                type="button"
                onClick={handleResetAndClose}
                className="flex-1 py-3 px-4 rounded-xl gold-btn text-black font-semibold text-xs font-cinzel tracking-wider uppercase flex items-center justify-center transition-transform hover:scale-[1.02]"
              >
                Done / Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
            {/* Guest Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                  Pilgrim / Guest Name *
                </label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 text-[#dfbb76] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="e.g. Anand Deshmukh"
                    className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#dfbb76]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                  Contact Mobile Number *
                </label>
                <div className="relative">
                  <Phone className="w-3.5 h-3.5 text-[#dfbb76] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98XXX XXXXX"
                    className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#dfbb76]"
                  />
                </div>
              </div>
            </div>

            {/* Party Size & Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                  Travel Party Size
                </label>
                <div className="relative">
                  <Users className="w-3.5 h-3.5 text-[#dfbb76] absolute left-3 top-1/2 -translate-y-1/2" />
                  <select
                    value={partySize}
                    onChange={(e) => setPartySize(e.target.value)}
                    className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl pl-8 pr-3 py-2 text-xs text-white focus:outline-none focus:border-[#dfbb76]"
                  >
                    <option value="2">2 Guests (Couple / Duo)</option>
                    <option value="4">4 Guests (Family Car)</option>
                    <option value="6">6 Guests (SUV / Innova)</option>
                    <option value="10">10 Guests (Extended Family)</option>
                    <option value="25">25+ Guests (Pilgrim Tour Bus)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                  Expected Arrival Time
                </label>
                <div className="relative">
                  <Clock className="w-3.5 h-3.5 text-[#dfbb76] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={arrivalTime}
                    onChange={(e) => setArrivalTime(e.target.value)}
                    placeholder="e.g. 1:15 PM"
                    className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl pl-8 pr-3 py-2 text-xs text-white focus:outline-none focus:border-[#dfbb76]"
                  />
                </div>
              </div>
            </div>

            {/* Vehicle & Parking Bay Request */}
            <div>
              <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                Vehicle Type (For Reserved Parking Bay Allocation)
              </label>
              <div className="relative">
                <Car className="w-3.5 h-3.5 text-[#dfbb76] absolute left-3 top-1/2 -translate-y-1/2" />
                <select
                  value={vehicleType}
                  onChange={(e) => setVehicleType(e.target.value)}
                  className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl pl-8 pr-3 py-2 text-xs text-white focus:outline-none focus:border-[#dfbb76]"
                >
                  <option value="Luxury SUV (Fortuner / BMW / Audi)">Luxury SUV (Fortuner / BMW / Audi)</option>
                  <option value="Sedan / Hatchback">Sedan / Hatchback</option>
                  <option value="Electric Vehicle (EV Charger Needed)">Electric Vehicle (Require 60kW EV Bay)</option>
                  <option value="Pilgrim Tour Bus / Coach">Pilgrim Tour Bus / 32-50 Seater Coach</option>
                </select>
              </div>
            </div>

            {/* Darshan Aarti Synchronization */}
            <div>
              <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                Target Temple Darshan Slot
              </label>
              <select
                value={darshanSlot}
                onChange={(e) => setDarshanSlot(e.target.value)}
                className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#dfbb76]"
              >
                <option value="Kakad Aarti (04:30 AM)">Kakad Aarti (04:30 AM)</option>
                <option value="Madhyan Aarti (12:00 PM)">Madhyan Aarti (12:00 PM)</option>
                <option value="Dhoop Aarti (Sunset 06:15 PM)">Dhoop Aarti (Sunset 06:15 PM)</option>
                <option value="Shej Aarti (10:30 PM)">Shej Aarti (10:30 PM)</option>
                <option value="Regular Darshan Queue (Anytime)">Regular Darshan Queue (Anytime)</option>
              </select>
            </div>

            {/* Dietary Preference */}
            <div>
              <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                Dietary & Satvik Standard
              </label>
              <select
                value={dietaryType}
                onChange={(e) => setDietaryType(e.target.value)}
                className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-2 text-xs text-[#dfbb76] focus:outline-none focus:border-[#dfbb76]"
              >
                <option value="100% Satvik Standard">100% Satvik Standard (Pure Veg with Desi Ghee)</option>
                <option value="Strict Jain (No Root Veg, No Onion/Garlic)">Strict Jain (No Root Veg, No Onion/Garlic)</option>
                <option value="Swaminarayan Purity">Swaminarayan Purity (No Onion / Garlic)</option>
                <option value="Elder-Friendly (Low Spice / Soft Rotis)">Elder-Friendly (Low Spice / Soft Indrayani Khichdi)</option>
              </select>
            </div>

            {/* Additional Special Request */}
            <div>
              <label className="text-[11px] text-[#a1a1aa] block mb-1 font-medium">
                Special Highway Notes / Meal Pre-Order Instructions
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Traveling with elderly parents; please allocate ground-level seating near restrooms."
                className="w-full bg-[#1a1a1e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#dfbb76]"
              ></textarea>
            </div>

            {/* Submit Action */}
            <div className="pt-2">
              <button
                id="reservation-submit-btn"
                type="submit"
                className="w-full gold-shimmer-btn text-black font-semibold text-xs uppercase tracking-wider py-3.5 rounded-2xl shadow-xl flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
              >
                <BookmarkCheck className="w-4 h-4 text-black" />
                <span>CONFIRM & SAVE RESERVATION</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
