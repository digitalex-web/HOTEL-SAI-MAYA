import React, { useState, useRef, useEffect } from 'react';
import {
  Star,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Quote,
  Sparkles,
  Award,
  MapPin,
  Heart,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { VERIFIED_GUEST_REVIEWS, RESTAURANT_METADATA } from '../data/restaurantData';
import { GuestReview } from '../types';

export const ReviewsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isSwiping, setIsSwiping] = useState<boolean>(false);
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);
  const mouseStartX = useRef<number | null>(null);
  const isMouseDown = useRef<boolean>(false);

  const reviews = VERIFIED_GUEST_REVIEWS;
  const total = reviews.length;

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? total - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === total - 1 ? 0 : prev + 1));
  };

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
    touchEndX.current = null;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    const distance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 50;

    if (distance > minSwipeDistance) {
      // Swiped left -> Next
      handleNext();
    } else if (distance < -minSwipeDistance) {
      // Swiped right -> Prev
      handlePrev();
    }

    touchStartX.current = null;
    touchEndX.current = null;
  };

  // Mouse drag handlers for desktop swipe
  const handleMouseDown = (e: React.MouseEvent) => {
    isMouseDown.current = true;
    mouseStartX.current = e.clientX;
    setIsSwiping(true);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDown.current) return;
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (!isMouseDown.current || mouseStartX.current === null) return;
    const distance = mouseStartX.current - e.clientX;
    const minSwipeDistance = 60;

    if (distance > minSwipeDistance) {
      handleNext();
    } else if (distance < -minSwipeDistance) {
      handlePrev();
    }

    isMouseDown.current = false;
    mouseStartX.current = null;
    setIsSwiping(false);
  };

  const handleMouseLeave = () => {
    isMouseDown.current = false;
    mouseStartX.current = null;
    setIsSwiping(false);
  };

  // Star rating rendering helper
  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((starIndex) => {
          const isFilled = starIndex <= Math.floor(rating);
          const isHalf = !isFilled && starIndex - 0.5 <= rating;

          return (
            <Star
              key={starIndex}
              className={`w-4 h-4 ${
                isFilled
                  ? 'text-[#dfbb76] fill-[#dfbb76]'
                  : isHalf
                  ? 'text-[#dfbb76] fill-[#dfbb76]/60'
                  : 'text-zinc-600'
              }`}
            />
          );
        })}
        <span className="ml-1.5 text-xs font-mono font-bold text-[#dfbb76]">
          {rating.toFixed(1)}
        </span>
      </div>
    );
  };

  return (
    <section
      id="reviews"
      className="relative py-20 sm:py-28 bg-[#0a0a0c] border-b border-white/10 overflow-hidden text-white"
    >
      {/* Background ambient lighting vignette */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-[#dfbb76]/5 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10 space-y-12 sm:space-y-16">
        {/* ============================================================ */}
        {/* Section Header & Pilgrim Rating Banner */}
        {/* ============================================================ */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-white/10 pb-8">
          <div className="space-y-3 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1c1a16] border border-[#dfbb76]/30 text-[#e6ca92] text-xs font-mono uppercase tracking-widest shadow-sm">
              <Award className="w-3.5 h-3.5 text-[#dfbb76]" />
              <span>Verified Pilgrim Chronicles</span>
            </div>

            <h2 className="font-playfair text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
              Revered Experiences & <br className="hidden sm:inline" />
              <span className="gold-text-glow text-transparent bg-clip-text bg-gradient-to-r from-[#dfbb76] via-[#f7e7c4] to-[#c5a059]">
                Guest Testimonials
              </span>
            </h2>

            <p className="text-xs sm:text-sm text-[#a1a1aa] font-sans-ui leading-relaxed">
              Read real impressions from families, spiritual seekers, tour groups, and highway travelers paused at Hotel Sai Maya along the Shirdi–Kopargaon corridor.
            </p>
          </div>

          {/* Aggregated Score Badge */}
          <div className="bg-[#141418] border border-[#dfbb76]/30 p-5 rounded-2xl flex items-center gap-5 shadow-xl shrink-0 self-start md:self-auto">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#dfbb76] to-[#c5a059] flex flex-col items-center justify-center text-black font-cinzel font-bold shadow-md">
              <span className="text-xl leading-none">4.8</span>
              <span className="text-[9px] uppercase tracking-wider font-mono">★ INDEX</span>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-4 h-4 text-[#dfbb76] fill-[#dfbb76]" />
                ))}
              </div>
              <div className="text-xs font-mono text-white font-semibold">
                {RESTAURANT_METADATA.reviewCount} Verified Ratings
              </div>
              <div className="text-[10px] font-mono text-[#a1a1aa] flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>100% Satvik Purity Certified</span>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* Interactive Swipeable Reviews Carousel */}
        {/* ============================================================ */}
        <div className="relative space-y-8">
          {/* Controls Bar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono text-[#a1a1aa]">
              <span className="text-white font-semibold">{currentIndex + 1}</span>
              <span>of</span>
              <span>{total} Verified Reviews</span>
              <span className="hidden sm:inline text-zinc-600">• Swipe or drag cards to browse</span>
            </div>

            {/* Prev / Next Chevrons */}
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrev}
                className="w-10 h-10 rounded-xl bg-[#18181c] border border-white/10 hover:border-[#dfbb76]/40 text-[#a1a1aa] hover:text-white flex items-center justify-center transition-all shadow-md active:scale-95"
                aria-label="Previous Review"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                className="w-10 h-10 rounded-xl bg-[#18181c] border border-white/10 hover:border-[#dfbb76]/40 text-[#a1a1aa] hover:text-white flex items-center justify-center transition-all shadow-md active:scale-95"
                aria-label="Next Review"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Swipe Container */}
          <div
            className={`cursor-grab select-none active:cursor-grabbing ${
              isSwiping ? 'cursor-grabbing' : ''
            }`}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseLeave}
          >
            {/* Desktop multi-card view with active spotlight & mobile single swipe card */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[0, 1, 2].map((offset) => {
                const index = (currentIndex + offset) % total;
                const rev = reviews[index];
                const isPrimary = offset === 0;

                return (
                  <div
                    key={rev.id}
                    className={`rounded-2xl p-6 sm:p-7 flex flex-col justify-between space-y-6 transition-all duration-300 border ${
                      isPrimary
                        ? 'bg-[#141418] border-[#dfbb76]/40 shadow-2xl relative ring-1 ring-[#dfbb76]/20'
                        : 'bg-[#111114] border-white/10 hover:border-white/20 opacity-90 hidden md:flex'
                    }`}
                  >
                    {/* Top: Stars, Verified Badge & Quote Icon */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        {renderStars(rev.rating)}

                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-medium">
                          <ShieldCheck className="w-3 h-3" />
                          <span>Verified Guest</span>
                        </span>
                      </div>

                      {/* Highlighted Dish or Amenity Pill */}
                      <div className="inline-block px-2.5 py-1 rounded-md bg-[#1d1b16] border border-[#dfbb76]/20 text-[#e6ca92] text-[11px] font-mono">
                        ✨ {rev.highlightDishOrAmenity}
                      </div>

                      {/* Testimonial Quote */}
                      <div className="relative pt-1">
                        <Quote className="w-6 h-6 text-[#dfbb76]/20 absolute -top-1 -left-1" />
                        <p className="text-xs sm:text-sm text-white/90 leading-relaxed font-sans-ui italic pl-5">
                          “{rev.reviewText}”
                        </p>
                      </div>
                    </div>

                    {/* Bottom: Guest Bio & Context */}
                    <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {rev.avatarUrl ? (
                          <img
                            src={rev.avatarUrl}
                            alt={rev.guestName}
                            className="w-10 h-10 rounded-full object-cover border border-[#dfbb76]/40"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-[#1e1e24] border border-[#dfbb76]/30 flex items-center justify-center font-cinzel font-bold text-xs text-[#dfbb76]">
                            {rev.guestName.charAt(0)}
                          </div>
                        )}

                        <div>
                          <h4 className="font-cinzel text-xs font-bold text-white tracking-wide">
                            {rev.guestName}
                          </h4>
                          <p className="text-[10px] text-[#a1a1aa] font-mono flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-[#dfbb76]" />
                            <span>{rev.location}</span>
                          </p>
                          <p className="text-[10px] text-zinc-500 font-sans-ui truncate max-w-[170px]">
                            {rev.travelContext}
                          </p>
                        </div>
                      </div>

                      <div className="text-[10px] font-mono text-zinc-500 text-right">
                        {rev.reviewDate}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Dots Navigation */}
          <div className="flex items-center justify-center gap-2 pt-2">
            {reviews.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  idx === currentIndex
                    ? 'w-8 bg-[#dfbb76]'
                    : 'w-2 bg-white/20 hover:bg-white/40'
                }`}
                aria-label={`Go to review ${idx + 1}`}
              />
            ))}
          </div>
        </div>

        {/* ============================================================ */}
        {/* Trust Endorsement Strip & Google Maps Review Trigger */}
        {/* ============================================================ */}
        <div className="bg-[#121215] border border-white/10 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-12 h-12 rounded-xl bg-[#1c1a16] border border-[#dfbb76]/30 flex items-center justify-center shrink-0">
              <Sparkles className="w-6 h-6 text-[#dfbb76]" />
            </div>
            <div>
              <h4 className="font-cinzel text-sm sm:text-base font-bold text-white">
                Have you dined or celebrated at Hotel Sai Maya?
              </h4>
              <p className="text-xs text-[#a1a1aa] font-sans-ui">
                Your blessing and culinary feedback guide fellow pilgrims on the sacred Shirdi highway.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 w-full md:w-auto">
            <a
              href="https://maps.google.com/?q=Hotel+Sai+Maya+New+Veg+Shirdi"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full md:w-auto gold-btn py-2.5 px-5 rounded-xl text-xs font-cinzel font-semibold text-black flex items-center justify-center gap-2 shadow-md"
            >
              <span>Write a Google Review</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <a
              href={`https://wa.me/${RESTAURANT_METADATA.whatsappNumber}?text=${encodeURIComponent("Namaskar Hotel Sai Maya! I would like to share feedback regarding my recent dining experience.")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full md:w-auto emerald-glass-btn py-2.5 px-4 rounded-xl text-xs font-mono text-[#e6ca92] flex items-center justify-center gap-2 border border-emerald-500/30"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span>Share on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
