import React, { useState, useMemo } from 'react';
import { Sparkles, Search, Filter } from 'lucide-react';
import { MenuItem } from '../types';
import { MENU_ITEMS } from '../data/restaurantData';
import { useAdmin } from '../context/AdminContext';
import { SensoryMenuCard } from './SensoryMenuCard';

interface SensoryMenuProps {
  onAddToCart: (item: MenuItem, dietary: 'Standard Satvik' | 'Strict Jain' | 'Mild Spices' | 'Extra Desi Ghee') => void;
  addedItemIds: Set<string>;
}

export const SensoryMenu: React.FC<SensoryMenuProps> = ({ onAddToCart, addedItemIds }) => {
  const { menuItems } = useAdmin();
  const [activeTab, setActiveTab] = useState<'all' | 'thali' | 'punjabi' | 'express'>('thali');
  const [jainOnly, setJainOnly] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const tabs = [
    { id: 'thali', label: '1. Royal Thalis & Maharashtrian', shortLabel: 'Royal Thalis' },
    { id: 'punjabi', label: '2. Punjabi Gravies & Clay Tandoor', shortLabel: 'Tandoor & Gravies' },
    { id: 'express', label: '3. Express Starters & Beverages', shortLabel: 'Express & Drinks' },
    { id: 'all', label: 'Complete Tasting Registry', shortLabel: 'All Creations' },
  ];

  const sourceItems = menuItems && menuItems.length > 0 ? menuItems : MENU_ITEMS;

  const filteredItems = useMemo(() => {
    return sourceItems.filter((item) => {
      // Tab matching
      if (activeTab !== 'all' && item.category !== activeTab) {
        return false;
      }
      // Jain filter
      if (jainOnly && !item.isJainAvailable) {
        return false;
      }
      // Search matching
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesAroma = item.aromaProfile.toLowerCase().includes(query);
        const matchesStory = item.story.toLowerCase().includes(query);
        if (!matchesName && !matchesAroma && !matchesStory) {
          return false;
        }
      }
      return true;
    });
  }, [activeTab, jainOnly, searchQuery]);

  return (
    <section id="menu" className="py-24 px-4 sm:px-6 relative bg-[#0c0c0e]">
      {/* Subtle background glow */}
      <div className="absolute left-1/2 -top-24 -translate-x-1/2 w-[800px] h-[400px] bg-radial-gold opacity-50 pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-[0.25em] text-[#dfbb76] uppercase font-cinzel mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>THE SENSORY MENU EXPERIENCE</span>
          </div>
          <h2 className="font-serif-title text-3xl sm:text-5xl font-bold tracking-tight text-[#f4f4f5] leading-tight mb-4">
            Curated Highway <span className="italic font-editorial gold-gradient-text font-normal">Haute Cuisine</span>.
          </h2>
          <p className="text-sm sm:text-base text-[#a1a1aa] font-sans-ui leading-relaxed">
            Every dish is prepared to order using cold-pressed oils, pure Gir cow ghee, and freshly pounded whole masalas. No reheating, no artificial gravies—pure Satvik divinity.
          </p>
        </div>

        {/* Tab Switcher & Search Bar Hub */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-12 p-3 sm:p-4 rounded-3xl bg-[#141416]/80 backdrop-blur-2xl border border-white/10 shadow-2xl">
          {/* Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto p-1 scrollbar-none">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 rounded-full text-xs font-medium tracking-wider whitespace-nowrap transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'bg-[#dfbb76] text-black font-semibold shadow-lg scale-105'
                    : 'text-[#a1a1aa] hover:text-white hover:bg-white/5'
                }`}
              >
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.shortLabel}</span>
              </button>
            ))}
          </div>

          {/* Quick Filters: Search & Jain Option Toggle */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-end">
            {/* Search Input */}
            <div className="relative flex-1 md:w-48">
              <Search className="w-3.5 h-3.5 text-[#a1a1aa] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search flavors..."
                className="w-full bg-[#1a1a1e] border border-white/10 rounded-full pl-8 pr-4 py-1.5 text-xs text-white placeholder-[#a1a1aa]/60 focus:outline-none focus:border-[#dfbb76]/50 transition-colors"
              />
            </div>

            {/* Strict Jain Filter Pill */}
            <button
              onClick={() => setJainOnly(!jainOnly)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium border transition-all ${
                jainOnly
                  ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                  : 'bg-[#1a1a1e] border-white/10 text-[#a1a1aa] hover:border-emerald-500/40 hover:text-white'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${jainOnly ? 'bg-emerald-400' : 'bg-[#a1a1aa]/40'}`}></span>
              <span>Jain Friendly</span>
            </button>
          </div>
        </div>

        {/* Menu Cards Grid with Intersection Observer Fade & Slide */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map((item, index) => (
            <SensoryMenuCard
              key={item.id}
              item={item}
              index={index}
              isAdded={addedItemIds.has(item.id)}
              jainOnly={jainOnly}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>

        {/* Empty state fallback if search yields nothing */}
        {filteredItems.length === 0 && (
          <div className="text-center py-16 px-4 rounded-3xl bg-[#141416]/50 border border-white/10 max-w-md mx-auto">
            <Filter className="w-8 h-8 text-[#dfbb76] mx-auto mb-3 opacity-60" />
            <h3 className="text-lg font-serif-title font-semibold text-white mb-1">No Culinary Creations Match</h3>
            <p className="text-xs text-[#a1a1aa] mb-4">Try clearing your search query or toggling Jain friendly filters.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setJainOnly(false);
                setActiveTab('all');
              }}
              className="px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider bg-[#dfbb76] text-black"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
