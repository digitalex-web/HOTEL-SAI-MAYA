import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, MessageSquare, Plus, Check, Clock, Flame } from 'lucide-react';
import { MenuItem } from '../types';
import { triggerWhatsAppOrder } from '../data/restaurantData';

interface SensoryMenuCardProps {
  item: MenuItem;
  index: number;
  isAdded: boolean;
  jainOnly: boolean;
  onAddToCart: (item: MenuItem, dietary: 'Standard Satvik' | 'Strict Jain' | 'Mild Spices' | 'Extra Desi Ghee') => void;
}

export const SensoryMenuCard: React.FC<SensoryMenuCardProps> = ({
  item,
  index,
  isAdded,
  jainOnly,
  onAddToCart,
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = cardRef.current;
    if (!element) return;

    // Check for prefers-reduced-motion or missing IntersectionObserver
    if (
      typeof window === 'undefined' ||
      !('IntersectionObserver' in window) ||
      window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches
    ) {
      setIsVisible(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.unobserve(entry.target);
          }
        });
      },
      {
        root: null,
        rootMargin: '0px 0px -40px 0px',
        threshold: 0.1,
      }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, []);

  // Stagger animation slightly across columns (0ms, 80ms, 160ms)
  const staggerDelay = `${(index % 3) * 80}ms`;

  return (
    <div
      ref={cardRef}
      id={`menu-card-${item.id}`}
      style={{
        transitionDelay: isVisible ? staggerDelay : '0ms',
      }}
      className={`group relative rounded-3xl bg-[#141416]/90 border border-white/10 hover:border-[#dfbb76]/40 overflow-hidden flex flex-col justify-between shadow-2xl hover:shadow-[0_20px_50px_rgba(0,0,0,0.8)] transition-all duration-700 ease-out will-change-transform ${
        isVisible
          ? 'opacity-100 translate-y-0 scale-100'
          : 'opacity-0 translate-y-10 scale-[0.97] pointer-events-none'
      }`}
    >
      {/* Culinary Image with Smooth Zoom */}
      <div className="relative h-56 sm:h-60 overflow-hidden bg-[#1a1a1e]">
        <img
          src={item.image}
          alt={item.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out brightness-90 group-hover:brightness-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#141416] via-[#141416]/20 to-transparent"></div>

        {/* Dietary Jeweled Markers */}
        <div className="absolute top-3 left-3 flex items-center gap-2">
          {/* 100% Pure Veg Symbol Marker */}
          <div className="w-5 h-5 rounded-md bg-[#0c0c0e]/90 border border-emerald-500/60 backdrop-blur-md flex items-center justify-center p-0.5 shadow-md">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]"></span>
          </div>

          {item.isJainAvailable && (
            <span className="text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 backdrop-blur-md">
              Jain Available
            </span>
          )}

          {item.isSignature && (
            <span className="text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded-full bg-[#dfbb76]/20 border border-[#dfbb76]/40 text-[#dfbb76] backdrop-blur-md flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              Signature
            </span>
          )}
        </div>

        {/* Cooking Time / Ready Speed */}
        <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#0c0c0e]/85 border border-white/10 text-[11px] text-[#a1a1aa] font-mono backdrop-blur-md">
          <Clock className="w-3 h-3 text-[#dfbb76]" />
          <span>~{item.cookingTimeMinutes}m</span>
        </div>

        {/* Live Price Badge */}
        <div className="absolute bottom-3 right-4 px-3.5 py-1 rounded-full bg-black/80 border border-[#dfbb76]/30 backdrop-blur-md">
          <span className="font-cinzel text-base font-bold text-[#dfbb76] tracking-wide">
            ₹{item.price}
          </span>
        </div>
      </div>

      {/* Card Content & Flavor Story */}
      <div className="p-6 flex-1 flex flex-col justify-between">
        <div>
          {/* Category tag & Spice indicator */}
          <div className="flex items-center justify-between text-[11px] text-[#a1a1aa] uppercase tracking-wider mb-2 font-mono">
            <span className="text-[#dfbb76]/90">{item.categoryLabel}</span>
            <span className="flex items-center gap-1 text-white/60">
              <Flame className="w-3 h-3 text-amber-500" />
              {item.spiciness}
            </span>
          </div>

          {/* Dish Name */}
          <h3 className="font-serif-title text-lg sm:text-xl font-bold text-[#f4f4f5] group-hover:text-[#dfbb76] transition-colors leading-snug mb-2.5">
            {item.name}
          </h3>

          {/* Aroma Profile */}
          <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5 mb-3">
            <span className="text-[10px] font-semibold tracking-wider text-[#dfbb76] uppercase font-cinzel block mb-0.5">
              Aroma Profile:
            </span>
            <p className="text-xs text-[#a1a1aa] italic font-editorial leading-relaxed">
              "{item.aromaProfile}"
            </p>
          </div>

          {/* Dish Story */}
          <p className="text-xs text-[#a1a1aa]/90 leading-relaxed font-sans-ui line-clamp-3 mb-6">
            {item.story}
          </p>
        </div>

        {/* Interactive Action Triggers */}
        <div className="pt-4 border-t border-white/5 flex items-center gap-2.5">
          {/* Add to Tray Button */}
          <button
            onClick={() => onAddToCart(item, item.isJainAvailable && jainOnly ? 'Strict Jain' : 'Standard Satvik')}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              isAdded
                ? 'bg-emerald-950 border border-emerald-500/60 text-emerald-300 shadow-md'
                : 'bg-[#1a1a1e] border border-white/10 hover:border-[#dfbb76]/50 text-white hover:bg-white/5'
            }`}
          >
            {isAdded ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>In Tray ({item.name.split(' ')[0]})</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5 text-[#dfbb76]" />
                <span>Add to Tray</span>
              </>
            )}
          </button>

          {/* Direct WhatsApp Pre-Order Button */}
          <button
            onClick={() =>
              triggerWhatsAppOrder({
                itemName: item.name,
                price: item.price,
                dietary: jainOnly ? 'Strict Jain Option' : 'Standard Satvik',
              })
            }
            title="Direct WhatsApp Pre-Order this dish"
            className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-600/30 hover:border-emerald-500 hover:bg-emerald-900/60 text-emerald-300 transition-all flex items-center justify-center group/wa cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-emerald-400 group-hover/wa:scale-110 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};
