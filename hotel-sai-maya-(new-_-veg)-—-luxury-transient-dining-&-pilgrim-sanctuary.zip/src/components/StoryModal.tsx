import React, { useState, useEffect } from 'react';
import { X, Heart, MessageCircle, Share2, Volume2, VolumeX, CheckCircle, Instagram, Sparkles } from 'lucide-react';
import { InstagramStoryItem } from '../types';
import { RESTAURANT_METADATA } from '../data/restaurantData';

interface StoryModalProps {
  story: InstagramStoryItem | null;
  onClose: () => void;
  onNext?: () => void;
  onPrev?: () => void;
}

export const StoryModal: React.FC<StoryModalProps> = ({ story, onClose }) => {
  const [isLiked, setIsLiked] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!story) return;
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 1.2;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [story]);

  if (!story) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="relative w-full max-w-sm sm:max-w-md h-[80vh] max-h-[720px] rounded-3xl overflow-hidden bg-[#141416] border border-white/20 shadow-2xl flex flex-col justify-between">
        {/* Story Progress Bar */}
        <div className="absolute top-3 inset-x-3 z-30 flex items-center gap-1.5">
          <div className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-75"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Story Header */}
        <div className="relative z-30 pt-6 px-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full p-0.5 bg-gradient-to-tr from-[#dfbb76] via-[#c5a059] to-emerald-500">
              <div className="w-full h-full rounded-full bg-black flex items-center justify-center font-cinzel text-xs font-bold text-[#dfbb76]">
                SM
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-xs font-semibold">
                <span>hotel_sai_maya_new</span>
                <CheckCircle className="w-3.5 h-3.5 text-blue-400 fill-blue-400/20" />
              </div>
              <span className="text-[10px] text-white/70">{story.timestamp} • {story.badge}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-1.5 rounded-full bg-black/40 text-white/80 hover:text-white"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-black/40 text-white/80 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Background Visual */}
        <div className="absolute inset-0 z-10">
          <img
            src={story.image}
            alt={story.title}
            className="w-full h-full object-cover object-center brightness-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"></div>
        </div>

        {/* Bottom Interactive Layer & Caption */}
        <div className="relative z-30 p-5 flex flex-col gap-3 text-white">
          <div className="p-3.5 rounded-2xl bg-black/60 backdrop-blur-md border border-white/10">
            <div className="flex items-center gap-2 text-[#dfbb76] text-xs font-semibold uppercase tracking-wider mb-1 font-cinzel">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{story.title}</span>
            </div>
            <p className="text-xs text-white/90 leading-relaxed font-sans-ui">
              {story.caption}
            </p>
          </div>

          {/* Social Interactions */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsLiked(!isLiked)}
                className="flex items-center gap-1.5 text-xs text-white hover:text-rose-400 transition-colors"
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'text-rose-500 fill-rose-500 animate-pulse' : ''}`} />
                <span>{isLiked ? 'Liked' : story.likes}</span>
              </button>
              <div className="flex items-center gap-1.5 text-xs text-white/80">
                <MessageCircle className="w-5 h-5" />
                <span>{story.comments}</span>
              </div>
            </div>

            <a
              href={`https://instagram.com/${RESTAURANT_METADATA.instagramHandle.replace('@', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-medium backdrop-blur-sm border border-white/20 text-white transition-colors"
            >
              <Instagram className="w-3.5 h-3.5 text-[#dfbb76]" />
              <span>View Profile</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
