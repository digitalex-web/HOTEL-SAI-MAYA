import React, { useState } from 'react';
import { ShieldCheck, Sparkles, Clock, Compass, Zap, Car, Bus, Bath, ArrowRight, CheckCircle2 } from 'lucide-react';
import { TRANSIT_AMENITIES } from '../data/restaurantData';

interface TransitConciergeProps {
  onPreOrder: () => void;
}

export const TransitConcierge: React.FC<TransitConciergeProps> = ({ onPreOrder }) => {
  const [selectedAarti, setSelectedAarti] = useState<string>('Madhyan Aarti (12:00 PM)');

  const aartiSchedule = [
    { name: 'Kakad Aarti (04:30 AM)', recommendedArrival: '03:15 AM', notes: 'Pre-darshan light Satvik Tea & Bun Maska' },
    { name: 'Madhyan Aarti (12:00 PM)', recommendedArrival: '10:45 AM', notes: 'Royal Imperial Thali before midday queue' },
    { name: 'Dhoop Aarti (Sunset 06:15 PM)', recommendedArrival: '04:45 PM', notes: 'Tandoor starters & refreshing Sol Kadhi' },
    { name: 'Shej Aarti (10:30 PM)', recommendedArrival: '09:00 PM', notes: 'Calming Indrayani Khichdi with Gir cow ghee' },
  ];

  const currentAarti = aartiSchedule.find((a) => a.name === selectedAarti) || aartiSchedule[1];

  return (
    <section id="transit" className="py-24 px-4 sm:px-6 relative bg-[#0c0c0e]">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-[0.25em] text-[#dfbb76] uppercase font-cinzel mb-3">
            <Compass className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>TRANSIT CONCIERGE & HIGHWAY SANCTUARY</span>
          </div>
          <h2 className="font-serif-title text-3xl sm:text-5xl font-bold tracking-tight text-[#f4f4f5] leading-tight mb-4">
            Engineered for the <span className="italic font-editorial gold-gradient-text font-normal">Highway Discerning</span>.
          </h2>
          <p className="text-sm sm:text-base text-[#a1a1aa] font-sans-ui leading-relaxed">
            We understand the exact rhythm of a Shirdi pilgrimage. From secure luxury parking to sterilized executive washrooms and 15-minute table turnarounds, our amenities remove highway friction.
          </p>
        </div>

        {/* 4 Pillar Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 mb-16">
          {TRANSIT_AMENITIES.map((amenity) => (
            <div
              key={amenity.id}
              className="p-8 rounded-3xl bg-[#141416]/90 border border-white/10 hover:border-[#dfbb76]/40 transition-all duration-300 shadow-2xl flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#1a1a1e] border border-white/10 flex items-center justify-center text-[#dfbb76] group-hover:border-[#dfbb76]/50 group-hover:scale-105 transition-all">
                    {amenity.iconName === 'ShieldCheck' && <ShieldCheck className="w-6 h-6" />}
                    {amenity.iconName === 'Sparkles' && <Sparkles className="w-6 h-6" />}
                    {amenity.iconName === 'Clock' && <Clock className="w-6 h-6" />}
                    {amenity.iconName === 'Compass' && <Compass className="w-6 h-6" />}
                  </div>
                  <span className="text-[10px] uppercase font-semibold tracking-wider px-3 py-1 rounded-full bg-[#1a1a1e] border border-white/10 text-[#e6ca92]">
                    {amenity.badge}
                  </span>
                </div>

                <h3 className="font-serif-title text-xl font-bold text-white group-hover:text-[#dfbb76] transition-colors mb-1">
                  {amenity.title}
                </h3>
                <span className="text-xs text-[#dfbb76]/80 font-mono tracking-wide block mb-3">
                  {amenity.subtitle}
                </span>

                <p className="text-sm text-[#a1a1aa] leading-relaxed mb-6 font-sans-ui">
                  {amenity.description}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex flex-wrap gap-2">
                {amenity.features.map((feat, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 text-xs text-white/90 bg-white/[0.03] border border-white/10 px-3 py-1.5 rounded-full"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    {feat}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Interactive Highway Transit Aarti Synchronizer */}
        <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-[#141416] via-[#1a1a1e] to-[#141416] border border-[#dfbb76]/30 shadow-2xl relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-[#c5a059]/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-[#dfbb76] uppercase font-cinzel mb-2">
                <Clock className="w-3.5 h-3.5" />
                <span>RUSH DARSHAN SYNCHRONICITY</span>
              </div>
              <h3 className="font-serif-title text-2xl sm:text-3xl font-bold text-white mb-3">
                Synchronize Your Dining with Shirdi Temple Aartis.
              </h3>
              <p className="text-xs sm:text-sm text-[#a1a1aa] leading-relaxed mb-6">
                Never stress about missing temple queue tokens. Select your planned darshan time below, and our express culinary brigade will ensure your table and food are ready the minute your vehicle pulls into MH SH 10.
              </p>

              {/* Aarti selector pill buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-6">
                {aartiSchedule.map((aarti) => (
                  <button
                    key={aarti.name}
                    onClick={() => setSelectedAarti(aarti.name)}
                    className={`text-left p-3 rounded-2xl border transition-all text-xs ${
                      selectedAarti === aarti.name
                        ? 'bg-[#dfbb76]/15 border-[#dfbb76] text-white shadow-md'
                        : 'bg-[#0c0c0e]/60 border-white/10 text-[#a1a1aa] hover:border-white/20'
                    }`}
                  >
                    <div className="font-semibold text-white mb-0.5">{aarti.name}</div>
                    <div className="text-[11px] text-[#dfbb76] font-mono">Arrive by: {aarti.recommendedArrival}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Calculated Advice Box */}
            <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0c0c0e]/80 border border-white/10 backdrop-blur-xl flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#a1a1aa] block mb-1">
                  RECOMMENDED HIGHWAY INGRESS
                </span>
                <div className="text-2xl font-cinzel font-bold text-[#dfbb76] mb-1">
                  {currentAarti.recommendedArrival}
                </div>
                <div className="text-xs text-white/90 font-medium mb-3">
                  Target Aarti: {currentAarti.name}
                </div>
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs text-[#a1a1aa] italic font-editorial mb-6">
                  "{currentAarti.notes}"
                </div>
              </div>

              <button
                onClick={onPreOrder}
                className="w-full gold-shimmer-btn text-black font-semibold text-xs uppercase tracking-wider py-3.5 rounded-xl shadow-lg flex items-center justify-center gap-2"
              >
                <span>Pre-Order for {currentAarti.recommendedArrival}</span>
                <ArrowRight className="w-4 h-4 text-black" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
