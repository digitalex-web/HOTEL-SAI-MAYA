import React from 'react';
import { useAdmin } from '../../context/AdminContext';
import {
  PhoneCall,
  UtensilsCrossed,
  Landmark,
  Star,
  Image as ImageIcon,
  Users,
  Plus,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Edit3,
  Calendar,
  Sparkles,
  ShieldAlert
} from 'lucide-react';

interface AdminDashboardProps {
  onOpenAddMenuModal: () => void;
  onOpenAddMediaModal: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onOpenAddMenuModal,
  onOpenAddMediaModal
}) => {
  const {
    stats,
    activities,
    enquiries,
    setActiveNav,
    setActiveSubNav,
    businessSettings,
    currentUser
  } = useAdmin();

  // Top Statistics Cards
  const statCards = [
    {
      id: 'stat-enquiries',
      title: "Today's Enquiries",
      value: stats.todayEnquiriesCount,
      icon: PhoneCall,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      badge: `${enquiries.filter(e => e.status === 'new').length} New Unread`,
      action: () => setActiveNav('enquiries')
    },
    {
      id: 'stat-menu',
      title: 'Active Menu Items',
      value: stats.totalMenuItemsCount,
      icon: UtensilsCrossed,
      color: 'bg-amber-50 text-[#b38938] border-amber-200',
      badge: '3 Categories Live',
      action: () => setActiveNav('restaurant')
    },
    {
      id: 'stat-banquet',
      title: 'Banquet Enquiries',
      value: stats.banquetEnquiriesCount,
      icon: Landmark,
      color: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      badge: 'October–Nov 2026',
      action: () => {
        setActiveNav('banquet');
        setActiveSubNav('banquet-enquiries');
      }
    },
    {
      id: 'stat-reviews',
      title: 'Verified Reviews',
      value: stats.reviewsCount,
      icon: Star,
      color: 'bg-yellow-50 text-yellow-700 border-yellow-200',
      badge: '4.8★ Pilgrim Index',
      action: () => setActiveNav('reviews')
    },
    {
      id: 'stat-gallery',
      title: 'Gallery Images',
      value: stats.galleryImagesCount,
      icon: ImageIcon,
      color: 'bg-sky-50 text-sky-700 border-sky-200',
      badge: 'WebP Optimized',
      action: () => setActiveNav('media')
    },
    {
      id: 'stat-visitors',
      title: 'Website Visitors',
      value: stats.visitorCount,
      icon: Users,
      color: 'bg-purple-50 text-purple-700 border-purple-200',
      badge: 'Active Sessions',
      action: () => setActiveNav('settings')
    }
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Welcome Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-100 text-[#b38938]">
              {currentUser?.role || 'Staff Operator'}
            </span>
            <span className="text-xs text-slate-500">
              Welcome back, {currentUser?.name || 'Administrator'}
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Hotel Sai Maya Operations Desk
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Live management suite for pure vegetarian highway dining, 80+ vehicle parking, banquet calendar availability, and guest enquiries on MH SH 10.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenAddMenuModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Menu Item</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveNav('enquiries')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            <span>View Enquiries</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Top Connected Statistics */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-600">
            System Operating Statistics (Real Connected Data)
          </h2>
          <span className="text-[11px] text-slate-500">Auto-synchronized with database & enquiries</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {statCards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.id}
                type="button"
                onClick={card.action}
                className="text-left bg-white p-4 rounded-xl border border-slate-200 hover:border-[#c5a059] shadow-sm hover:shadow transition-all group cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center border ${card.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-medium text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                    {card.badge}
                  </span>
                </div>
                <div className="text-2xl font-bold text-slate-900 font-mono tracking-tight group-hover:text-[#b38938] transition-colors">
                  {card.value}
                </div>
                <div className="text-xs font-medium text-slate-600 mt-1 truncate">
                  {card.title}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Quick Actions & Highway Operational Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions Panel */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-4 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#b38938]" />
            <span>Quick Actions</span>
          </h3>
          <div className="space-y-2.5">
            <button
              type="button"
              onClick={onOpenAddMenuModal}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-[#c5a059] hover:bg-amber-50/40 text-left transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-100 text-[#b38938] flex items-center justify-center font-bold">
                  🍽️
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-[#b38938]">
                    + Add Menu Item
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Publish new thali, sabzi, or beverage
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#b38938]" />
            </button>

            <button
              type="button"
              onClick={onOpenAddMediaModal}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-[#c5a059] hover:bg-amber-50/40 text-left transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
                  📸
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-[#b38938]">
                    + Add Gallery Image
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Upload dining, banquet, or food photograph
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#b38938]" />
            </button>

            <button
              type="button"
              id="dashboard-edit-current-image-btn"
              onClick={() => setActiveNav('media')}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-[#c5a059] hover:bg-amber-50/40 text-left transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-100 text-[#b38938] flex items-center justify-center font-bold">
                  🖼️
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-[#b38938]">
                    Edit Current Image
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Modify active dining, banquet hall, or facade photos
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#b38938]" />
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveNav('banquet');
                setActiveSubNav('banquet-availability');
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-[#c5a059] hover:bg-amber-50/40 text-left transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                  🏛️
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-[#b38938]">
                    + Add Banquet Event / Date
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Update calendar booking & slot reservations
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#b38938]" />
            </button>

            <button
              type="button"
              onClick={() => setActiveNav('website')}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-[#c5a059] hover:bg-amber-50/40 text-left transition-colors group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                  🌐
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-[#b38938]">
                    Edit Homepage Content
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Adjust hero message, CTAs, and section order
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#b38938]" />
            </button>
          </div>
        </div>

        {/* Recent Activity Stream */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" />
              <span>Recent Activity Feed</span>
            </h3>
            <span className="text-xs text-slate-500">
              Live Operations Log
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {activities.slice(0, 5).map((act) => (
              <div key={act.id} className="py-3.5 flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#c5a059] mt-1.5 shrink-0" />
                  <div>
                    <div className="text-xs font-semibold text-slate-900">{act.title}</div>
                    {act.details && (
                      <div className="text-[11px] text-slate-500 mt-0.5">{act.details}</div>
                    )}
                    <div className="text-[10px] text-slate-400 mt-1">
                      By {act.actor} • {act.timestamp}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                  {act.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Blueprint Feature #23: "Edit Website" Overview Grid */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-base font-serif font-bold text-slate-900">
              Website Content Management Hub
            </h3>
            <p className="text-xs text-slate-500">
              Update any public website section directly without modifying code.
            </p>
          </div>
          <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 inline-flex items-center gap-1 w-fit">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Client-Manageable CMS Active
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            {
              title: 'Homepage Hero & Headings',
              desc: 'Edit hero titles, subtitle, background image, CTA buttons',
              btnText: 'EDIT',
              action: () => setActiveNav('website')
            },
            {
              title: 'Restaurant Menu & Thalis',
              desc: 'Manage categories, dishes, prices, Jain options, and availability',
              btnText: 'MANAGE',
              action: () => setActiveNav('restaurant')
            },
            {
              title: 'Banquet Hall & Packages',
              desc: 'Set capacity placeholders, facilities toggles, packages, and calendar',
              btnText: 'MANAGE',
              action: () => setActiveNav('banquet')
            },
            {
              title: 'Media Gallery & Photos',
              desc: 'Upload restaurant dining, food, and celebration photos',
              btnText: 'MANAGE',
              action: () => setActiveNav('media')
            },
            {
              title: 'Verified Guest Reviews',
              desc: 'Moderate testimonials, toggle website display, Google review index',
              btnText: 'MANAGE',
              action: () => setActiveNav('reviews')
            },
            {
              title: 'Location & Google Maps',
              desc: 'Update address, coordinates, route info, and landmark distances',
              btnText: 'EDIT',
              action: () => setActiveNav('location')
            },
            {
              title: 'Business Info & Hours',
              desc: 'Phone, WhatsApp, email, daily opening/closing schedules',
              btnText: 'EDIT',
              action: () => setActiveNav('settings')
            },
            {
              title: 'WhatsApp Concierge',
              desc: 'Pre-order routing, takeaway triggers, and auto-generated message templates',
              btnText: 'EDIT',
              action: () => {
                setActiveNav('settings');
                setActiveSubNav('settings-whatsapp');
              }
            },
            {
              title: 'SEO & Social Tags',
              desc: 'Page titles, meta descriptions, keywords, and OpenGraph share card',
              btnText: 'EDIT',
              action: () => {
                setActiveNav('website');
                setActiveSubNav('website-seo');
              }
            }
          ].map((item, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 flex flex-col justify-between gap-3"
            >
              <div>
                <h4 className="text-xs font-bold text-slate-900">{item.title}</h4>
                <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{item.desc}</p>
              </div>
              <button
                type="button"
                onClick={item.action}
                className="w-full py-1.5 px-3 bg-white hover:bg-amber-50 border border-slate-300 hover:border-[#c5a059] text-[11px] font-bold text-slate-700 hover:text-[#b38938] rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span>[{item.btnText}]</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
