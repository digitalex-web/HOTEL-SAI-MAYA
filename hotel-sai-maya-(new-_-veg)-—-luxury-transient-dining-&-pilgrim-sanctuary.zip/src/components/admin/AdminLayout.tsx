import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { AdminLogin } from './AdminLogin';
import { AdminDashboard } from './AdminDashboard';
import { MenuManager } from './MenuManager';
import { BanquetManager } from './BanquetManager';
import { EnquiryManager } from './EnquiryManager';
import { WebsiteManager } from './WebsiteManager';
import { MediaManager } from './MediaManager';
import { ReviewManager } from './ReviewManager';
import { BusinessSettings } from './BusinessSettings';
import { LocationManager } from './LocationManager';
import { SEOManager } from './SEOManager';
import { StaffManager } from './StaffManager';
import { SystemSettings } from './SystemSettings';
import { AdminNavSection } from '../../types';
import {
  LayoutDashboard,
  Globe,
  UtensilsCrossed,
  Building2,
  PhoneCall,
  Image as ImageIcon,
  Star,
  Settings,
  MapPin,
  Search,
  Users,
  ShieldAlert,
  LogOut,
  ExternalLink,
  Bell,
  Menu as MenuIcon,
  X,
  Plus,
  ChevronDown,
  Sparkles,
  Edit3
} from 'lucide-react';

export const AdminLayout: React.FC = () => {
  const {
    isAuthenticated,
    currentUser,
    logout,
    activeNav,
    setActiveNav,
    setActiveSubNav,
    toggleAdminMode,
    stats,
    enquiries
  } = useAdmin();

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAddMenuModalOpen, setIsAddMenuModalOpen] = useState(false);
  const [isAddMediaModalOpen, setIsAddMediaModalOpen] = useState(false);
  const [isQuickAddDropdown, setIsQuickAddDropdown] = useState(false);
  const [isProfileDropdown, setIsProfileDropdown] = useState(false);

  // If unauthenticated, show the secure login screen
  if (!isAuthenticated) {
    return <AdminLogin />;
  }

  const navItems: { id: AdminNavSection; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string | number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'website', label: 'Website Manager', icon: Globe },
    { id: 'restaurant', label: 'Restaurant Menu', icon: UtensilsCrossed, badge: stats.totalMenuItemsCount },
    { id: 'banquet', label: 'Banquet Hall', icon: Building2 },
    { id: 'enquiries', label: 'Enquiries', icon: PhoneCall, badge: enquiries.filter(e => e.status === 'new').length || undefined },
    { id: 'media', label: 'Gallery & Photos', icon: ImageIcon },
    { id: 'reviews', label: 'Reviews & Feedback', icon: Star },
    { id: 'settings', label: 'Business Settings', icon: Settings },
    { id: 'location', label: 'Location & Map', icon: MapPin },
    { id: 'seo', label: 'SEO & Meta Tags', icon: Search },
    { id: 'users', label: 'Staff & Users', icon: Users },
    { id: 'backup', label: 'System & Backups', icon: ShieldAlert }
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col font-sans antialiased">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
        <div className="flex items-center justify-between px-4 sm:px-6 h-16">
          {/* Brand & Mobile Hamburger */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg lg:hidden transition-colors cursor-pointer"
              title="Toggle sidebar"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-[#141416] text-[#dfbb76] font-serif font-bold text-sm flex items-center justify-center border border-[#c5a059]/40 shadow-xs">
                SM
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 tracking-wider uppercase font-serif">
                  Hotel Sai Maya
                </div>
                <div className="text-[10px] text-slate-400 font-medium">
                  Operations & Sanctuary Admin Panel
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions, View Site, User Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Add Button Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsQuickAddDropdown(!isQuickAddDropdown)}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {isQuickAddDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-slate-200 py-1.5 z-50 animate-fadeIn">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('restaurant');
                      setIsAddMenuModalOpen(true);
                      setIsQuickAddDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <UtensilsCrossed className="w-3.5 h-3.5 text-[#b38938]" />
                    <span>Add Menu Item</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('banquet');
                      setActiveSubNav('banquet-packages');
                      setIsQuickAddDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Add Banquet Package</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('enquiries');
                      setIsQuickAddDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Log Banquet Enquiry</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('media');
                      setIsAddMediaModalOpen(true);
                      setIsQuickAddDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-sky-600" />
                    <span>Upload Photo</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('media');
                      setIsQuickAddDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-[#b38938]" />
                    <span>Edit Current Image</span>
                  </button>
                </div>
              )}
            </div>

            {/* View Live Website Button */}
            <button
              type="button"
              onClick={() => toggleAdminMode(false)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Return to Public Website View"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#b38938]" />
              <span className="hidden md:inline">View Public Website</span>
            </button>

            {/* Notifications Bell */}
            <button
              type="button"
              onClick={() => setActiveNav('enquiries')}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg relative transition-colors cursor-pointer"
              title="View Enquiries"
            >
              <Bell className="w-4 h-4" />
              {enquiries.filter((e) => e.status === 'new').length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#b38938]" />
              )}
            </button>

            {/* User Profile Pill & Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsProfileDropdown(!isProfileDropdown)}
                className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-semibold text-xs flex items-center justify-center">
                  {currentUser?.name?.charAt(0) || 'A'}
                </div>
                <div className="text-left hidden lg:block">
                  <div className="text-xs font-bold text-slate-900 leading-tight">
                    {currentUser?.name || 'Administrator'}
                  </div>
                  <div className="text-[10px] text-slate-500 capitalize">
                    {currentUser?.role?.replace('_', ' ') || 'Super Admin'}
                  </div>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isProfileDropdown && (
                <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-lg border border-slate-200 py-2 z-50 animate-fadeIn">
                  <div className="px-3.5 py-2 border-b border-slate-100">
                    <div className="text-xs font-bold text-slate-900">{currentUser.name}</div>
                    <div className="text-[11px] text-slate-500 truncate">{currentUser.email}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('backup');
                      setIsProfileDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <Settings className="w-3.5 h-3.5 text-slate-400" />
                    <span>Security & Profile</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      logout();
                      setIsProfileDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5 text-rose-500" />
                    <span>Logout of Dashboard</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Administrative Workspace */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <aside
          className={`fixed inset-y-0 left-0 z-30 w-64 bg-white border-r border-slate-200 transform transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 flex flex-col justify-between ${
            isSidebarOpen ? 'translate-x-0' : '-translate-x-0 max-lg:-translate-x-full'
          }`}
        >
          {/* Navigation Items */}
          <div className="p-3 space-y-1 overflow-y-auto flex-1">
            <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Operations Navigation
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveNav(item.id);
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-amber-50 text-[#b38938] font-bold border border-[#c5a059]/30'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#b38938]' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                        isActive
                          ? 'bg-[#b38938] text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Sidebar Footer */}
          <div className="p-3 border-t border-slate-200 bg-slate-50/70">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="text-[11px] font-mono">v3.2 Hotel CMS</span>
              <button
                type="button"
                onClick={logout}
                className="text-[11px] font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
              >
                <LogOut className="w-3 h-3" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </aside>

        {/* Content View Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#f8fafc]">
          {activeNav === 'dashboard' && (
            <AdminDashboard
              onOpenAddMenuModal={() => {
                setActiveNav('restaurant');
                setIsAddMenuModalOpen(true);
              }}
              onOpenAddMediaModal={() => {
                setActiveNav('media');
                setIsAddMediaModalOpen(true);
              }}
            />
          )}

          {activeNav === 'website' && <WebsiteManager />}

          {activeNav === 'restaurant' && (
            <MenuManager
              isOpenAddModal={isAddMenuModalOpen}
              onCloseAddModal={() => setIsAddMenuModalOpen(false)}
            />
          )}

          {activeNav === 'banquet' && <BanquetManager />}

          {activeNav === 'enquiries' && <EnquiryManager />}

          {activeNav === 'media' && (
            <MediaManager
              isOpenAddModal={isAddMediaModalOpen}
              onCloseAddModal={() => setIsAddMediaModalOpen(false)}
            />
          )}

          {activeNav === 'reviews' && <ReviewManager />}

          {activeNav === 'settings' && <BusinessSettings />}

          {activeNav === 'location' && <LocationManager />}

          {activeNav === 'seo' && <SEOManager />}

          {activeNav === 'users' && <StaffManager />}

          {activeNav === 'backup' && <SystemSettings />}
        </main>
      </div>
    </div>
  );
};
