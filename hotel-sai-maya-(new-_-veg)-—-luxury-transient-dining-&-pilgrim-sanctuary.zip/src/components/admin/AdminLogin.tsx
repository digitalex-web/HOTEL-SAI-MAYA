import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { StaffRole } from '../../types';
import {
  Lock,
  Mail,
  Eye,
  EyeOff,
  ShieldCheck,
  ArrowLeft,
  KeyRound,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const AdminLogin: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const { login, staffUsers } = useAdmin();
  const [email, setEmail] = useState('admin@hotelsaimaya.com');
  const [password, setPassword] = useState('saimaya2026');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [enable2FA, setEnable2FA] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [error, setError] = useState('');
  const [forgotModal, setForgotModal] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Please provide both email and password.');
      return;
    }

    if (enable2FA && otpCode.length < 4) {
      setError('Please enter the 6-digit security authentication OTP.');
      return;
    }

    const success = login(email);
    if (!success) {
      setError('Invalid credentials. Please verify your administrative access.');
    }
  };

  const handleQuickDemoLogin = (userEmail: string, role: StaffRole) => {
    setEmail(userEmail);
    setPassword('demo-session-verified');
    login(userEmail, role);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans selection:bg-[#c5a059]/30">
      {/* Top Brand Bar */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center px-4">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-[#c5a059] to-[#8f6d2b] shadow-xl shadow-black/40 mb-4 border border-[#e6cca0]/30">
          <span className="text-white font-serif text-2xl font-bold tracking-tight">SM</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-serif font-medium tracking-tight text-white">
          HOTEL SAI MAYA
        </h2>
        <p className="mt-1 text-xs uppercase tracking-widest text-[#dfbb76] font-medium">
          Management & Operations Portal
        </p>
        <p className="mt-2 text-sm text-slate-400">
          Highway State Highway 10 • Restaurant, Banquet & Website CMS
        </p>
      </div>

      {/* Main Login Card */}
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div className="bg-white py-8 px-6 shadow-2xl rounded-2xl sm:px-10 border border-slate-200">
          {error && (
            <div className="mb-5 p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-center gap-2 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          <form className="space-y-5" onSubmit={handleSubmit}>
            {/* Email / Username */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Email / Username
              </label>
              <div className="relative rounded-lg shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Mail className="h-4 w-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@hotelsaimaya.com"
                  className="block w-full pl-10 pr-3 py-2.5 sm:text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059] focus:border-[#c5a059] text-slate-900 bg-white placeholder-slate-400"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setForgotModal(true)}
                  className="text-xs font-medium text-[#b38938] hover:text-[#8f6d2b] transition-colors"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative rounded-lg shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="h-4 w-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="block w-full pl-10 pr-10 py-2.5 sm:text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059] focus:border-[#c5a059] text-slate-900 bg-white placeholder-slate-400"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* 2FA Optional Toggle */}
            <div className="pt-1">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-600">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-slate-300 text-[#b38938] focus:ring-[#c5a059]"
                  />
                  <span>Remember this device</span>
                </label>
                <button
                  type="button"
                  onClick={() => setEnable2FA(!enable2FA)}
                  className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-[#b38938]" />
                  <span>{enable2FA ? '2FA Active' : 'Enable 2FA'}</span>
                </button>
              </div>

              {enable2FA && (
                <div className="mt-3 p-3 bg-slate-50 rounded-lg border border-slate-200 animate-fadeIn">
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Enter 6-Digit Authenticator / SMS Code
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="e.g. 842190"
                    className="w-full tracking-widest text-center font-mono py-1.5 text-sm border border-slate-300 rounded-md focus:ring-[#c5a059] focus:border-[#c5a059]"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Test code: enter any 4+ digits to proceed.</p>
                </div>
              )}
            </div>

            {/* Secure Login CTA */}
            <div>
              <button
                type="submit"
                className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-semibold text-white bg-gradient-to-r from-[#b38938] via-[#c5a059] to-[#8f6d2b] hover:opacity-95 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#c5a059] transition-all cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Secure Sign In</span>
              </button>
            </div>
          </form>

          {/* Quick Demo Login Hub */}
          <div className="mt-6 pt-5 border-t border-slate-200">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider text-center mb-3">
              One-Click Role Simulation
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('admin@hotelsaimaya.com', 'Super Admin')}
                className="px-2.5 py-2 text-left bg-slate-50 hover:bg-amber-50/50 border border-slate-200 hover:border-[#c5a059]/40 rounded-lg transition-colors group cursor-pointer"
              >
                <div className="text-[11px] font-bold text-slate-900 group-hover:text-[#b38938]">Super Admin</div>
                <div className="text-[10px] text-slate-500">Rajendra K. (Full Access)</div>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('banquet@hotelsaimaya.com', 'Banquet Manager')}
                className="px-2.5 py-2 text-left bg-slate-50 hover:bg-amber-50/50 border border-slate-200 hover:border-[#c5a059]/40 rounded-lg transition-colors group cursor-pointer"
              >
                <div className="text-[11px] font-bold text-slate-900 group-hover:text-[#b38938]">Banquet Manager</div>
                <div className="text-[10px] text-slate-500">Sneha D. (Events & Hall)</div>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('manager@hotelsaimaya.com', 'Manager')}
                className="px-2.5 py-2 text-left bg-slate-50 hover:bg-amber-50/50 border border-slate-200 hover:border-[#c5a059]/40 rounded-lg transition-colors group cursor-pointer"
              >
                <div className="text-[11px] font-bold text-slate-900 group-hover:text-[#b38938]">General Manager</div>
                <div className="text-[10px] text-slate-500">Sunil P. (Operations)</div>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('kitchen@hotelsaimaya.com', 'Restaurant Staff')}
                className="px-2.5 py-2 text-left bg-slate-50 hover:bg-amber-50/50 border border-slate-200 hover:border-[#c5a059]/40 rounded-lg transition-colors group cursor-pointer"
              >
                <div className="text-[11px] font-bold text-slate-900 group-hover:text-[#b38938]">Kitchen & Menu</div>
                <div className="text-[10px] text-slate-500">Devendra J. (Chef)</div>
              </button>
            </div>
          </div>
        </div>

        {/* Exit link back to public site */}
        <div className="text-center mt-6">
          <button
            type="button"
            onClick={onExit}
            className="inline-flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Hotel Sai Maya Public Website</span>
          </button>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {forgotModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-amber-50 border border-[#c5a059]/30 flex items-center justify-center text-[#b38938] mb-4">
              <KeyRound className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-serif font-bold text-slate-900">Reset Administrative Password</h3>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              An OTP verification token and reset instructions will be transmitted to the registered hotel director's mobile (+91 98220 54321).
            </p>

            {resetSuccess ? (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-xs text-emerald-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Reset token dispatched to registered WhatsApp and email.</span>
              </div>
            ) : (
              <div className="mt-5 space-y-3">
                <input
                  type="email"
                  defaultValue={email}
                  placeholder="admin@hotelsaimaya.com"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
                <button
                  type="button"
                  onClick={() => setResetSuccess(true)}
                  className="w-full py-2.5 bg-[#b38938] text-white text-xs font-bold rounded-lg hover:bg-[#8f6d2b] transition-colors"
                >
                  Send Reset Link
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                setForgotModal(false);
                setResetSuccess(false);
              }}
              className="mt-4 w-full py-2 border border-slate-200 text-xs font-medium text-slate-600 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
