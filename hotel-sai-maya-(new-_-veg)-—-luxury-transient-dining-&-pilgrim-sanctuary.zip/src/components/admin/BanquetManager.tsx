import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import {
  BanquetPackageItem,
  BanquetFacilityItem,
  BanquetEventTypeItem,
  BanquetCalendarDate
} from '../../types';
import { BANQUET_CALENDAR_DATA } from '../../data/restaurantData';
import {
  Building2,
  Check,
  Plus,
  Trash2,
  Calendar,
  Layers,
  Sparkles,
  Info,
  PhoneCall,
  MessageSquare,
  Users,
  Clock,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const BanquetManager: React.FC = () => {
  const {
    banquetHallInfo,
    updateHallInfo,
    banquetFacilities,
    toggleFacility,
    banquetEventTypes,
    addEventType,
    toggleEventTypeActive,
    banquetPackages,
    addPackage,
    updatePackage,
    deletePackage,
    togglePackageActive,
    enquiries,
    activeSubNav,
    setActiveNav
  } = useAdmin();

  const [activeSubTab, setActiveSubTab] = useState<
    'info' | 'facilities' | 'events' | 'packages' | 'availability' | 'enquiries'
  >(
    activeSubNav === 'banquet-availability'
      ? 'availability'
      : activeSubNav === 'banquet-enquiries'
      ? 'enquiries'
      : 'info'
  );

  // Editable Hall info form state
  const [hallForm, setHallForm] = useState(banquetHallInfo);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Add Package Modal
  const [packageModal, setPackageModal] = useState(false);
  const [pkgForm, setPkgForm] = useState<Partial<BanquetPackageItem>>({
    name: '',
    pricePerGuest: 500,
    guestCapacity: '50 – 150 Guests',
    tagline: '',
    includes: ['Hall rental for 4 hours', 'Pure Veg live buffet feast', 'Ambient lighting'],
    isActive: true
  });
  const [includeInput, setIncludeInput] = useState('');

  // Add Event Type Modal
  const [eventModal, setEventModal] = useState(false);
  const [evtForm, setEvtForm] = useState({ name: '', description: '' });

  // Calendar Availability Interactive Inspection
  const [currentMonth, setCurrentMonth] = useState<'october' | 'november'>('october');
  const [calendarDates, setCalendarDates] = useState<BanquetCalendarDate[]>(
    currentMonth === 'october' ? BANQUET_CALENDAR_DATA[0].days : BANQUET_CALENDAR_DATA[1].days
  );
  const [selectedDate, setSelectedDate] = useState<BanquetCalendarDate | null>(
    BANQUET_CALENDAR_DATA[0].days[9]
  );

  const handleMonthSwitch = (month: 'october' | 'november') => {
    setCurrentMonth(month);
    const dates = month === 'october' ? BANQUET_CALENDAR_DATA[0].days : BANQUET_CALENDAR_DATA[1].days;
    setCalendarDates(dates);
    setSelectedDate(dates[0]);
  };

  const handleDateClick = (date: BanquetCalendarDate) => {
    setSelectedDate(date);
  };

  const handleStatusChange = (newStatus: 'available' | 'peak' | 'booked') => {
    if (!selectedDate) return;
    const updated = calendarDates.map((d) =>
      d.date === selectedDate.date ? { ...d, status: newStatus } : d
    );
    setCalendarDates(updated);
    setSelectedDate({ ...selectedDate, status: newStatus });
  };

  const handleSaveHallInfo = (e: React.FormEvent) => {
    e.preventDefault();
    updateHallInfo(hallForm);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleAddInclusion = () => {
    if (!includeInput.trim()) return;
    setPkgForm({
      ...pkgForm,
      includes: [...(pkgForm.includes || []), includeInput.trim()]
    });
    setIncludeInput('');
  };

  const handleSavePackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pkgForm.name) return;

    addPackage({
      name: pkgForm.name,
      pricePerGuest: Number(pkgForm.pricePerGuest) || 0,
      guestCapacity: pkgForm.guestCapacity || 'TBC based on layout',
      tagline: pkgForm.tagline,
      includes: pkgForm.includes && pkgForm.includes.length > 0 ? pkgForm.includes : ['Full banquet access'],
      isActive: true
    });

    setPackageModal(false);
    setPkgForm({
      name: '',
      pricePerGuest: 500,
      guestCapacity: '50 – 150 Guests',
      tagline: '',
      includes: ['Hall rental for 4 hours', 'Pure Veg live buffet feast'],
      isActive: true
    });
  };

  const handleSaveEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!evtForm.name) return;
    addEventType({
      name: evtForm.name,
      description: evtForm.description || 'Custom spiritual or joyous gathering',
      isActive: true
    });
    setEventModal(false);
    setEvtForm({ name: '', description: '' });
  };

  const banquetEnquiriesList = enquiries.filter((e) => e.type === 'banquet');

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Events & Ceremonial Sanctuary
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Banquet Hall Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Oversee hall capacity specs, verified facility toggles, custom packages, calendar availability slots, and guest inquiries.
          </p>
        </div>

        {/* Sub Navigation Pills */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-50 border border-slate-200 rounded-xl">
          {[
            { id: 'info', label: 'Hall Information' },
            { id: 'facilities', label: 'Facilities' },
            { id: 'events', label: 'Event Types' },
            { id: 'packages', label: 'Packages' },
            { id: 'availability', label: 'Availability Calendar' },
            { id: 'enquiries', label: `Enquiries (${banquetEnquiriesList.length})` }
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeSubTab === tab.id
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Hall Information */}
      {activeSubTab === 'info' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Hall Specifications & Capacity TBC Safeguards
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage operational venue details. Adheres to blueprint rule: capacity is confirmed upon layout review.
              </p>
            </div>
            {savedSuccess && (
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                Saved Changes
              </span>
            )}
          </div>

          <form className="space-y-5" onSubmit={handleSaveHallInfo}>
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Hall Name
              </label>
              <input
                type="text"
                value={hallForm.name}
                onChange={(e) => setHallForm({ ...hallForm, name: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Description / Atmosphere
              </label>
              <textarea
                rows={3}
                value={hallForm.description}
                onChange={(e) => setHallForm({ ...hallForm, description: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            {/* Capacity Input Controls (Explicit Blueprint Requirement #6) */}
            <div className="p-4 bg-amber-50/50 rounded-xl border border-[#c5a059]/30">
              <div className="flex items-center gap-2 mb-3">
                <Info className="w-4 h-4 text-[#b38938]" />
                <span className="text-xs font-bold text-slate-900">
                  Guest Capacity Parameters
                </span>
                <span className="text-[10px] text-[#b38938] bg-amber-100 px-2 py-0.5 rounded-full font-medium">
                  Configurable Range
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Minimum Capacity (Guests)
                  </label>
                  <input
                    type="text"
                    value={hallForm.minCapacity}
                    onChange={(e) => setHallForm({ ...hallForm, minCapacity: e.target.value })}
                    placeholder="e.g. 40"
                    className="w-full text-xs px-3.5 py-2 border border-slate-300 rounded-lg bg-white font-mono focus:ring-2 focus:ring-[#c5a059]"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Minimum headcount for private booking</p>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Maximum Capacity (Guests)
                  </label>
                  <input
                    type="text"
                    value={hallForm.maxCapacity}
                    onChange={(e) => setHallForm({ ...hallForm, maxCapacity: e.target.value })}
                    placeholder="e.g. 250 (Subject to layout)"
                    className="w-full text-xs px-3.5 py-2 border border-slate-300 rounded-lg bg-white font-mono focus:ring-2 focus:ring-[#c5a059]"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Maximum comfortable capacity</p>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Seating Arrangements
              </label>
              <input
                type="text"
                value={hallForm.seatingArrangements}
                onChange={(e) => setHallForm({ ...hallForm, seatingArrangements: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Facilities & Confirmation Note
              </label>
              <input
                type="text"
                value={hallForm.facilitiesNote}
                onChange={(e) => setHallForm({ ...hallForm, facilitiesNote: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Contact CTA Button Text
              </label>
              <input
                type="text"
                value={hallForm.contactCTA}
                onChange={(e) => setHallForm({ ...hallForm, contactCTA: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-bold rounded-lg shadow transition-colors cursor-pointer"
              >
                Save Hall Specifications
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 2: Banquet Facilities (Blueprint #7) */}
      {activeSubTab === 'facilities' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Banquet Facilities Toggles
              </h2>
              <p className="text-xs text-slate-500">
                Only facilities actually provided should be enabled. Disabled amenities display with a "TBC / Advance Request" badge.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {banquetFacilities.map((fac) => (
              <div
                key={fac.id}
                className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                  fac.isEnabled
                    ? 'border-emerald-300 bg-emerald-50/30'
                    : 'border-slate-200 bg-slate-50/60 opacity-80'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-slate-900">{fac.name}</span>
                    <span
                      className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${
                        fac.isEnabled
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {fac.isEnabled ? 'Available' : 'Pending / TBC'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed">{fac.description}</p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={fac.isEnabled}
                    onChange={() => toggleFacility(fac.id)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#b38938]"></div>
                </label>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Banquet Event Types (Blueprint #8) */}
      {activeSubTab === 'events' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Celebration & Event Types
              </h2>
              <p className="text-xs text-slate-500">
                Manage event selections shown on the customer booking form.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setEventModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Event Type</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {banquetEventTypes.map((evt) => (
              <div
                key={evt.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-900">{evt.name}</span>
                    <button
                      type="button"
                      onClick={() => toggleEventTypeActive(evt.id)}
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full cursor-pointer ${
                        evt.isActive
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {evt.isActive ? 'Active' : 'Inactive'}
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">{evt.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Banquet Packages (Blueprint #9) */}
      {activeSubTab === 'packages' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Banquet Packages & Catering Feasts
              </h2>
              <p className="text-xs text-slate-500">
                Verified pure-vegetarian event tiers with per-guest pricing and transparent inclusions.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setPackageModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Package</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {banquetPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="p-5 rounded-xl border border-slate-200 bg-white shadow-sm flex flex-col justify-between relative group hover:border-[#c5a059] transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                      {pkg.guestCapacity}
                    </span>
                    <button
                      type="button"
                      onClick={() => togglePackageActive(pkg.id)}
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        pkg.isActive
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {pkg.isActive ? 'Active' : 'Draft'}
                    </button>
                  </div>

                  <h3 className="text-base font-bold text-slate-900">{pkg.name}</h3>
                  {pkg.tagline && (
                    <p className="text-xs text-[#b38938] font-medium mt-0.5">{pkg.tagline}</p>
                  )}

                  <div className="mt-3 text-2xl font-mono font-bold text-slate-900">
                    ₹{pkg.pricePerGuest}{' '}
                    <span className="text-xs font-sans font-normal text-slate-500">/ guest</span>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
                    <div className="text-[11px] font-semibold uppercase text-slate-600 mb-1">
                      Includes:
                    </div>
                    {pkg.includes.map((inc, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-600">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{inc}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-mono">ID: {pkg.id}</span>
                  <button
                    type="button"
                    onClick={() => deletePackage(pkg.id)}
                    className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 5: Banquet Availability Calendar (Blueprint #10) */}
      {activeSubTab === 'availability' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Banquet Availability Master Calendar
              </h2>
              <p className="text-xs text-slate-500">
                Live date management for morning and evening session slots. Click any date to view booking details.
              </p>
            </div>

            {/* Month switch & Legend */}
            <div className="flex items-center gap-3">
              <div className="inline-flex rounded-lg border border-slate-200 p-1 bg-slate-50">
                <button
                  type="button"
                  onClick={() => handleMonthSwitch('october')}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    currentMonth === 'october'
                      ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                      : 'text-slate-600'
                  }`}
                >
                  October 2026
                </button>
                <button
                  type="button"
                  onClick={() => handleMonthSwitch('november')}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    currentMonth === 'november'
                      ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                      : 'text-slate-600'
                  }`}
                >
                  November 2026
                </button>
              </div>
            </div>
          </div>

          {/* Status Legend */}
          <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>🟢 Available (Open)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span>🟡 Enquiry / Fast-Filling</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>🔴 Booked</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-800" />
              <span>⚫ Blocked / Maintenance</span>
            </span>
          </div>

          {/* Calendar Grid & Detail Inspector */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Calendar Matrix */}
            <div className="lg:col-span-2 border border-slate-200 rounded-xl overflow-hidden">
              <div className="grid grid-cols-7 bg-slate-100 text-slate-700 text-center font-bold text-[11px] py-2 border-b border-slate-200 uppercase">
                <span>Mon</span>
                <span>Tue</span>
                <span>Wed</span>
                <span>Thu</span>
                <span>Fri</span>
                <span>Sat</span>
                <span>Sun</span>
              </div>

              <div className="grid grid-cols-7 gap-px bg-slate-200">
                {calendarDates.map((d) => {
                  const isSelected = selectedDate?.date === d.date;
                  const statusColors = {
                    available: 'bg-emerald-50 border-emerald-300 text-emerald-900',
                    peak: 'bg-amber-50 border-amber-300 text-amber-900',
                    booked: 'bg-rose-50 border-rose-300 text-rose-900',
                    muhurat: 'bg-purple-50 border-purple-300 text-purple-900'
                  };

                  return (
                    <button
                      key={d.date}
                      type="button"
                      onClick={() => handleDateClick(d)}
                      className={`min-h-[70px] p-2 bg-white flex flex-col justify-between text-left hover:bg-amber-50/40 transition-all cursor-pointer ${
                        isSelected ? 'ring-2 ring-[#c5a059] bg-amber-50/60 z-10' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-slate-800">
                          {d.dayNumber}
                        </span>
                        <span
                          className={`w-2 h-2 rounded-full ${
                            d.status === 'available'
                              ? 'bg-emerald-500'
                              : d.status === 'peak'
                              ? 'bg-amber-500'
                              : d.status === 'booked'
                              ? 'bg-rose-500'
                              : 'bg-purple-500'
                          }`}
                        />
                      </div>

                      {d.occasionNote && (
                        <div className="text-[10px] text-slate-500 line-clamp-1 leading-tight">
                          {d.occasionNote}
                        </div>
                      )}

                      <div className="flex gap-1 text-[9px] font-mono text-slate-400">
                        <span>M:{d.morningSlot === 'open' ? '🟢' : '🔴'}</span>
                        <span>E:{d.eveningSlot === 'open' ? '🟢' : '🔴'}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Date Details & Status Modifier Panel (Blueprint: Event -> Customer -> Guests -> Status -> Contact) */}
            <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 flex flex-col justify-between">
              {selectedDate ? (
                <div className="space-y-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[#b38938]">
                      Selected Date Inspection
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-0.5">
                      {selectedDate.date} ({selectedDate.dayOfWeek})
                    </h3>
                    <p className="text-xs text-slate-500">{selectedDate.occasionNote || 'Standard Highway Date'}</p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-200">
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                      Current Date Status
                    </label>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleStatusChange('available')}
                        className={`py-1.5 px-2 text-xs font-semibold rounded-lg border transition-colors ${
                          selectedDate.status === 'available'
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        Available
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStatusChange('peak')}
                        className={`py-1.5 px-2 text-xs font-semibold rounded-lg border transition-colors ${
                          selectedDate.status === 'peak'
                            ? 'bg-amber-600 text-white border-amber-600'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        Enquiry
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStatusChange('booked')}
                        className={`py-1.5 px-2 text-xs font-semibold rounded-lg border transition-colors ${
                          selectedDate.status === 'booked'
                            ? 'bg-rose-600 text-white border-rose-600'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        Booked
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-200/60">
                      <span className="text-slate-500">Morning / Lunch Slot:</span>
                      <span className="font-bold text-slate-800">
                        {selectedDate.morningSlot === 'open' ? 'Open (10 AM - 3 PM)' : 'Reserved'}
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200/60">
                      <span className="text-slate-500">Evening / Dinner Slot:</span>
                      <span className="font-bold text-slate-800">
                        {selectedDate.eveningSlot === 'open' ? 'Open (6 PM - 11 PM)' : 'Reserved'}
                      </span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-500">Connected Enquiry:</span>
                      <span className="font-bold text-[#b38938]">
                        {selectedDate.status === 'booked' ? 'Rahul Patil (85 pax)' : 'No Booking'}
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400">Select a date from the calendar to inspect slot details.</p>
              )}

              <div className="pt-4 mt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveSubTab('enquiries')}
                  className="w-full py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Check Connected Banquet Enquiries</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: Banquet Enquiries (Blueprint #11 & #12) */}
      {activeSubTab === 'enquiries' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 flex-wrap gap-2">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Banquet Enquiries & Event Leads
              </h2>
              <p className="text-xs text-slate-500">
                Customer leads generated directly from the public website's event consultation form.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveNav('enquiries')}
              className="px-3.5 py-1.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Open Enquiries Manager Table</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {banquetEnquiriesList.map((enq) => (
              <div key={enq.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{enq.customerName}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-50 text-[#b38938] border border-amber-200">
                      {enq.eventDate || 'Date Flexible'}
                    </span>
                    <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800">
                      {enq.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 mt-1">{enq.requirements}</p>

                  <div className="flex items-center gap-4 text-[11px] text-slate-400 mt-2">
                    <span>Mobile: {enq.mobileNumber}</span>
                    <span>Guests: {enq.expectedGuests}</span>
                    <span>Slot: {enq.preferredTime}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href={`tel:${enq.mobileNumber}`}
                    className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg border border-slate-200 transition-colors"
                    title="Call Customer"
                  >
                    <PhoneCall className="w-4 h-4" />
                  </a>
                  <a
                    href={`https://wa.me/${enq.mobileNumber.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg border border-slate-200 transition-colors"
                    title="WhatsApp Customer"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Package Modal */}
      {packageModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-serif font-bold text-slate-900 mb-3">
              + Add Banquet Package
            </h3>
            <form className="space-y-3" onSubmit={handleSavePackage}>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Package Name *
                </label>
                <input
                  type="text"
                  required
                  value={pkgForm.name}
                  onChange={(e) => setPkgForm({ ...pkgForm, name: e.target.value })}
                  placeholder="e.g. Silver Celebration"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Price / Guest (₹)
                  </label>
                  <input
                    type="number"
                    value={pkgForm.pricePerGuest}
                    onChange={(e) => setPkgForm({ ...pkgForm, pricePerGuest: Number(e.target.value) })}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Guest Capacity
                  </label>
                  <input
                    type="text"
                    value={pkgForm.guestCapacity}
                    onChange={(e) => setPkgForm({ ...pkgForm, guestCapacity: e.target.value })}
                    placeholder="40 – 100 Guests"
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Tagline / Best For
                </label>
                <input
                  type="text"
                  value={pkgForm.tagline}
                  onChange={(e) => setPkgForm({ ...pkgForm, tagline: e.target.value })}
                  placeholder="Ideal for birthdays, baby showers, etc."
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Package Inclusions
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={includeInput}
                    onChange={(e) => setIncludeInput(e.target.value)}
                    placeholder="Add an item..."
                    className="flex-1 text-xs px-3 py-1.5 border border-slate-300 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={handleAddInclusion}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                  >
                    Add
                  </button>
                </div>
                <div className="space-y-1 max-h-28 overflow-y-auto">
                  {pkgForm.includes?.map((inc, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs bg-slate-50 px-2 py-1 rounded">
                      <span className="text-slate-700">{inc}</span>
                      <button
                        type="button"
                        onClick={() =>
                          setPkgForm({
                            ...pkgForm,
                            includes: pkgForm.includes?.filter((_, i) => i !== idx)
                          })
                        }
                        className="text-rose-500"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setPackageModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-lg text-xs font-semibold shadow"
                >
                  Save Package
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Event Type Modal */}
      {eventModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-serif font-bold text-slate-900 mb-3">
              + Add Banquet Event Type
            </h3>
            <form className="space-y-3" onSubmit={handleSaveEvent}>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Event Name *
                </label>
                <input
                  type="text"
                  required
                  value={evtForm.name}
                  onChange={(e) => setEvtForm({ ...evtForm, name: e.target.value })}
                  placeholder="e.g. Bhajan Sandhya"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={evtForm.description}
                  onChange={(e) => setEvtForm({ ...evtForm, description: e.target.value })}
                  placeholder="Details of the occasion..."
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setEventModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#b38938] text-white rounded-lg text-xs font-semibold shadow"
                >
                  Add Type
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
