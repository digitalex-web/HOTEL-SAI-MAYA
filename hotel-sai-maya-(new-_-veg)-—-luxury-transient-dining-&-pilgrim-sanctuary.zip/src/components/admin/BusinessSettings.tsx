import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import {
  Check,
  Building,
  Phone,
  Mail,
  Clock,
  MessageSquare,
  Instagram,
  MapPin,
  Sparkles
} from 'lucide-react';

export const BusinessSettings: React.FC = () => {
  const { businessSettings, updateBusinessSettings, activeSubNav } = useAdmin();

  const [activeTab, setActiveTab] = useState<'info' | 'hours' | 'whatsapp'>(
    activeSubNav === 'opening-hours'
      ? 'hours'
      : activeSubNav === 'whatsapp'
      ? 'whatsapp'
      : 'info'
  );

  const [form, setForm] = useState(businessSettings);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusinessSettings(form);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleDayHourChange = (dayIndex: number, field: string, value: any) => {
    const updated = [...form.openingHours];
    updated[dayIndex] = { ...updated[dayIndex], [field]: value };
    setForm({ ...form, openingHours: updated });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Sanctuary Operations
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Business & Operational Settings
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Configure contact hotlines, 24/7 highway hours, dining shifts, and WhatsApp concierge templates.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-50 border border-slate-200 rounded-xl shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('info')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'info'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600'
            }`}
          >
            Business Profile
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('hours')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'hours'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600'
            }`}
          >
            Opening Hours
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'whatsapp'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600'
            }`}
          >
            WhatsApp Concierge
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Tab 1: Business Profile (Blueprint #15) */}
        {activeTab === 'info' && (
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900">
                Core Identity & Contact Information
              </h2>
              {savedSuccess && (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  Saved Changes
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Hotel / Restaurant Name *
                </label>
                <input
                  type="text"
                  required
                  value={form.hotelName}
                  onChange={(e) => setForm({ ...form, hotelName: e.target.value })}
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Business Tagline
                </label>
                <input
                  type="text"
                  value={form.tagline}
                  onChange={(e) => setForm({ ...form, tagline: e.target.value })}
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Primary Contact Phone *
                </label>
                <input
                  type="text"
                  required
                  value={form.contactPhone}
                  onChange={(e) => setForm({ ...form, contactPhone: e.target.value })}
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Secondary / Banquet Hotline
                </label>
                <input
                  type="text"
                  value={form.secondaryPhone}
                  onChange={(e) => setForm({ ...form, secondaryPhone: e.target.value })}
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Official Email
                </label>
                <input
                  type="email"
                  value={form.contactEmail}
                  onChange={(e) => setForm({ ...form, contactEmail: e.target.value })}
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Instagram Handle *
                </label>
                <input
                  type="text"
                  value={form.instagramHandle}
                  onChange={(e) => setForm({ ...form, instagramHandle: e.target.value })}
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Full Physical Address *
              </label>
              <textarea
                rows={2}
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="w-full text-xs px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>
          </div>
        )}

        {/* Tab 2: Opening Hours (Blueprint #16) */}
        {activeTab === 'hours' && (
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Opening Hours & Transit Shifts
                </h2>
                <p className="text-xs text-slate-500">
                  Manage individual daily schedules for highway pilgrims and morning Aarti transits.
                </p>
              </div>
              {savedSuccess && (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  Saved Changes
                </span>
              )}
            </div>

            <div className="divide-y divide-slate-100">
              {form.openingHours.map((day, idx) => (
                <div key={day.day} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="w-36 font-semibold text-xs text-slate-900">{day.day}</div>

                  <div className="flex items-center gap-3">
                    <label className="inline-flex items-center gap-1.5 text-xs text-slate-600">
                      <input
                        type="checkbox"
                        checked={!day.isClosed}
                        onChange={(e) => handleDayHourChange(idx, 'isClosed', !e.target.checked)}
                        className="rounded border-slate-300 text-[#b38938]"
                      />
                      <span>Open</span>
                    </label>

                    <label className="inline-flex items-center gap-1.5 text-xs text-slate-600">
                      <input
                        type="checkbox"
                        checked={day.is24Hours}
                        onChange={(e) => handleDayHourChange(idx, 'is24Hours', e.target.checked)}
                        className="rounded border-slate-300 text-emerald-600"
                      />
                      <span className="font-medium text-emerald-700">24/7 Open</span>
                    </label>
                  </div>

                  {!day.isClosed && !day.is24Hours && (
                    <div className="flex items-center gap-2 text-xs">
                      <input
                        type="time"
                        value={day.openTime}
                        onChange={(e) => handleDayHourChange(idx, 'openTime', e.target.value)}
                        className="px-2 py-1 border border-slate-300 rounded font-mono"
                      />
                      <span className="text-slate-400">to</span>
                      <input
                        type="time"
                        value={day.closeTime}
                        onChange={(e) => handleDayHourChange(idx, 'closeTime', e.target.value)}
                        className="px-2 py-1 border border-slate-300 rounded font-mono"
                      />
                    </div>
                  )}

                  {(day.isClosed || day.is24Hours) && (
                    <div className="text-xs font-mono text-slate-400">
                      {day.is24Hours ? 'Continuous Highway Service' : 'Closed for Sanctuary Maintenance'}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: WhatsApp Configuration (Blueprint #18) */}
        {activeTab === 'whatsapp' && (
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  WhatsApp Concierge & Floating Button
                </h2>
                <p className="text-xs text-slate-500">
                  Manage floating chat triggers, destination numbers, and automated inquiry messages.
                </p>
              </div>
              {savedSuccess && (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  Saved Changes
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Destination WhatsApp Mobile (with country code)
                </label>
                <input
                  type="text"
                  required
                  value={form.whatsappNumber}
                  onChange={(e) => setForm({ ...form, whatsappNumber: e.target.value })}
                  placeholder="+9198XXXXXXXX"
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Button Position
                </label>
                <select
                  value={form.whatsappButtonPosition}
                  onChange={(e) =>
                    setForm({ ...form, whatsappButtonPosition: e.target.value as any })
                  }
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg bg-white"
                >
                  <option value="bottom-right">Bottom Right (Recommended)</option>
                  <option value="bottom-left">Bottom Left</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Default Inquiry Message Template
              </label>
              <textarea
                rows={3}
                value={form.whatsappPreFilledMessage}
                onChange={(e) => setForm({ ...form, whatsappPreFilledMessage: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="floating-wa-check"
                checked={form.enableFloatingWhatsapp}
                onChange={(e) =>
                  setForm({ ...form, enableFloatingWhatsapp: e.target.checked })
                }
                className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
              />
              <label htmlFor="floating-wa-check" className="text-xs font-medium text-slate-700 cursor-pointer">
                Enable 1-Click Floating WhatsApp Button on Public Website
              </label>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-bold rounded-lg shadow transition-colors cursor-pointer"
          >
            Save All Changes
          </button>
        </div>
      </form>
    </div>
  );
};
