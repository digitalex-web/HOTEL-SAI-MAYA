import React, { useState, useEffect } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { EnquiryRecord, EnquiryType, EnquiryStatus } from '../../types';
import {
  PhoneCall,
  MessageSquare,
  Clock,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Calendar,
  Users,
  Search,
  Plus,
  Send,
  UserCheck,
  Tag,
  ArrowRight,
  RefreshCw,
  Sparkles,
  Trash2,
  Copy,
  Check,
  Download,
  Printer,
  SlidersHorizontal,
  Building2,
  Eye,
  Columns,
  Table as TableIcon,
  X,
  Mail,
  FileText,
  IndianRupee,
  ChevronRight,
  UtensilsCrossed
} from 'lucide-react';

export const EnquiryManager: React.FC = () => {
  const {
    enquiries,
    updateEnquiryStatus,
    addEnquiryNote,
    addEnquiry,
    currentUser,
    syncSubmittedInquiries,
    deleteEnquiry
  } = useAdmin();

  // View & Filter States
  const [activeCategory, setActiveCategory] = useState<'banquet' | 'all' | 'website' | 'restaurant'>('banquet');
  const [statusFilter, setStatusFilter] = useState<'all' | EnquiryStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'eventDate' | 'guests' | 'amount'>('newest');
  const [viewMode, setViewMode] = useState<'table' | 'split'>('table');
  
  // Review Drawer / Modal
  const [selectedEnquiry, setSelectedEnquiry] = useState<EnquiryRecord | null>(null);
  const [isReviewDrawerOpen, setIsReviewDrawerOpen] = useState(false);
  const [noteInput, setNoteInput] = useState('');
  
  // Manual Add Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newEnquiryForm, setNewEnquiryForm] = useState({
    customerName: '',
    mobileNumber: '',
    email: '',
    type: 'banquet' as EnquiryType,
    eventType: 'Wedding Reception',
    eventDate: '2026-10-24',
    expectedGuests: '100',
    preferredTime: 'Evening (6:00 PM – 11:00 PM)',
    requirements: 'Pure Satvik feast & stage floral arrangement',
    totalAmountEstimate: 55000
  });

  // Action Feedbacks
  const [syncing, setSyncing] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [actionSuccessToast, setActionSuccessToast] = useState<string | null>(null);

  // Auto-sync on mount
  useEffect(() => {
    if (syncSubmittedInquiries) {
      syncSubmittedInquiries();
    }
  }, [syncSubmittedInquiries]);

  // Handle manual sync
  const handleManualSync = () => {
    setSyncing(true);
    if (syncSubmittedInquiries) {
      syncSubmittedInquiries();
    }
    setTimeout(() => {
      setSyncing(false);
      showToast('Enquiries synced with local application state');
    }, 500);
  };

  const showToast = (msg: string) => {
    setActionSuccessToast(msg);
    setTimeout(() => setActionSuccessToast(null), 3000);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(text);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Filter and sort inquiries
  const filteredEnquiries = enquiries
    .filter((enq) => {
      // Category filter
      if (activeCategory === 'banquet') {
        if (enq.type !== 'banquet') return false;
      } else if (activeCategory === 'website') {
        if (enq.source !== 'website_banquet' && !enq.referenceCode) return false;
      } else if (activeCategory === 'restaurant') {
        if (enq.type !== 'restaurant' && enq.type !== 'takeaway') return false;
      }

      // Status filter
      if (statusFilter !== 'all' && enq.status !== statusFilter) {
        return false;
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = enq.customerName.toLowerCase().includes(q);
        const matchesPhone = enq.mobileNumber.includes(q);
        const matchesRef = enq.referenceCode ? enq.referenceCode.toLowerCase().includes(q) : false;
        const matchesEvent = enq.eventType ? enq.eventType.toLowerCase().includes(q) : false;
        const matchesReq = enq.requirements ? enq.requirements.toLowerCase().includes(q) : false;
        const matchesDate = enq.eventDate ? enq.eventDate.toLowerCase().includes(q) : false;
        const matchesEmail = enq.email ? enq.email.toLowerCase().includes(q) : false;
        if (!matchesName && !matchesPhone && !matchesRef && !matchesEvent && !matchesReq && !matchesDate && !matchesEmail) {
          return false;
        }
      }

      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') {
        return (b.createdAt || '').localeCompare(a.createdAt || '');
      }
      if (sortBy === 'eventDate') {
        return (a.eventDate || '9999').localeCompare(b.eventDate || '9999');
      }
      if (sortBy === 'guests') {
        const ga = Number(a.expectedGuests) || 0;
        const gb = Number(b.expectedGuests) || 0;
        return gb - ga;
      }
      if (sortBy === 'amount') {
        const aa = a.totalAmountEstimate || 0;
        const ab = b.totalAmountEstimate || 0;
        return ab - aa;
      }
      return 0;
    });

  // Current selected enquiry object from state
  const activeEnquiry = selectedEnquiry
    ? enquiries.find((e) => e.id === selectedEnquiry.id) || selectedEnquiry
    : filteredEnquiries[0] || null;

  // Key KPI metrics for manager
  const banquetLeads = enquiries.filter((e) => e.type === 'banquet');
  const newLeadsCount = banquetLeads.filter((e) => e.status === 'new').length;
  const confirmedLeadsCount = banquetLeads.filter((e) => e.status === 'confirmed').length;
  const totalPipelineValue = banquetLeads.reduce(
    (sum, e) => sum + (e.totalAmountEstimate || 0),
    0
  );
  const websiteSubmissionsCount = enquiries.filter((e) => e.source === 'website_banquet' || e.referenceCode).length;

  const handleOpenReview = (enq: EnquiryRecord) => {
    setSelectedEnquiry(enq);
    setIsReviewDrawerOpen(true);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeEnquiry || !noteInput.trim()) return;
    addEnquiryNote(activeEnquiry.id, noteInput.trim());
    setNoteInput('');
    showToast('Manager follow-up note recorded');
  };

  const handleDeleteCurrent = (id: string) => {
    if (window.confirm('Are you sure you want to permanently remove this enquiry record?')) {
      if (deleteEnquiry) {
        deleteEnquiry(id);
      }
      setIsReviewDrawerOpen(false);
      setSelectedEnquiry(null);
      showToast('Enquiry record removed');
    }
  };

  const handleStatusChangeInline = (id: string, newStatus: EnquiryStatus) => {
    const note = `Status updated to ${newStatus.toUpperCase()} by ${currentUser?.name || 'Manager'}`;
    updateEnquiryStatus(id, newStatus, note);
    showToast(`Enquiry marked as ${newStatus.toUpperCase()}`);
  };

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'Reference Code',
      'Customer Name',
      'Mobile Number',
      'Email',
      'Enquiry Type',
      'Event Type',
      'Event Date',
      'Guests (Pax)',
      'Preferred Slot',
      'Status',
      'Estimated Amount (INR)',
      'Requirements',
      'Created At'
    ];

    const rows = filteredEnquiries.map((e) => [
      `"${e.referenceCode || 'N/A'}"`,
      `"${e.customerName.replace(/"/g, '""')}"`,
      `"${e.mobileNumber}"`,
      `"${e.email || ''}"`,
      `"${e.type}"`,
      `"${e.eventType || e.type}"`,
      `"${e.eventDate || ''}"`,
      `"${e.expectedGuests || ''}"`,
      `"${e.preferredTime || ''}"`,
      `"${e.status}"`,
      `"${e.totalAmountEstimate || 0}"`,
      `"${(e.requirements || '').replace(/"/g, '""').replace(/\n/g, ' ')}"`,
      `"${e.createdAt}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `hotel_sai_maya_banquet_enquiries_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Enquiries exported to CSV');
  };

  // Print Lead Sheet
  const handlePrintLeadSheet = (enq: EnquiryRecord) => {
    const printWindow = window.open('', '_blank', 'width=800,height=900');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Banquet Event Lead Sheet - ${enq.referenceCode || enq.id}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #1e293b; }
            .header { border-bottom: 2px solid #b38938; padding-bottom: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-end; }
            .brand { font-size: 24px; font-weight: bold; color: #0f172a; }
            .sub { font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; }
            .badge { background: #fef3c7; color: #92400e; padding: 4px 10px; border-radius: 6px; font-weight: bold; font-size: 12px; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
            .card { background: #f8fafc; border: 1px solid #e2e8f0; padding: 14px; border-radius: 8px; }
            .label { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: bold; margin-bottom: 4px; }
            .value { font-size: 14px; font-weight: 600; color: #0f172a; }
            .notes { background: #fffbeb; border: 1px solid #fef3c7; padding: 16px; border-radius: 8px; margin-bottom: 24px; }
            .footer { margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 16px; font-size: 11px; color: #94a3b8; display: flex; justify-content: space-between; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="brand">HOTEL SAI MAYA</div>
              <div class="sub">Sanctuary Banquet Hall & Event Lead Sheet</div>
            </div>
            <div>
              <span class="badge">STATUS: ${enq.status.toUpperCase()}</span>
            </div>
          </div>

          <div class="grid">
            <div class="card">
              <div class="label">Customer Name</div>
              <div class="value">${enq.customerName}</div>
            </div>
            <div class="card">
              <div class="label">Contact Mobile</div>
              <div class="value">${enq.mobileNumber}</div>
            </div>
            <div class="card">
              <div class="label">Booking Reference ID</div>
              <div class="value">${enq.referenceCode || 'N/A'}</div>
            </div>
            <div class="card">
              <div class="label">Event Category</div>
              <div class="value">${enq.eventType || enq.type}</div>
            </div>
            <div class="card">
              <div class="label">Requested Event Date</div>
              <div class="value">${enq.eventDate || 'Date Open'}</div>
            </div>
            <div class="card">
              <div class="label">Preferred Time Slot</div>
              <div class="value">${enq.preferredTime || 'Flexible'}</div>
            </div>
            <div class="card">
              <div class="label">Expected Guests (Pax)</div>
              <div class="value">${enq.expectedGuests || 'To be confirmed'} Guests</div>
            </div>
            <div class="card">
              <div class="label">Estimated Budget / Quote</div>
              <div class="value">₹${(enq.totalAmountEstimate || 0).toLocaleString()}</div>
            </div>
          </div>

          <div class="notes">
            <div class="label" style="color: #b45309;">Guest Requirements & Dietary Notes</div>
            <div style="margin-top: 6px; font-size: 13px; line-height: 1.6;">
              ${enq.requirements || 'No special requirements noted.'}
            </div>
          </div>

          <div class="footer">
            <span>Printed on ${new Date().toLocaleString()} by ${currentUser?.name || 'Manager'}</span>
            <span>Hotel Sai Maya • Shirdi–Nashik Highway NH 160</span>
          </div>
          <script>window.print();</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Create manual enquiry
  const handleCreateManualEnquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEnquiryForm.customerName.trim() || !newEnquiryForm.mobileNumber.trim()) {
      alert('Please provide customer name and mobile number.');
      return;
    }

    const ref = `HSM-BNQ-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    addEnquiry({
      customerName: newEnquiryForm.customerName.trim(),
      mobileNumber: newEnquiryForm.mobileNumber.trim(),
      email: newEnquiryForm.email.trim() || undefined,
      type: newEnquiryForm.type,
      eventType: newEnquiryForm.eventType,
      eventDate: newEnquiryForm.eventDate,
      expectedGuests: newEnquiryForm.expectedGuests,
      preferredTime: newEnquiryForm.preferredTime,
      requirements: newEnquiryForm.requirements,
      totalAmountEstimate: Number(newEnquiryForm.totalAmountEstimate) || 35000,
      referenceCode: ref,
      source: 'admin',
      status: 'new',
      history: [
        {
          id: `hist-${Date.now()}`,
          timestamp: `Today, ${now}`,
          action: 'Enquiry Logged by Manager',
          note: `Direct phone/walk-in inquiry entered by ${currentUser?.name || 'Reception Desk'}`,
          staffName: currentUser?.name || 'Manager'
        }
      ]
    });

    setIsAddModalOpen(false);
    showToast(`New banquet enquiry ${ref} recorded successfully`);
    setNewEnquiryForm({
      customerName: '',
      mobileNumber: '',
      email: '',
      type: 'banquet',
      eventType: 'Wedding Reception',
      eventDate: '2026-10-24',
      expectedGuests: '100',
      preferredTime: 'Evening (6:00 PM – 11:00 PM)',
      requirements: 'Pure Satvik feast & stage floral arrangement',
      totalAmountEstimate: 55000
    });
  };

  const getStatusBadge = (status: EnquiryStatus) => {
    const styles: Record<EnquiryStatus, string> = {
      new: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      contacted: 'bg-sky-50 text-sky-700 border-sky-200',
      'follow-up': 'bg-amber-50 text-amber-700 border-amber-200',
      confirmed: 'bg-purple-50 text-purple-700 border-purple-200',
      completed: 'bg-slate-100 text-slate-700 border-slate-200',
      cancelled: 'bg-rose-50 text-rose-700 border-rose-200'
    };
    return (
      <span
        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
          styles[status] || styles.new
        }`}
      >
        {status}
      </span>
    );
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Toast Notification */}
      {actionSuccessToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs font-semibold animate-fadeIn border border-slate-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{actionSuccessToast}</span>
        </div>
      )}

      {/* Top Banner & Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938] flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5" />
              Event Operations & Highway Concierge Desk
            </span>
            {websiteSubmissionsCount > 0 && (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-[#b38938] border border-amber-200">
                <Sparkles className="w-3 h-3" />
                {websiteSubmissionsCount} Online Submissions
              </span>
            )}
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Banquet & Event Enquiries Manager
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Clean, real-time register of all event inquiries, wedding bookings, and satvik banquet consultations submitted through the website form and concierge desk.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleManualSync}
            disabled={syncing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
            title="Reload submitted inquiries from local application state"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#b38938] ${syncing ? 'animate-spin' : ''}`} />
            <span>{syncing ? 'Syncing...' : 'Sync Local State'}</span>
          </button>

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
            title="Download CSV spreadsheet"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>

          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log New Enquiry</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Banquet Leads
            </span>
            <span className="text-2xl font-bold font-serif text-slate-900 mt-0.5 block">
              {banquetLeads.length}
            </span>
            <span className="text-[10px] text-slate-500">Total event inquiries</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-[#b38938]">
            <Building2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Needs Review
            </span>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-2xl font-bold font-serif text-emerald-700">
                {newLeadsCount}
              </span>
              {newLeadsCount > 0 && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 animate-pulse">
                  Action Required
                </span>
              )}
            </div>
            <span className="text-[10px] text-slate-500">Uncontacted leads</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Confirmed Events
            </span>
            <span className="text-2xl font-bold font-serif text-purple-700 mt-0.5 block">
              {confirmedLeadsCount}
            </span>
            <span className="text-[10px] text-slate-500">Hall reserved dates</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-200 flex items-center justify-center text-purple-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Pipeline Value
            </span>
            <span className="text-xl font-bold font-mono text-[#b38938] mt-0.5 block">
              ₹{totalPipelineValue.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-500">Est. banquet revenue</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50/60 border border-amber-200 flex items-center justify-center text-[#b38938]">
            <IndianRupee className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Control Bar: Filters, Search, and View Mode Toggle */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100/70 border border-slate-200 rounded-xl">
            {[
              { id: 'banquet', label: `Banquet Enquiries (${banquetLeads.length})` },
              { id: 'website', label: `Web Form Leads (${websiteSubmissionsCount})` },
              { id: 'all', label: `All Channels (${enquiries.length})` },
              { id: 'restaurant', label: `Dining / Takeaway (${enquiries.filter((e) => e.type !== 'banquet').length})` }
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveCategory(tab.id as any)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  activeCategory === tab.id
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* View Mode Toggle: Wide Table vs Split Review Mode */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 hidden sm:inline">Layout:</span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  viewMode === 'table' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Full width table view"
              >
                <TableIcon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Full Table</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('split')}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  viewMode === 'split' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Split table and review drawer"
              >
                <Columns className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Split Inspector</span>
              </button>
            </div>
          </div>
        </div>

        {/* Search Input & Secondary Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-1 border-t border-slate-100">
          {/* Search Box */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by customer name, phone, booking ref (e.g. HSM-BNQ), event type, or date..."
              className="w-full pl-9 pr-8 py-2 text-xs text-slate-900 placeholder-slate-400 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#b38938]/30 transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Status Filter */}
          <div className="sm:col-span-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full py-2 px-3 text-xs text-slate-700 bg-slate-50 hover:bg-slate-100/70 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#b38938]/30 transition-all cursor-pointer"
            >
              <option value="all">All Statuses</option>
              <option value="new">New (Unreviewed)</option>
              <option value="contacted">Contacted</option>
              <option value="follow-up">Follow-up Pending</option>
              <option value="confirmed">Confirmed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="sm:col-span-3">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full py-2 px-3 text-xs text-slate-700 bg-slate-50 hover:bg-slate-100/70 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#b38938]/30 transition-all cursor-pointer"
            >
              <option value="newest">Sort: Newest First</option>
              <option value="eventDate">Sort: Event Date (Soonest)</option>
              <option value="guests">Sort: Guest Count (Highest)</option>
              <option value="amount">Sort: Est. Quote (Highest)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table Section: Table View OR Split View */}
      <div className={viewMode === 'split' ? 'grid grid-cols-1 lg:grid-cols-12 gap-6' : 'space-y-6'}>
        {/* Table Container */}
        <div className={`${viewMode === 'split' ? 'lg:col-span-7' : 'w-full'} bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col`}>
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="text-xs font-semibold text-slate-700">
              Showing <span className="font-bold text-slate-900">{filteredEnquiries.length}</span> {activeCategory === 'banquet' ? 'banquet enquiries' : 'records'}
              {searchQuery && <span className="text-slate-400 font-normal"> matching "{searchQuery}"</span>}
            </div>
            {filteredEnquiries.length > 0 && (
              <span className="text-[11px] text-slate-400 font-mono">
                Click any row or "Review" to inspect
              </span>
            )}
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Booking Ref</th>
                  <th className="py-3 px-4">Customer & Contact</th>
                  <th className="py-3 px-3">Event Type & Guests</th>
                  <th className="py-3 px-3">Event Date & Slot</th>
                  {viewMode === 'table' && <th className="py-3 px-3">Dietary / Notes</th>}
                  <th className="py-3 px-3">Est. Quote</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-4 text-right">Review</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredEnquiries.length === 0 ? (
                  <tr>
                    <td colSpan={viewMode === 'table' ? 8 : 7} className="py-12 text-center">
                      <div className="max-w-md mx-auto space-y-3">
                        <Building2 className="w-10 h-10 text-slate-300 mx-auto" />
                        <h3 className="text-sm font-bold text-slate-800">No banquet enquiries found</h3>
                        <p className="text-xs text-slate-500">
                          {searchQuery
                            ? `No results match your search query "${searchQuery}". Try clearing your filters.`
                            : 'No enquiries currently in local state under this filter. Inquiries submitted via the public banquet form appear here automatically.'}
                        </p>
                        {searchQuery ? (
                          <button
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setStatusFilter('all');
                              setActiveCategory('all');
                            }}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                          >
                            Clear All Filters
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setIsAddModalOpen(true)}
                            className="px-3.5 py-1.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
                          >
                            Log Sample Banquet Lead
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredEnquiries.map((enq) => {
                    const isSelected = activeEnquiry?.id === enq.id;
                    const isOnline = enq.source === 'website_banquet' || !!enq.referenceCode;
                    const isNew = enq.status === 'new';

                    return (
                      <tr
                        key={enq.id}
                        onClick={() => {
                          setSelectedEnquiry(enq);
                          if (viewMode === 'table') {
                            setIsReviewDrawerOpen(true);
                          }
                        }}
                        className={`hover:bg-amber-50/30 transition-colors cursor-pointer ${
                          isSelected ? 'bg-amber-50/60' : ''
                        } ${isNew ? 'border-l-4 border-l-emerald-500' : ''}`}
                      >
                        {/* Booking Ref */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-slate-900 text-xs">
                              {enq.referenceCode || enq.id.substring(0, 10)}
                            </span>
                            {enq.referenceCode && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  copyToClipboard(enq.referenceCode!);
                                }}
                                className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                                title="Copy Reference Code"
                              >
                                {copiedCode === enq.referenceCode ? (
                                  <Check className="w-3 h-3 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            )}
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            {isOnline ? (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                                Web Form
                              </span>
                            ) : (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 border border-slate-200">
                                Concierge Desk
                              </span>
                            )}
                            <span className="text-[10px] text-slate-400">{enq.createdAt}</span>
                          </div>
                        </td>

                        {/* Customer & Contact */}
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900 text-xs">{enq.customerName}</div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[11px] text-slate-600 font-mono">{enq.mobileNumber}</span>
                            <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                              <a
                                href={`tel:${enq.mobileNumber}`}
                                className="p-1 text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors"
                                title="Call Guest"
                              >
                                <PhoneCall className="w-3 h-3" />
                              </a>
                              <a
                                href={`https://wa.me/${enq.mobileNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                                  `Namaskar ${enq.customerName}! This is Hotel Sai Maya Banquet Operations regarding your inquiry for ${enq.eventType || 'the hall'} on ${enq.eventDate || 'your proposed date'} (Ref: ${enq.referenceCode || 'HSM'}). How may we assist you today?`
                                )}`}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1 text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 rounded transition-colors"
                                title="WhatsApp Guest"
                              >
                                <MessageSquare className="w-3 h-3" />
                              </a>
                            </div>
                          </div>
                          {enq.email && (
                            <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{enq.email}</div>
                          )}
                        </td>

                        {/* Event Type & Guests */}
                        <td className="py-3.5 px-3">
                          <div className="font-semibold text-slate-800 text-xs">
                            {enq.eventType || enq.type}
                          </div>
                          <div className="flex items-center gap-1.5 text-[11px] text-[#b38938] font-semibold mt-0.5">
                            <Users className="w-3 h-3" />
                            <span>
                              {enq.expectedGuests ? `${enq.expectedGuests} Guests (Pax)` : 'Seating Open'}
                            </span>
                          </div>
                        </td>

                        {/* Event Date & Slot */}
                        <td className="py-3.5 px-3 whitespace-nowrap">
                          <div className="flex items-center gap-1 font-semibold text-slate-900 text-xs">
                            <Calendar className="w-3 h-3 text-[#b38938]" />
                            <span>{enq.eventDate || 'Date Open'}</span>
                          </div>
                          <div className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-1">
                            <Clock className="w-2.5 h-2.5" />
                            <span>{enq.preferredTime || 'Flexible Timing'}</span>
                          </div>
                        </td>

                        {/* Dietary / Requirements (Visible in full table view) */}
                        {viewMode === 'table' && (
                          <td className="py-3.5 px-3 max-w-xs">
                            <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                              {enq.requirements || 'Standard pure-vegetarian banquet setup.'}
                            </p>
                            {enq.cateringPreference && (
                              <span className="inline-block mt-1 text-[9px] font-semibold px-1.5 py-0.2 rounded bg-amber-50 text-[#b38938] border border-amber-200">
                                {enq.cateringPreference}
                              </span>
                            )}
                          </td>
                        )}

                        {/* Est Quote */}
                        <td className="py-3.5 px-3 whitespace-nowrap">
                          <div className="font-mono font-bold text-slate-900 text-xs">
                            {enq.totalAmountEstimate
                              ? `₹${enq.totalAmountEstimate.toLocaleString()}`
                              : 'Upon Quote'}
                          </div>
                          <div className="text-[10px] text-slate-400">Satvik package</div>
                        </td>

                        {/* Status with Quick Interactive Dropdown */}
                        <td className="py-3.5 px-3" onClick={(e) => e.stopPropagation()}>
                          <select
                            value={enq.status}
                            onChange={(e) => handleStatusChangeInline(enq.id, e.target.value as EnquiryStatus)}
                            className="text-[10px] font-bold uppercase tracking-wider py-1 px-2 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer focus:outline-none focus:ring-1 focus:ring-[#b38938]"
                          >
                            <option value="new">🟢 NEW</option>
                            <option value="contacted">🔵 CONTACTED</option>
                            <option value="follow-up">🟡 FOLLOW-UP</option>
                            <option value="confirmed">🟣 CONFIRMED</option>
                            <option value="cancelled">🔴 CANCELLED</option>
                          </select>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleOpenReview(enq)}
                              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-[#b38938] hover:text-white text-slate-700 text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1"
                              title="Inspect enquiry details"
                            >
                              <Eye className="w-3 h-3" />
                              <span>Review</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handlePrintLeadSheet(enq)}
                              className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition-colors"
                              title="Print Event Lead Sheet"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Split View Right Inspector (Only when viewMode === 'split') */}
        {viewMode === 'split' && activeEnquiry && (
          <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between">
            <div className="space-y-5">
              {/* Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-[#b38938]">
                      BANQUET REVIEW DESK
                    </span>
                    {activeEnquiry.referenceCode && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-50 text-[#b38938] border border-amber-200">
                        {activeEnquiry.referenceCode}
                      </span>
                    )}
                  </div>
                  <h3 className="text-xl font-serif font-bold text-slate-900 mt-1">
                    {activeEnquiry.customerName}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    {activeEnquiry.mobileNumber} {activeEnquiry.email ? `• ${activeEnquiry.email}` : ''}
                  </p>
                </div>
                {getStatusBadge(activeEnquiry.status)}
              </div>

              {/* Specific Parameters */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Event Type</span>
                  <span className="font-bold text-slate-800">{activeEnquiry.eventType || activeEnquiry.type}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Requested Date</span>
                  <span className="font-bold text-slate-800">{activeEnquiry.eventDate || 'Date Open'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Expected Guests</span>
                  <span className="font-bold text-slate-800">{activeEnquiry.expectedGuests || 'Standard'} Guests</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Time Slot</span>
                  <span className="font-bold text-slate-800">{activeEnquiry.preferredTime || 'Flexible'}</span>
                </div>
                <div className="col-span-2 pt-2 border-t border-slate-200 flex justify-between items-center">
                  <span className="text-slate-500 text-xs">Est. Banquet Quote:</span>
                  <span className="font-bold font-mono text-[#b38938] text-sm">
                    {activeEnquiry.totalAmountEstimate
                      ? `₹${activeEnquiry.totalAmountEstimate.toLocaleString()}`
                      : 'Upon Quote'}
                  </span>
                </div>
              </div>

              {/* Requirements */}
              <div>
                <span className="text-xs font-semibold text-slate-700 block mb-1">
                  Customer Requirements & Special Notes
                </span>
                <p className="text-xs text-slate-600 bg-amber-50/40 p-3.5 rounded-xl border border-amber-200/60 leading-relaxed">
                  {activeEnquiry.requirements || 'No special requirements noted.'}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2">
                <a
                  href={`tel:${activeEnquiry.mobileNumber}`}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call Guest</span>
                </a>

                <a
                  href={`https://wa.me/${activeEnquiry.mobileNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                    `Namaskar ${activeEnquiry.customerName}! This is Hotel Sai Maya Banquet Operations regarding your enquiry for ${activeEnquiry.eventType || 'the hall'} on ${activeEnquiry.eventDate || 'your proposed date'} (Ref: ${activeEnquiry.referenceCode || 'HSM'}). How may we assist with finalizing your menu and hall visit?`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-1.5 py-2 px-3 bg-[#25D366] hover:bg-[#1eb857] text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp Quote</span>
                </a>
              </div>

              {/* Quick Status Modifiers */}
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleStatusChangeInline(activeEnquiry.id, 'contacted')}
                  className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer"
                >
                  Mark Contacted
                </button>
                <button
                  type="button"
                  onClick={() => handleStatusChangeInline(activeEnquiry.id, 'confirmed')}
                  className="py-1.5 px-2 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer"
                >
                  Confirm Slot
                </button>
                <button
                  type="button"
                  onClick={() => handlePrintLeadSheet(activeEnquiry)}
                  className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <Printer className="w-3 h-3" />
                  <span>Print Sheet</span>
                </button>
              </div>

              {/* History Log */}
              <div>
                <span className="text-xs font-semibold text-slate-700 block mb-1.5">
                  Audit History & Manager Notes
                </span>
                <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                  {activeEnquiry.history.map((log) => (
                    <div key={log.id} className="text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
                        <span className="font-semibold text-slate-700">{log.action}</span>
                        <span>{log.timestamp}</span>
                      </div>
                      {log.note && <p className="text-slate-600 text-[11px]">{log.note}</p>}
                    </div>
                  ))}
                </div>

                {/* Add note */}
                <form onSubmit={handleAddNote} className="mt-2 flex gap-1.5">
                  <input
                    type="text"
                    value={noteInput}
                    onChange={(e) => setNoteInput(e.target.value)}
                    placeholder="Log call notes or updates..."
                    className="flex-1 py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white"
                  />
                  <button
                    type="submit"
                    className="py-1.5 px-3 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-black transition-colors"
                  >
                    Add
                  </button>
                </form>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-between items-center text-xs">
              <button
                type="button"
                onClick={() => handleDeleteCurrent(activeEnquiry.id)}
                className="text-rose-500 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>Delete Enquiry</span>
              </button>
              <button
                type="button"
                onClick={() => handleOpenReview(activeEnquiry)}
                className="text-[#b38938] hover:underline font-semibold flex items-center gap-1"
              >
                <span>Full Review Modal</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Review Modal (For Full Inspection) */}
      {isReviewDrawerOpen && activeEnquiry && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 space-y-6 animate-scaleUp">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-bold text-[#b38938] tracking-wider">
                    BANQUET EVENT ENQUIRY REVIEW
                  </span>
                  {activeEnquiry.referenceCode && (
                    <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-[#b38938] border border-amber-200">
                      {activeEnquiry.referenceCode}
                    </span>
                  )}
                </div>
                <h2 className="text-2xl font-serif font-bold text-slate-900 mt-1">
                  {activeEnquiry.customerName}
                </h2>
                <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                  <span className="font-mono">{activeEnquiry.mobileNumber}</span>
                  {activeEnquiry.email && <span>• {activeEnquiry.email}</span>}
                  <span>• Submitted {activeEnquiry.createdAt}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsReviewDrawerOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Overview Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Event Type</span>
                <span className="font-bold text-slate-800 text-sm">{activeEnquiry.eventType || activeEnquiry.type}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Event Date</span>
                <span className="font-bold text-slate-800 text-sm">{activeEnquiry.eventDate || 'Date Open'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Expected Guests</span>
                <span className="font-bold text-slate-800 text-sm">{activeEnquiry.expectedGuests || 'Standard'} Pax</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Time Slot</span>
                <span className="font-bold text-slate-800 text-sm">{activeEnquiry.preferredTime || 'Flexible'}</span>
              </div>
              <div className="col-span-2 pt-3 border-t border-slate-200">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Current Status</span>
                <div className="mt-1">{getStatusBadge(activeEnquiry.status)}</div>
              </div>
              <div className="col-span-2 pt-3 border-t border-slate-200 text-right">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Est. Total Quote</span>
                <span className="font-mono font-bold text-base text-[#b38938]">
                  {activeEnquiry.totalAmountEstimate
                    ? `₹${activeEnquiry.totalAmountEstimate.toLocaleString()}`
                    : 'Upon Custom Quotation'}
                </span>
              </div>
            </div>

            {/* Requirements & Dietary Notes */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Customer Requirements & Menu Specifications
              </span>
              <div className="bg-amber-50/40 p-4 rounded-xl border border-amber-200/70 text-xs text-slate-700 leading-relaxed">
                {activeEnquiry.requirements || 'No special requirements noted.'}
                {activeEnquiry.cateringPreference && (
                  <div className="mt-2 pt-2 border-t border-amber-200/50 flex items-center gap-2">
                    <span className="font-bold text-[#b38938]">Catering Note:</span>
                    <span>{activeEnquiry.cateringPreference}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Manager Follow-up Actions */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Manager Follow-Up Actions
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    handleStatusChangeInline(activeEnquiry.id, 'contacted');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Mark Contacted</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleStatusChangeInline(activeEnquiry.id, 'follow-up');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Follow-Up</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleStatusChangeInline(activeEnquiry.id, 'confirmed');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Confirm Slot</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleStatusChangeInline(activeEnquiry.id, 'cancelled');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Decline / Cancel</span>
                </button>
              </div>

              {/* Direct Communications */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <a
                  href={`tel:${activeEnquiry.mobileNumber}`}
                  className="flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Call Customer Directly</span>
                </a>
                <a
                  href={`https://wa.me/${activeEnquiry.mobileNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                    `Namaskar ${activeEnquiry.customerName}! This is Hotel Sai Maya Banquet Operations regarding your booking inquiry for ${activeEnquiry.eventType || 'the hall'} on ${activeEnquiry.eventDate || 'your proposed date'} (Ref: ${activeEnquiry.referenceCode || 'HSM'}). We are pleased to confirm that our Sanctuary Hall and Satvik Pure-Veg catering are available. May we arrange a hall visit for you?`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-2 py-2.5 px-4 bg-[#25D366] hover:bg-[#1eb857] text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Send WhatsApp Proposal</span>
                </a>
              </div>
            </div>

            {/* Audit Trail & Notes */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Audit Trail & Staff Notes
              </span>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {activeEnquiry.history.map((log) => (
                  <div key={log.id} className="text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                      <span className="font-bold text-slate-700">{log.action}</span>
                      <span className="font-mono">{log.timestamp} • {log.staffName}</span>
                    </div>
                    {log.note && <p className="text-slate-600 leading-relaxed">{log.note}</p>}
                  </div>
                ))}
              </div>

              {/* Add Note Form */}
              <form onSubmit={handleAddNote} className="flex gap-2">
                <input
                  type="text"
                  value={noteInput}
                  onChange={(e) => setNoteInput(e.target.value)}
                  placeholder="Record customer discussion, catering quote, or hall tour..."
                  className="flex-1 py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#b38938]/30"
                />
                <button
                  type="submit"
                  className="py-2 px-4 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Save Note
                </button>
              </form>
            </div>

            {/* Modal Footer */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => handleDeleteCurrent(activeEnquiry.id)}
                className="text-xs text-rose-500 hover:text-rose-700 flex items-center gap-1 cursor-pointer font-semibold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Lead</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handlePrintLeadSheet(activeEnquiry)}
                  className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Lead Sheet</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsReviewDrawerOpen(false)}
                  className="py-2 px-4 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Close Review
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Manual Add Enquiry Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#b38938]">CONCIERGE DESK</span>
                <h3 className="text-lg font-serif font-bold text-slate-900">Log Offline Banquet Lead</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateManualEnquiry} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Customer / Host Name *</label>
                <input
                  type="text"
                  required
                  value={newEnquiryForm.customerName}
                  onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, customerName: e.target.value })}
                  placeholder="e.g. Ramesh Kulkarni"
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={newEnquiryForm.mobileNumber}
                    onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, mobileNumber: e.target.value })}
                    placeholder="+91 98XXX XXXXX"
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={newEnquiryForm.email}
                    onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, email: e.target.value })}
                    placeholder="host@example.com"
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Event Type</label>
                  <select
                    value={newEnquiryForm.eventType}
                    onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, eventType: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white cursor-pointer"
                  >
                    <option value="Wedding Reception">Wedding Reception</option>
                    <option value="Sakharpuda / Ring Ceremony">Sakharpuda / Ring Ceremony</option>
                    <option value="Family Milestone / Birthday">Family Milestone / Birthday</option>
                    <option value="Pilgrim Group Satsang">Pilgrim Group Satsang</option>
                    <option value="Corporate Retreat">Corporate Retreat</option>
                    <option value="Naming Ceremony">Naming Ceremony</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Proposed Event Date</label>
                  <input
                    type="date"
                    value={newEnquiryForm.eventDate}
                    onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, eventDate: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Expected Guests (Pax)</label>
                  <input
                    type="number"
                    value={newEnquiryForm.expectedGuests}
                    onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, expectedGuests: e.target.value })}
                    placeholder="e.g. 100"
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Time Slot</label>
                  <select
                    value={newEnquiryForm.preferredTime}
                    onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, preferredTime: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white cursor-pointer"
                  >
                    <option value="Morning (9:00 AM – 3:00 PM)">Morning (9:00 AM – 3:00 PM)</option>
                    <option value="Evening (6:00 PM – 11:00 PM)">Evening (6:00 PM – 11:00 PM)</option>
                    <option value="Full Day Window">Full Day Window</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Special Requirements & Catering</label>
                <textarea
                  rows={3}
                  value={newEnquiryForm.requirements}
                  onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, requirements: e.target.value })}
                  placeholder="Satvik menu specs, Jain food, stage backdrop, etc..."
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Estimated Budget / Package Quote (₹)</label>
                <input
                  type="number"
                  value={newEnquiryForm.totalAmountEstimate}
                  onChange={(e) => setNewEnquiryForm({ ...newEnquiryForm, totalAmountEstimate: Number(e.target.value) })}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="py-2 px-4 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2 px-5 rounded-xl bg-[#b38938] hover:bg-[#8f6d2b] text-white font-bold shadow-xs transition-colors cursor-pointer"
                >
                  Save Banquet Lead
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
