import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import {
  MapPin,
  Compass,
  Navigation,
  ExternalLink,
  Check,
  Plus,
  Trash2
} from 'lucide-react';

export const LocationManager: React.FC = () => {
  const { locationSettings, updateLocationSettings } = useAdmin();

  const [form, setForm] = useState(locationSettings);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [newLandmark, setNewLandmark] = useState({ name: '', distance: '' });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateLocationSettings(form);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleAddLandmark = () => {
    if (!newLandmark.name || !newLandmark.distance) return;
    setForm({
      ...form,
      nearbyLandmarks: [...form.nearbyLandmarks, { ...newLandmark }]
    });
    setNewLandmark({ name: '', distance: '' });
  };

  const handleRemoveLandmark = (idx: number) => {
    setForm({
      ...form,
      nearbyLandmarks: form.nearbyLandmarks.filter((_, i) => i !== idx)
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Geographic Intelligence
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Location & Highway Navigation Settings
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Configure Google Maps embed parameters, GPS coordinates, highway transit milestones, and secure coach parking.
          </p>
        </div>

        {form.directionsUrl && (
          <a
            href={form.directionsUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors shrink-0"
          >
            <span>Test Google Maps Navigation</span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </a>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">
              Corridor Address & GPS Coordinates
            </h2>
            {savedSuccess && (
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                Updated!
              </span>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Full Physical Address
            </label>
            <input
              type="text"
              required
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Latitude Coordinate
              </label>
              <input
                type="number"
                step="any"
                value={form.latitude}
                onChange={(e) => setForm({ ...form, latitude: Number(e.target.value) })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Longitude Coordinate
              </label>
              <input
                type="number"
                step="any"
                value={form.longitude}
                onChange={(e) => setForm({ ...form, longitude: Number(e.target.value) })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Google Maps Embed URL (iframe source)
            </label>
            <input
              type="url"
              value={form.googleMapsEmbedUrl}
              onChange={(e) => setForm({ ...form, googleMapsEmbedUrl: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Direct Google Directions URL
            </label>
            <input
              type="url"
              value={form.directionsUrl}
              onChange={(e) => setForm({ ...form, directionsUrl: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Parking Instructions & Coach Access
            </label>
            <textarea
              rows={2}
              value={form.parkingInstructions}
              onChange={(e) => setForm({ ...form, parkingInstructions: e.target.value })}
              className="w-full text-xs px-3.5 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
            />
          </div>
        </div>

        {/* Nearby Landmarks & Corridor Distances (Blueprint #17) */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Corridor Landmarks & Transit Distances
              </h2>
              <p className="text-xs text-slate-500">
                Helps highway travelers gauge transit time to holy shrines and transport junctions.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {form.nearbyLandmarks.map((lm, idx) => (
              <div
                key={idx}
                className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-slate-900">{lm.name}</div>
                  <div className="text-xs text-[#b38938] font-mono font-semibold">{lm.distance}</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveLandmark(idx)}
                  className="text-slate-400 hover:text-rose-600 p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          <div className="flex gap-2 pt-2">
            <input
              type="text"
              value={newLandmark.name}
              onChange={(e) => setNewLandmark({ ...newLandmark, name: e.target.value })}
              placeholder="Landmark name (e.g. Shani Shingnapur Turning)"
              className="flex-1 text-xs px-3 py-2 border border-slate-300 rounded-lg"
            />
            <input
              type="text"
              value={newLandmark.distance}
              onChange={(e) => setNewLandmark({ ...newLandmark, distance: e.target.value })}
              placeholder="Distance (e.g. 58 km)"
              className="w-36 text-xs px-3 py-2 border border-slate-300 rounded-lg"
            />
            <button
              type="button"
              onClick={handleAddLandmark}
              className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-black"
            >
              Add
            </button>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-bold rounded-lg shadow transition-colors cursor-pointer"
          >
            Save Location Settings
          </button>
        </div>
      </form>
    </div>
  );
};
