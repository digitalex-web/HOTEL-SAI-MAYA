import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { GalleryMediaItem } from '../../types';
import {
  Plus,
  Trash2,
  Star,
  Check,
  X,
  Sparkles,
  Image as ImageIcon,
  Eye,
  EyeOff,
  Edit3,
  SlidersHorizontal,
  RefreshCw
} from 'lucide-react';

const CURATED_IMAGE_PRESETS = [
  {
    title: 'Grand Banquet Chandelier Hall',
    category: 'banquet' as const,
    subCategory: 'hall' as const,
    url: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=240&q=70'
  },
  {
    title: 'Royal Satvik Thali & Feast',
    category: 'restaurant' as const,
    subCategory: 'food' as const,
    url: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=240&q=70'
  },
  {
    title: 'Mandap Floral Wedding Stage',
    category: 'banquet' as const,
    subCategory: 'decorations' as const,
    url: 'https://images.unsplash.com/photo-1544077960-604201fe74bc?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1544077960-604201fe74bc?auto=format&fit=crop&w=240&q=70'
  },
  {
    title: 'Highway Facade & 80+ Parking',
    category: 'restaurant' as const,
    subCategory: 'exterior' as const,
    url: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=240&q=70'
  },
  {
    title: 'Live Satvik Buffet Feast Setup',
    category: 'banquet' as const,
    subCategory: 'dining' as const,
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=240&q=70'
  },
  {
    title: 'Traditional Sweets & Mithai Display',
    category: 'restaurant' as const,
    subCategory: 'food' as const,
    url: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=240&q=70'
  },
  {
    title: 'Air-Conditioned Family Dining Hall',
    category: 'restaurant' as const,
    subCategory: 'dining' as const,
    url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=240&q=70'
  },
  {
    title: 'Celebration Stage Lighting & Mandap',
    category: 'banquet' as const,
    subCategory: 'events' as const,
    url: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1200&q=85',
    thumbnail: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=240&q=70'
  }
];

export const MediaManager: React.FC<{ isOpenAddModal: boolean; onCloseAddModal: () => void }> = ({
  isOpenAddModal,
  onCloseAddModal
}) => {
  const { galleryItems, addGalleryItem, updateGalleryItem, toggleGalleryFeatured, deleteGalleryItem } = useAdmin();

  const [activeCategoryTab, setActiveCategoryTab] = useState<'all' | 'restaurant' | 'banquet'>('all');
  const [subCategoryFilter, setSubCategoryFilter] = useState<string>('all');

  // Edit Current Image State
  const [editingMedia, setEditingMedia] = useState<GalleryMediaItem | null>(null);
  const [editForm, setEditForm] = useState<Partial<GalleryMediaItem>>({});
  const [editSuccessMsg, setEditSuccessMsg] = useState<string | null>(null);

  // Add Media Form
  const [mediaForm, setMediaForm] = useState<Partial<GalleryMediaItem>>({
    title: '',
    category: 'banquet',
    subCategory: 'hall',
    image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1000&q=85',
    caption: '',
    isFeatured: true,
    isPublished: true
  });

  const filteredItems = galleryItems.filter((item) => {
    const matchesCat = activeCategoryTab === 'all' || item.category === activeCategoryTab;
    const matchesSub = subCategoryFilter === 'all' || item.subCategory === subCategoryFilter;
    return matchesCat && matchesSub;
  });

  const handleOpenEdit = (media: GalleryMediaItem) => {
    setEditingMedia(media);
    setEditForm({
      title: media.title,
      category: media.category,
      subCategory: media.subCategory,
      image: media.image,
      caption: media.caption || '',
      isFeatured: media.isFeatured,
      isPublished: media.isPublished !== false
    });
    setEditSuccessMsg(null);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMedia || !editForm.title || !editForm.image) return;

    updateGalleryItem(editingMedia.id, {
      title: editForm.title,
      category: (editForm.category as 'restaurant' | 'banquet') || 'banquet',
      subCategory: (editForm.subCategory as any) || 'hall',
      image: editForm.image,
      caption: editForm.caption || '',
      isFeatured: !!editForm.isFeatured,
      isPublished: editForm.isPublished !== false
    });

    setEditSuccessMsg('Current image updated successfully!');
    setTimeout(() => {
      setEditingMedia(null);
      setEditSuccessMsg(null);
    }, 900);
  };

  const handleSaveMedia = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaForm.title || !mediaForm.image) return;

    addGalleryItem({
      title: mediaForm.title,
      category: (mediaForm.category as 'restaurant' | 'banquet') || 'banquet',
      subCategory: (mediaForm.subCategory as any) || 'hall',
      image: mediaForm.image,
      caption: mediaForm.caption || '',
      isFeatured: !!mediaForm.isFeatured,
      isPublished: true
    });

    onCloseAddModal();
    setMediaForm({
      title: '',
      category: 'banquet',
      subCategory: 'hall',
      image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1000&q=85',
      caption: '',
      isFeatured: true,
      isPublished: true
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Visual Media Hub
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Gallery & Media Manager
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Curate high-definition dining photographs, celebration hall stages, and pure-vegetarian thali imagery.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Category tabs */}
          <div className="inline-flex rounded-lg border border-slate-200 p-1 bg-slate-50">
            <button
              type="button"
              onClick={() => {
                setActiveCategoryTab('all');
                setSubCategoryFilter('all');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeCategoryTab === 'all'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                  : 'text-slate-600'
              }`}
            >
              All Media ({galleryItems.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveCategoryTab('banquet');
                setSubCategoryFilter('all');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeCategoryTab === 'banquet'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                  : 'text-slate-600'
              }`}
            >
              Banquet ({galleryItems.filter(g => g.category === 'banquet').length})
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveCategoryTab('restaurant');
                setSubCategoryFilter('all');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeCategoryTab === 'restaurant'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                  : 'text-slate-600'
              }`}
            >
              Restaurant ({galleryItems.filter(g => g.category === 'restaurant').length})
            </button>
          </div>

          <button
            type="button"
            id="edit-current-image-top-btn"
            onClick={() => {
              const target = filteredItems[0] || galleryItems[0];
              if (target) handleOpenEdit(target);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg border border-slate-200 shadow-xs transition-colors cursor-pointer"
            title="Edit Current Selected Image"
          >
            <Edit3 className="w-3.5 h-3.5 text-[#b38938]" />
            <span>Edit Current Image</span>
          </button>

          <button
            type="button"
            onClick={onCloseAddModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Photo</span>
          </button>
        </div>
      </div>

      {/* Gallery Media Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredItems.map((media) => (
          <div
            key={media.id}
            className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm hover:shadow transition-all group flex flex-col justify-between"
          >
            <div className="relative aspect-video bg-slate-100 overflow-hidden">
              <img
                src={media.image}
                alt={media.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute top-2 left-2 flex gap-1 z-20">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-black/60 text-white backdrop-blur-xs">
                  {media.category}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/90 text-slate-800 backdrop-blur-xs capitalize">
                  {media.subCategory}
                </span>
              </div>

              {/* Hover Quick Edit Overlay */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center z-10 backdrop-blur-[1px]">
                <button
                  type="button"
                  id={`overlay-edit-image-${media.id}`}
                  onClick={() => handleOpenEdit(media)}
                  className="px-3 py-1.5 rounded-lg bg-white/95 hover:bg-white text-slate-900 font-semibold text-xs shadow-md flex items-center gap-1.5 transition-all transform hover:scale-105 cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5 text-[#b38938]" />
                  <span>Edit Current Image</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => toggleGalleryFeatured(media.id)}
                title={media.isFeatured ? 'Featured Image' : 'Mark as Featured'}
                className={`absolute top-2 right-2 z-20 p-1.5 rounded-full backdrop-blur-xs transition-colors ${
                  media.isFeatured
                    ? 'bg-amber-400 text-slate-900 shadow'
                    : 'bg-black/40 text-white hover:bg-black/60'
                }`}
              >
                <Star className="w-3.5 h-3.5 fill-current" />
              </button>
            </div>

            <div className="p-3.5 flex-1 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{media.title}</h4>
                <p className="text-[11px] text-slate-500 line-clamp-2 mt-1">{media.caption}</p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  type="button"
                  id={`edit-image-btn-${media.id}`}
                  onClick={() => handleOpenEdit(media)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-slate-700 hover:text-[#b38938] hover:bg-amber-50/70 border border-slate-200 transition-colors font-medium text-[11px] cursor-pointer"
                  title="Edit Current Image"
                >
                  <Edit3 className="w-3 h-3 text-[#b38938]" />
                  <span>Edit Current Image</span>
                </button>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-slate-400">{media.createdAt}</span>
                  <button
                    type="button"
                    onClick={() => deleteGalleryItem(media.id)}
                    className="text-slate-400 hover:text-rose-600 transition-colors p-1 cursor-pointer"
                    title="Delete media"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Media Modal */}
      {isOpenAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-serif font-bold text-slate-900">
                + Upload / Add Gallery Photo
              </h3>
              <button
                type="button"
                onClick={onCloseAddModal}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form className="mt-4 space-y-3" onSubmit={handleSaveMedia}>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Photo Title *
                </label>
                <input
                  type="text"
                  required
                  value={mediaForm.title}
                  onChange={(e) => setMediaForm({ ...mediaForm, title: e.target.value })}
                  placeholder="e.g. Chandelier Banquet Setup"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Primary Area
                  </label>
                  <select
                    value={mediaForm.category}
                    onChange={(e) =>
                      setMediaForm({ ...mediaForm, category: e.target.value as any })
                    }
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="banquet">Banquet</option>
                    <option value="restaurant">Restaurant</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Sub-Category
                  </label>
                  <select
                    value={mediaForm.subCategory}
                    onChange={(e) =>
                      setMediaForm({ ...mediaForm, subCategory: e.target.value as any })
                    }
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="hall">Hall</option>
                    <option value="seating">Seating</option>
                    <option value="decorations">Decorations</option>
                    <option value="dining">Dining</option>
                    <option value="food">Food</option>
                    <option value="exterior">Exterior</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Image URL (WebP / Optimized) *
                </label>
                <input
                  type="url"
                  required
                  value={mediaForm.image}
                  onChange={(e) => setMediaForm({ ...mediaForm, image: e.target.value })}
                  placeholder="https://..."
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Caption / Narrative
                </label>
                <textarea
                  rows={2}
                  value={mediaForm.caption}
                  onChange={(e) => setMediaForm({ ...mediaForm, caption: e.target.value })}
                  placeholder="Brief context of the occasion or culinary preparation..."
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="featured-check"
                  checked={mediaForm.isFeatured}
                  onChange={(e) =>
                    setMediaForm({ ...mediaForm, isFeatured: e.target.checked })
                  }
                  className="rounded border-slate-300 text-[#b38938]"
                />
                <label htmlFor="featured-check" className="text-xs text-slate-700 cursor-pointer">
                  Mark as Featured in Carousel
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={onCloseAddModal}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-lg text-xs font-semibold shadow"
                >
                  Publish Photo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Current Image Modal */}
      {editingMedia && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-[#b38938] flex items-center justify-center">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-serif font-bold text-slate-900">
                    Edit Current Image
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Modify current visual asset, switch to presets, or adjust category tags
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingMedia(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {editSuccessMsg ? (
              <div className="py-10 text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-slate-900">{editSuccessMsg}</h4>
                <p className="text-xs text-slate-500">Synchronizing gallery preview...</p>
              </div>
            ) : (
              <form className="mt-4 space-y-4" onSubmit={handleSaveEdit}>
                {/* Real-time Image Preview */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600 uppercase tracking-wider mb-2">
                    <span>Live Image Preview</span>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      Active Target
                    </span>
                  </div>
                  <div className="relative aspect-video w-full rounded-lg overflow-hidden border border-slate-200 bg-slate-900">
                    <img
                      src={editForm.image || editingMedia.image}
                      alt={editForm.title || 'Preview'}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-2 left-2 bg-black/70 backdrop-blur-xs text-white px-2.5 py-1 rounded text-[10px] font-medium flex items-center gap-1.5">
                      <span className="uppercase text-amber-300 font-bold">{editForm.category}</span>
                      <span>•</span>
                      <span className="capitalize">{editForm.subCategory}</span>
                    </div>
                  </div>
                </div>

                {/* Preset Fast Picker */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#b38938]" />
                      <span>Quick Select: Hotel Sai Maya Presets</span>
                    </label>
                    <span className="text-[10px] text-slate-400">1-click replacement</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {CURATED_IMAGE_PRESETS.map((preset, idx) => {
                      const isSelected = editForm.image === preset.url;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setEditForm({
                              ...editForm,
                              image: preset.url,
                              title: editForm.title || preset.title,
                              category: preset.category,
                              subCategory: preset.subCategory
                            });
                          }}
                          className={`group text-left p-1.5 rounded-lg border text-[11px] transition-all flex flex-col gap-1 cursor-pointer ${
                            isSelected
                              ? 'border-[#b38938] bg-amber-50/60 ring-2 ring-[#b38938]/30 shadow-xs'
                              : 'border-slate-200 hover:border-slate-300 bg-white'
                          }`}
                        >
                          <img
                            src={preset.thumbnail}
                            alt={preset.title}
                            className="w-full h-14 object-cover rounded"
                          />
                          <span className="line-clamp-1 text-[10px] font-semibold text-slate-800">
                            {preset.title}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Image URL */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Image URL (High-Res WebP / CDN Link) *
                  </label>
                  <input
                    type="url"
                    required
                    value={editForm.image || ''}
                    onChange={(e) => setEditForm({ ...editForm, image: e.target.value })}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                  />
                </div>

                {/* Title */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Photo Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={editForm.title || ''}
                    onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                    placeholder="e.g. Grand Chandelier Banquet Setup"
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                  />
                </div>

                {/* Category & Subcategory */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Primary Area
                    </label>
                    <select
                      value={editForm.category || 'banquet'}
                      onChange={(e) =>
                        setEditForm({ ...editForm, category: e.target.value as any })
                      }
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="banquet">Banquet</option>
                      <option value="restaurant">Restaurant</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Sub-Category
                    </label>
                    <select
                      value={editForm.subCategory || 'hall'}
                      onChange={(e) =>
                        setEditForm({ ...editForm, subCategory: e.target.value as any })
                      }
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="hall">Hall</option>
                      <option value="seating">Seating</option>
                      <option value="decorations">Decorations</option>
                      <option value="dining">Dining</option>
                      <option value="food">Food</option>
                      <option value="exterior">Exterior</option>
                      <option value="events">Events</option>
                    </select>
                  </div>
                </div>

                {/* Caption */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Caption / Context Story
                  </label>
                  <textarea
                    rows={2}
                    value={editForm.caption || ''}
                    onChange={(e) => setEditForm({ ...editForm, caption: e.target.value })}
                    placeholder="Brief description of the setup or celebration..."
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>

                {/* Toggles */}
                <div className="flex flex-wrap items-center gap-4 pt-1">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!!editForm.isFeatured}
                      onChange={(e) =>
                        setEditForm({ ...editForm, isFeatured: e.target.checked })
                      }
                      className="rounded border-slate-300 text-[#b38938]"
                    />
                    <span>Mark as Featured in Carousel</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editForm.isPublished !== false}
                      onChange={(e) =>
                        setEditForm({ ...editForm, isPublished: e.target.checked })
                      }
                      className="rounded border-slate-300 text-[#b38938]"
                    />
                    <span>Published & Visible to Guests</span>
                  </label>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setEditingMedia(null)}
                    className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-lg text-xs font-semibold shadow transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Save & Update Image</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
