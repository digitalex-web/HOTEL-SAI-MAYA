import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { MenuItem, MenuCategoryItem } from '../../types';
import {
  Plus,
  Search,
  Edit2,
  Copy,
  Eye,
  EyeOff,
  Trash2,
  Check,
  X,
  Filter,
  Sparkles,
  UtensilsCrossed,
  Layers
} from 'lucide-react';

export const MenuManager: React.FC<{ isOpenAddModal: boolean; onCloseAddModal: () => void }> = ({
  isOpenAddModal,
  onCloseAddModal
}) => {
  const {
    menuItems,
    categories,
    addMenuItem,
    updateMenuItem,
    duplicateMenuItem,
    deleteMenuItem,
    addCategory,
    updateCategory,
    deleteCategory
  } = useAdmin();

  const [activeTab, setActiveTab] = useState<'items' | 'categories'>('items');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | 'jain' | 'signature'>('all');

  // Edit item state
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  // Form state for add/edit item
  const [formData, setFormData] = useState<Partial<MenuItem>>({
    name: '',
    category: 'thali',
    categoryLabel: 'Royal Thalis & Heritage Maharashtrian',
    price: 250,
    isPureVeg: true,
    isJainAvailable: false,
    isSignature: false,
    aromaProfile: '',
    story: '',
    cookingTimeMinutes: 10,
    image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=1000&q=85',
    spiciness: 'Medium'
  });

  // Category Modal
  const [categoryModal, setCategoryModal] = useState(false);
  const [catFormData, setCatFormData] = useState<Partial<MenuCategoryItem>>({
    name: '',
    slug: '',
    description: '',
    displayOrder: 1,
    isActive: true
  });

  // Filtered menu items
  const filteredItems = menuItems.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.story.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategoryFilter === 'all' || item.category === selectedCategoryFilter;

    const matchesDietary =
      dietaryFilter === 'all'
        ? true
        : dietaryFilter === 'jain'
        ? item.isJainAvailable
        : item.isSignature;

    return matchesSearch && matchesCategory && matchesDietary;
  });

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      name: '',
      category: 'thali',
      categoryLabel: 'Royal Thalis & Heritage Maharashtrian',
      price: 250,
      isPureVeg: true,
      isJainAvailable: false,
      isSignature: false,
      aromaProfile: '',
      story: '',
      cookingTimeMinutes: 10,
      image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=1000&q=85',
      spiciness: 'Medium'
    });
  };

  const handleOpenEdit = (item: MenuItem) => {
    setEditingItem(item);
    setFormData({ ...item });
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.price) return;

    const selectedCat = categories.find((c) => c.slug === formData.category);
    const catLabel = selectedCat ? selectedCat.name : 'Royal Thalis & Heritage Maharashtrian';

    const itemToSave = {
      name: formData.name || 'Untitled Dish',
      category: (formData.category as 'thali' | 'punjabi' | 'express') || 'thali',
      categoryLabel: catLabel,
      price: Number(formData.price) || 0,
      isPureVeg: true,
      isJainAvailable: !!formData.isJainAvailable,
      isSignature: !!formData.isSignature,
      aromaProfile: formData.aromaProfile || 'Artisanal stone-ground spices & pure cow ghee.',
      story: formData.story || 'Freshly prepared upon highway arrival.',
      cookingTimeMinutes: Number(formData.cookingTimeMinutes) || 10,
      image: formData.image || 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=1000&q=85',
      spiciness: formData.spiciness || 'Medium'
    };

    if (editingItem) {
      updateMenuItem(editingItem.id, itemToSave);
      setEditingItem(null);
    } else {
      addMenuItem(itemToSave);
      onCloseAddModal();
    }
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catFormData.name) return;

    const slug =
      catFormData.slug ||
      catFormData.name.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 15);

    addCategory({
      name: catFormData.name,
      slug,
      description: catFormData.description || '',
      displayOrder: Number(catFormData.displayOrder) || categories.length + 1,
      isActive: true
    });

    setCategoryModal(false);
    setCatFormData({ name: '', slug: '', description: '', displayOrder: 1, isActive: true });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Restaurant & Highway Kitchen
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Restaurant Menu Manager
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Live catalog control for royal thalis, Punjabi curries, express starters, prices, and Jain availability.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="inline-flex rounded-lg border border-slate-200 p-1 bg-slate-50">
            <button
              type="button"
              onClick={() => setActiveTab('items')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'items'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Menu Items ({menuItems.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('categories')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'categories'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Categories ({categories.length})
            </button>
          </div>

          {activeTab === 'items' ? (
            <button
              type="button"
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Menu Item</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setCategoryModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Category</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === 'items' ? (
        <>
          {/* Search and Filters Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dishes by name, ingredients, or style..."
                className="w-full pl-10 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-[#c5a059] focus:border-[#c5a059] text-slate-900 bg-white"
              />
            </div>

            {/* Category Filter */}
            <div className="flex items-center gap-2">
              <select
                value={selectedCategoryFilter}
                onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                className="text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white text-slate-700 focus:ring-2 focus:ring-[#c5a059]"
              >
                <option value="all">All Categories ({menuItems.length})</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.slug}>
                    {cat.name}
                  </option>
                ))}
              </select>

              {/* Jain / Signature Filter */}
              <select
                value={dietaryFilter}
                onChange={(e) => setDietaryFilter(e.target.value as any)}
                className="text-xs px-3 py-2 border border-slate-200 rounded-lg bg-white text-slate-700 focus:ring-2 focus:ring-[#c5a059]"
              >
                <option value="all">All Specialties</option>
                <option value="jain">Jain Available Only</option>
                <option value="signature">Signature Only</option>
              </select>
            </div>
          </div>

          {/* Dishes Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3.5 px-4">Dish</th>
                    <th className="py-3.5 px-3">Category</th>
                    <th className="py-3.5 px-3">Price</th>
                    <th className="py-3.5 px-3">Tags & Diet</th>
                    <th className="py-3.5 px-3">Prep Time</th>
                    <th className="py-3.5 px-4 text-right">Controls</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredItems.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        No dishes matched your filter or search query.
                      </td>
                    </tr>
                  ) : (
                    filteredItems.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                        {/* Image & Title */}
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-11 h-11 rounded-lg object-cover border border-slate-200 shrink-0"
                            />
                            <div>
                              <div className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                                <span>{item.name}</span>
                                {item.isSignature && (
                                  <span className="text-[10px] bg-amber-50 text-[#b38938] border border-amber-200 font-medium px-1.5 py-0.2 rounded">
                                    ★ Signature
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-500 line-clamp-1 max-w-xs mt-0.5">
                                {item.story}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Category */}
                        <td className="py-3 px-3">
                          <span className="inline-block bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium">
                            {item.categoryLabel}
                          </span>
                        </td>

                        {/* Price */}
                        <td className="py-3 px-3 font-mono font-bold text-slate-900 text-xs">
                          ₹{item.price}
                        </td>

                        {/* Dietary Tags */}
                        <td className="py-3 px-3">
                          <div className="flex flex-wrap gap-1">
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                              Veg
                            </span>
                            {item.isJainAvailable && (
                              <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-sky-50 text-sky-700 border border-sky-200">
                                Jain Available
                              </span>
                            )}
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600">
                              {item.spiciness}
                            </span>
                          </div>
                        </td>

                        {/* Prep Time */}
                        <td className="py-3 px-3 text-slate-500 font-mono">
                          {item.cookingTimeMinutes}m
                        </td>

                        {/* Action Controls */}
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(item)}
                              title="Edit Dish"
                              className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => duplicateMenuItem(item.id)}
                              title="Duplicate Dish"
                              className="p-1.5 text-slate-500 hover:text-[#b38938] hover:bg-amber-50 rounded-md transition-colors cursor-pointer"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteMenuItem(item.id)}
                              title="Delete Dish"
                              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* Categories Manager */
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Menu Categories
              </h3>
              <p className="text-xs text-slate-500">
                Organize dining groupings for thalis, North Indian curries, and beverages.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {categories.map((cat) => (
              <div
                key={cat.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono text-slate-500 bg-slate-200 px-1.5 py-0.5 rounded">
                      Order: {cat.displayOrder}
                    </span>
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                      Active
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900">{cat.name}</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{cat.description}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-mono text-[11px]">slug: {cat.slug}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => deleteCategory(cat.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                      title="Delete category"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add / Edit Dish Modal */}
      {(editingItem || isOpenAddModal) && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h3 className="text-lg font-serif font-bold text-slate-900">
                {editingItem ? 'Edit Dish Details' : 'Add New Menu Item'}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setEditingItem(null);
                  onCloseAddModal();
                }}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form className="mt-5 space-y-4" onSubmit={handleSaveItem}>
              {/* Dish Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Dish Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Imperial Maharashtrian Thali"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              {/* Category & Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Category *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        category: e.target.value as any
                      })
                    }
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-[#c5a059]"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.slug}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Price (₹) *
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                    placeholder="250"
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-[#c5a059]"
                  />
                </div>
              </div>

              {/* Description / Story */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Culinary Description / Heritage Story
                </label>
                <textarea
                  rows={2}
                  value={formData.story}
                  onChange={(e) => setFormData({ ...formData, story: e.target.value })}
                  placeholder="Prepared with authentic stone-ground Khandeshi spices..."
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              {/* Aroma Profile */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Aroma Profile Notes
                </label>
                <input
                  type="text"
                  value={formData.aromaProfile}
                  onChange={(e) => setFormData({ ...formData, aromaProfile: e.target.value })}
                  placeholder="Woodfire Dagad Phool, roasted sesame & pure Gir cow ghee"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                />
              </div>

              {/* Image URL & Spiciness */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Food Photograph (Image URL)
                  </label>
                  <input
                    type="url"
                    value={formData.image}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    placeholder="https://..."
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Spiciness Level
                  </label>
                  <select
                    value={formData.spiciness}
                    onChange={(e) => setFormData({ ...formData, spiciness: e.target.value as any })}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-[#c5a059]"
                  >
                    <option value="Mild">Mild</option>
                    <option value="Medium">Medium</option>
                    <option value="Khandeshi Bold">Khandeshi Bold</option>
                  </select>
                </div>
              </div>

              {/* Toggles Checklist */}
              <div className="pt-2 grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                  <input
                    type="checkbox"
                    checked={formData.isPureVeg}
                    disabled
                    className="rounded border-slate-300 text-emerald-600"
                  />
                  <span className="font-semibold text-emerald-700">100% Pure Vegetarian (Fixed)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                  <input
                    type="checkbox"
                    checked={formData.isJainAvailable}
                    onChange={(e) =>
                      setFormData({ ...formData, isJainAvailable: e.target.checked })
                    }
                    className="rounded border-slate-300 text-[#b38938] focus:ring-[#c5a059]"
                  />
                  <span>Jain Preparation Available</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                  <input
                    type="checkbox"
                    checked={formData.isSignature}
                    onChange={(e) =>
                      setFormData({ ...formData, isSignature: e.target.checked })
                    }
                    className="rounded border-slate-300 text-[#b38938] focus:ring-[#c5a059]"
                  />
                  <span>Featured / Chef's Signature</span>
                </label>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Cooking time:</span>
                  <input
                    type="number"
                    value={formData.cookingTimeMinutes}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        cookingTimeMinutes: Number(e.target.value)
                      })
                    }
                    className="w-16 text-xs px-2 py-1 border border-slate-300 rounded font-mono"
                  />
                  <span className="text-xs text-slate-500">mins</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => {
                    setEditingItem(null);
                    onCloseAddModal();
                  }}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-lg text-xs font-semibold shadow transition-colors cursor-pointer"
                >
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Category Modal */}
      {categoryModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-serif font-bold text-slate-900">
                + Add Menu Category
              </h3>
              <button
                type="button"
                onClick={() => setCategoryModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form className="mt-4 space-y-3" onSubmit={handleSaveCategory}>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Category Name *
                </label>
                <input
                  type="text"
                  required
                  value={catFormData.name}
                  onChange={(e) => setCatFormData({ ...catFormData, name: e.target.value })}
                  placeholder="e.g. Maharashtrian Specialties"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={catFormData.description}
                  onChange={(e) => setCatFormData({ ...catFormData, description: e.target.value })}
                  placeholder="Summary of this culinary selection..."
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Display Order
                </label>
                <input
                  type="number"
                  value={catFormData.displayOrder}
                  onChange={(e) =>
                    setCatFormData({ ...catFormData, displayOrder: Number(e.target.value) })
                  }
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setCategoryModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-lg text-xs font-semibold shadow transition-colors"
                >
                  Create Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
