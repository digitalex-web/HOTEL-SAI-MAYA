import React from 'react';
import { useAdmin } from '../../context/AdminContext';
import {
  Star,
  Eye,
  EyeOff,
  Trash2,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Award
} from 'lucide-react';

export const ReviewManager: React.FC = () => {
  const { reviews, toggleReviewPublished, deleteReview, businessSettings } = useAdmin();

  const publishedCount = reviews.filter((r) => r.isPublished !== false).length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Guest Sentiment & Reputation
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Review & Testimonial Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Moderate pilgrim feedback, toggle visibility on the public carousel, and link to authentic Google Reviews.
          </p>
        </div>

        <a
          href={businessSettings.googleMapsDirectionsUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors shrink-0"
        >
          <span>Leave a Google Review</span>
          <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
        </a>
      </div>

      {/* Aggregate Score Cards (Blueprint #14) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-[#b38938]">
            <Star className="w-6 h-6 fill-current" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-slate-900">4.8 / 5.0</div>
            <div className="text-xs font-medium text-slate-500">Google Pilgrim Rating</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-slate-900">{publishedCount} Live</div>
            <div className="text-xs font-medium text-slate-500">Visible on Public Website</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-slate-900">1,940+</div>
            <div className="text-xs font-medium text-slate-500">Verified Highway Yatris</div>
          </div>
        </div>
      </div>

      {/* Reviews Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900">
            Guest Testimonial Roster
          </h2>
          <span className="text-xs text-slate-500">
            Strict mandate: No fabricated reviews. Authentic pilgrim records only.
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Guest</th>
                <th className="py-3 px-3">Rating</th>
                <th className="py-3 px-4">Testimonial & Context</th>
                <th className="py-3 px-3">Highlight</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-4 text-right">Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {reviews.map((rev) => (
                <tr
                  key={rev.id}
                  className={`hover:bg-slate-50/80 transition-colors ${
                    rev.isPublished === false ? 'opacity-60 bg-slate-50/40' : ''
                  }`}
                >
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900">{rev.guestName}</div>
                    <div className="text-[11px] text-slate-400">{rev.location}</div>
                  </td>

                  <td className="py-3.5 px-3">
                    <div className="flex items-center gap-1 font-mono font-bold text-amber-500">
                      <span>{rev.rating}★</span>
                    </div>
                  </td>

                  <td className="py-3.5 px-4 max-w-md">
                    <p className="text-xs text-slate-700 line-clamp-2 leading-relaxed">
                      "{rev.reviewText}"
                    </p>
                    <div className="text-[10px] text-slate-400 mt-1">
                      Context: {rev.travelContext}
                    </div>
                  </td>

                  <td className="py-3.5 px-3">
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-[#b38938] border border-amber-200">
                      {rev.highlightDishOrAmenity}
                    </span>
                  </td>

                  <td className="py-3.5 px-3 font-mono text-[11px] text-slate-400">
                    {rev.reviewDate}
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => toggleReviewPublished(rev.id)}
                        title={rev.isPublished === false ? 'Show on Website' : 'Hide from Website'}
                        className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                          rev.isPublished === false
                            ? 'text-slate-400 hover:text-emerald-700 hover:bg-emerald-50'
                            : 'text-emerald-700 hover:bg-emerald-50'
                        }`}
                      >
                        {rev.isPublished === false ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteReview(rev.id)}
                        title="Remove Review"
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
