import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { Search, Check, Globe, Sparkles, Tag, ShieldAlert } from 'lucide-react';

export const SEOManager: React.FC = () => {
  const { seoSettings, updateSeoSettings } = useAdmin();

  const [form, setForm] = useState(seoSettings);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [keywordInput, setKeywordInput] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSeoSettings(form);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleAddKeyword = (e: React.KeyboardEvent | React.MouseEvent) => {
    if ('key' in e && e.key !== 'Enter') return;
    e.preventDefault();
    if (!keywordInput.trim()) return;
    if (!form.keywords.includes(keywordInput.trim())) {
      setForm({ ...form, keywords: [...form.keywords, keywordInput.trim()] });
    }
    setKeywordInput('');
  };

  const handleRemoveKeyword = (kw: string) => {
    setForm({ ...form, keywords: form.keywords.filter((k) => k !== kw) });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Search Engine & Social Discovery
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            SEO & Metadata Settings
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage meta tags, Open Graph social share previews, and Schema.org structured data for pilgrim queries.
          </p>
        </div>

        {savedSuccess && (
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1">
            <Check className="w-3.5 h-3.5" />
            SEO Tags Published
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Editor Form (7 cols) */}
        <form onSubmit={handleSave} className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Homepage Meta Title *
            </label>
            <input
              type="text"
              required
              value={form.metaTitle}
              onChange={(e) => setForm({ ...form, metaTitle: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
            />
            <div className="flex justify-between text-[11px] text-slate-400 mt-1">
              <span>Recommended: 50-60 characters</span>
              <span className="font-mono">{form.metaTitle.length} chars</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Meta Description *
            </label>
            <textarea
              rows={3}
              required
              value={form.metaDescription}
              onChange={(e) => setForm({ ...form, metaDescription: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
            />
            <div className="flex justify-between text-[11px] text-slate-400 mt-1">
              <span>Recommended: 150-160 characters</span>
              <span className="font-mono">{form.metaDescription.length} chars</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Target SEO Keywords
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={keywordInput}
                onChange={(e) => setKeywordInput(e.target.value)}
                onKeyDown={handleAddKeyword}
                placeholder="Type keyword & press enter (e.g. Pure Veg Restaurant Shirdi Highway)"
                className="flex-1 text-xs px-3 py-2 border border-slate-300 rounded-lg"
              />
              <button
                type="button"
                onClick={handleAddKeyword}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto">
              {form.keywords.map((kw) => (
                <span
                  key={kw}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs bg-amber-50 text-[#b38938] border border-amber-200"
                >
                  <span>{kw}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveKeyword(kw)}
                    className="text-amber-800 hover:text-rose-600 font-bold"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Schema.org Entity
              </label>
              <select
                value={form.schemaType}
                onChange={(e) => setForm({ ...form, schemaType: e.target.value })}
                className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="Restaurant">Restaurant (Default)</option>
                <option value="Hotel">Hotel</option>
                <option value="FoodEstablishment">FoodEstablishment</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Canonical URL
              </label>
              <input
                type="url"
                value={form.canonicalUrl}
                onChange={(e) => setForm({ ...form, canonicalUrl: e.target.value })}
                className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Open Graph Share Card Image URL
            </label>
            <input
              type="url"
              value={form.ogImageUrl}
              onChange={(e) => setForm({ ...form, ogImageUrl: e.target.value })}
              className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-bold rounded-lg shadow transition-colors cursor-pointer"
            >
              Save SEO Configuration
            </button>
          </div>
        </form>

        {/* Google SERP Preview & Social Card (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Google Search Result Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
            <div className="flex items-center gap-2 mb-1">
              <Globe className="w-4 h-4 text-emerald-600" />
              <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider">
                Google Search Result Preview
              </span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono line-clamp-1">
              https://hotelsaimaya.com › shirdi-kopargaon
            </div>
            <div className="text-base text-blue-800 font-medium hover:underline cursor-pointer leading-tight">
              {form.metaTitle}
            </div>
            <div className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
              {form.metaDescription}
            </div>
          </div>

          {/* Social Share Card Preview */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="p-3 border-b border-slate-100 text-[11px] font-bold text-slate-800 uppercase tracking-wider">
              Social Media Share Preview (WhatsApp & Twitter)
            </div>
            <div className="aspect-video bg-slate-100 overflow-hidden relative">
              <img
                src={form.ogImageUrl}
                alt="OG Preview"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-3.5 bg-slate-50">
              <div className="text-[10px] text-slate-400 font-mono">HOTELSAIMAYA.COM</div>
              <div className="text-xs font-bold text-slate-900 mt-0.5 line-clamp-1">
                {form.metaTitle}
              </div>
              <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                {form.metaDescription}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
