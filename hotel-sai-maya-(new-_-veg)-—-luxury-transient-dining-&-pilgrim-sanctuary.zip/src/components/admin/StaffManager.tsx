import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { AdminUser, AdminRole } from '../../types';
import {
  Users,
  UserPlus,
  Shield,
  CheckCircle2,
  Trash2,
  KeyRound,
  UserCheck,
  X
} from 'lucide-react';

export const StaffManager: React.FC = () => {
  const { staffUsers, addStaffUser, deleteStaffUser, currentUser } = useAdmin();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'restaurant_staff' as AdminRole,
    mobile: ''
  });

  const getRoleBadge = (role: AdminRole) => {
    const roles: Partial<Record<AdminRole, { label: string; color: string }>> = {
      super_admin: { label: 'Super Admin', color: 'bg-purple-50 text-purple-700 border-purple-200' },
      'Super Admin': { label: 'Super Admin', color: 'bg-purple-50 text-purple-700 border-purple-200' },
      manager: { label: 'General Manager', color: 'bg-amber-50 text-amber-700 border-amber-200' },
      Manager: { label: 'General Manager', color: 'bg-amber-50 text-amber-700 border-amber-200' },
      restaurant_staff: { label: 'Restaurant Staff', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
      'Restaurant Staff': { label: 'Restaurant Staff', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
      banquet_manager: { label: 'Banquet Manager', color: 'bg-blue-50 text-blue-700 border-blue-200' },
      'Banquet Manager': { label: 'Banquet Manager', color: 'bg-blue-50 text-blue-700 border-blue-200' },
      content_manager: { label: 'Content Manager', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
      'Content Manager': { label: 'Content Manager', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' }
    };
    const r = roles[role] || { label: role, color: 'bg-slate-100 text-slate-700 border-slate-200' };
    return (
      <span className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-semibold border ${r.color}`}>
        {r.label}
      </span>
    );
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;

    addStaffUser({
      name: formData.name,
      email: formData.email,
      role: formData.role,
      mobile: formData.mobile,
      status: 'active',
      isActive: true
    });

    setIsAddModalOpen(false);
    setFormData({ name: '', email: '', role: 'restaurant_staff', mobile: '' });
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Access Control & Operations
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Staff & Role Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Assign role-based access for banquet coordinators, head captains, inventory managers, and general directors.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer shrink-0"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>Add Staff Member</span>
        </button>
      </div>

      {/* Role Descriptions Bar (Blueprint #20 Specification) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { role: 'Super Admin', desc: 'Full control over all settings & staff' },
          { role: 'Manager', desc: 'Oversees menus, banquets & enquiries' },
          { role: 'Banquet Manager', desc: 'Manages hall calendar & events' },
          { role: 'Restaurant Staff', desc: 'Menu prices, dish availability' },
          { role: 'Content Manager', desc: 'Photos, reviews & homepage text' }
        ].map((item, idx) => (
          <div key={idx} className="p-3 bg-white rounded-xl border border-slate-200 text-xs">
            <div className="font-bold text-slate-900">{item.role}</div>
            <div className="text-[11px] text-slate-500 mt-0.5 leading-snug">{item.desc}</div>
          </div>
        ))}
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-3">Role</th>
                <th className="py-3 px-3">Contact</th>
                <th className="py-3 px-3">Last Active</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {staffUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900">{user.name}</div>
                    <div className="text-[11px] text-slate-400">{user.email}</div>
                  </td>

                  <td className="py-3.5 px-3">{getRoleBadge(user.role)}</td>

                  <td className="py-3.5 px-3 font-mono text-slate-600">
                    {user.mobile || '—'}
                  </td>

                  <td className="py-3.5 px-3 text-slate-500 font-mono text-[11px]">
                    {user.lastLoginAt || 'Never'}
                  </td>

                  <td className="py-3.5 px-3">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span>Active</span>
                    </span>
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    {(!currentUser || user.id !== currentUser.id) && user.role !== 'super_admin' && user.role !== 'Super Admin' && (
                      <button
                        type="button"
                        onClick={() => deleteStaffUser(user.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded transition-colors"
                        title="Delete User"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Staff Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-serif font-bold text-slate-900">
                + Add Staff Member
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form className="mt-4 space-y-3" onSubmit={handleAddUser}>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Ramesh Kulkarni"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Email / Login Username *
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="ramesh@hotelsaimaya.com"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Mobile Number
                </label>
                <input
                  type="text"
                  value={formData.mobile}
                  onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                  placeholder="+91 98XXXXXXXX"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  System Role *
                </label>
                <select
                  value={formData.role}
                  onChange={(e) =>
                    setFormData({ ...formData, role: e.target.value as AdminRole })
                  }
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  <option value="manager">Manager (Enquiries & Menus)</option>
                  <option value="banquet_manager">Banquet Manager (Hall & Events)</option>
                  <option value="restaurant_staff">Restaurant Staff (Menu Operations)</option>
                  <option value="content_manager">Content Manager (Gallery & Reviews)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-lg text-xs font-semibold shadow"
                >
                  Create User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
