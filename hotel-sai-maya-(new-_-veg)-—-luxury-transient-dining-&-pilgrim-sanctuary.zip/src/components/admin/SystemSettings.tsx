import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import {
  Download,
  Upload,
  RotateCcw,
  ShieldCheck,
  Lock,
  Key,
  Clock,
  Check,
  AlertTriangle,
  FileJson,
  Search,
  Activity
} from 'lucide-react';

export const SystemSettings: React.FC = () => {
  const {
    activityLogs,
    exportDataJson,
    importDataJson,
    resetToDefault,
    currentUser,
    activeSubNav
  } = useAdmin();

  const [activeTab, setActiveTab] = useState<'security' | 'backup' | 'logs'>(
    activeSubNav === 'audit-logs'
      ? 'logs'
      : activeSubNav === 'backup'
      ? 'backup'
      : 'security'
  );

  // Security password change
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [pwSuccess, setPwSuccess] = useState(false);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  // Audit log search
  const [logSearch, setLogSearch] = useState('');

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPw || newPw !== confirmPw) return;
    setPwSuccess(true);
    setCurrentPw('');
    setNewPw('');
    setConfirmPw('');
    setTimeout(() => setPwSuccess(false), 3000);
  };

  const handleExportBackup = () => {
    const jsonStr = exportDataJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hotel-sai-maya-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const ok = importDataJson(content);
        if (ok) {
          alert('Database state successfully restored!');
        } else {
          alert('Invalid backup JSON format.');
        }
      }
    };
    reader.readAsText(file);
  };

  const filteredLogs = activityLogs.filter(
    (log) =>
      (log.action || log.title || '').toLowerCase().includes(logSearch.toLowerCase()) ||
      (log.details || '').toLowerCase().includes(logSearch.toLowerCase()) ||
      (log.staffName || log.actor || '').toLowerCase().includes(logSearch.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Platform Architecture
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Security, Backups & Audit Trails
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage administrative authentication, export JSON archives, and inspect operational activity logs.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-50 border border-slate-200 rounded-xl shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('security')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'security'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600'
            }`}
          >
            Security & 2FA
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('backup')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'backup'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600'
            }`}
          >
            Backup & Restore
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('logs')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'logs'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600'
            }`}
          >
            Activity Logs ({activityLogs.length})
          </button>
        </div>
      </div>

      {/* Tab 1: Security Settings (Blueprint #22) */}
      {activeTab === 'security' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Change Password Form */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900">Change Admin Password</h2>
              {pwSuccess && (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  Password Updated!
                </span>
              )}
            </div>

            <form onSubmit={handlePasswordChange} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  value={currentPw}
                  onChange={(e) => setCurrentPw(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  required
                  value={newPw}
                  onChange={(e) => setNewPw(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  value={confirmPw}
                  onChange={(e) => setConfirmPw(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2 bg-slate-900 hover:bg-black text-white rounded-lg text-xs font-semibold shadow transition-colors cursor-pointer"
                >
                  Update Admin Password
                </button>
              </div>
            </form>
          </div>

          {/* Two-Factor Authentication Toggle */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <ShieldCheck className="w-5 h-5 text-indigo-600" />
                <h2 className="text-base font-bold text-slate-900">
                  Two-Factor Authentication (2FA)
                </h2>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Require SMS or Authenticator OTP verification before accessing banquet inquiries, guest phone numbers, and financial receipts.
              </p>

              <div className="mt-6 p-4 rounded-xl border border-indigo-100 bg-indigo-50/50 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-900">
                    2FA Security Enforcement
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {twoFactorEnabled ? 'Active for all staff logins' : 'Currently Optional'}
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={twoFactorEnabled}
                    onChange={(e) => setTwoFactorEnabled(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 mt-6 pt-3 border-t border-slate-100 font-mono">
              Session Timeout: 12 Hours | Current User: {currentUser.name}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Backup & Restore (Blueprint #23) */}
      {activeTab === 'backup' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Export JSON Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Download className="w-5 h-5 text-[#b38938]" />
                <h2 className="text-base font-bold text-slate-900">
                  Export Website Data & Database
                </h2>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Download a complete, offline JSON snapshot of all menu items, banquet configurations, inquiries, photos, reviews, and SEO settings.
              </p>

              <div className="mt-4 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-600">
                Format: JSON Archive (.json) | Includes: All 12 Data Entities
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={handleExportBackup}
                className="w-full py-2.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white rounded-lg text-xs font-bold shadow transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Database JSON Backup</span>
              </button>
            </div>
          </div>

          {/* Restore from JSON Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Upload className="w-5 h-5 text-indigo-600" />
                <h2 className="text-base font-bold text-slate-900">
                  Restore from JSON Backup
                </h2>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Upload a previously exported JSON backup file to restore menus, banquet dates, and business parameters.
              </p>

              <div className="mt-4">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Select Backup File (.json)
                </label>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportFile}
                  className="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-slate-700 hover:file:bg-slate-200"
                />
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Reset all admin settings, menus, and banquets to factory defaults?')) {
                    resetToDefault();
                  }
                }}
                className="w-full py-2 text-rose-600 hover:bg-rose-50 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset to System Factory Default</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Operational Activity Logs (Blueprint #24) */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#b38938]" />
                <span>Operational Activity Log</span>
              </h2>
              <p className="text-xs text-slate-500">
                Tamper-proof audit history recording every dish modification, price change, and enquiry status update.
              </p>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={logSearch}
                onChange={(e) => setLogSearch(e.target.value)}
                placeholder="Search audit trail..."
                className="pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 text-slate-800"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">Staff Member</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                      {log.timestamp}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                      {log.staffName || log.actor}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                        {log.action || log.title}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
