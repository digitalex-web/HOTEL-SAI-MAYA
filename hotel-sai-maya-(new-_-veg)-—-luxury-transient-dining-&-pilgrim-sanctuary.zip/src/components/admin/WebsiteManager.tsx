import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import {
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Check,
  Globe,
  Sparkles,
  ExternalLink,
  Edit2
} from 'lucide-react';

export const WebsiteManager: React.FC = () => {
  const {
    heroConfig,
    updateHeroConfig,
    homepageSections,
    toggleSectionVisibility,
    moveSection,
    toggleAdminMode
  } = useAdmin();

  const [heroForm, setHeroForm] = useState(heroConfig);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveHero = (e: React.FormEvent) => {
    e.preventDefault();
    updateHeroConfig(heroForm);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#b38938]">
              Client-Manageable CMS
            </span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-slate-900 tracking-tight">
            Homepage & Website Manager
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Update hero headlines, CTA buttons, and configure public section visibility and display order.
          </p>
        </div>

        <button
          type="button"
          onClick={() => toggleAdminMode(false)}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0"
        >
          <Globe className="w-3.5 h-3.5 text-[#b38938]" />
          <span>View Live Public Website</span>
        </button>
      </div>

      {/* Hero Section Editor (Blueprint #4) */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Hero Stage & Highway Headline Editor
            </h2>
            <p className="text-xs text-slate-500">
              Customize the primary welcome screen for pilgrims traveling on MH SH 10.
            </p>
          </div>
          {savedSuccess && (
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              Live Site Updated!
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Edit Form (7 cols) */}
          <form className="lg:col-span-7 space-y-4" onSubmit={handleSaveHero}>
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Hero Main Title *
              </label>
              <input
                type="text"
                required
                value={heroForm.title}
                onChange={(e) => setHeroForm({ ...heroForm, title: e.target.value })}
                placeholder="e.g. Pure Vegetarian Taste for Every Journey"
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Hero Subtitle / Description
              </label>
              <textarea
                rows={3}
                value={heroForm.subtitle}
                onChange={(e) => setHeroForm({ ...heroForm, subtitle: e.target.value })}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#c5a059]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Primary CTA Button Label
                </label>
                <input
                  type="text"
                  value={heroForm.primaryCtaText}
                  onChange={(e) => setHeroForm({ ...heroForm, primaryCtaText: e.target.value })}
                  placeholder="View Menu / Reserve Dining"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Secondary CTA Button Label
                </label>
                <input
                  type="text"
                  value={heroForm.secondaryCtaText}
                  onChange={(e) => setHeroForm({ ...heroForm, secondaryCtaText: e.target.value })}
                  placeholder="Get Highway Directions"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Hero Visual Background Image URL
              </label>
              <input
                type="url"
                value={heroForm.heroImage}
                onChange={(e) => setHeroForm({ ...heroForm, heroImage: e.target.value })}
                placeholder="https://images.unsplash.com/..."
                className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#b38938] hover:bg-[#8f6d2b] text-white text-xs font-bold rounded-lg shadow transition-colors cursor-pointer"
              >
                Publish Hero Changes
              </button>
            </div>
          </form>

          {/* Live Preview Miniature (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900 rounded-xl p-5 border border-slate-800 text-white flex flex-col justify-between relative overflow-hidden">
            <div
              className="absolute inset-0 opacity-25 bg-cover bg-center"
              style={{ backgroundImage: `url(${heroForm.heroImage})` }}
            />
            <div className="relative z-10">
              <div className="flex items-center gap-1.5 mb-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span className="text-[10px] uppercase tracking-widest text-[#dfbb76] font-mono">
                  Live Preview Mini
                </span>
              </div>
              <h3 className="text-lg font-serif font-bold text-white leading-tight">
                {heroForm.title || 'Untitled Hero Headline'}
              </h3>
              <p className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                {heroForm.subtitle}
              </p>
            </div>

            <div className="relative z-10 mt-6 pt-3 border-t border-white/10 flex flex-wrap gap-2">
              <span className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#b38938] to-[#8f6d2b] text-[11px] font-bold text-white shadow">
                {heroForm.primaryCtaText || 'View Menu'}
              </span>
              <span className="px-3 py-1.5 rounded-lg bg-white/10 border border-white/20 text-[11px] font-medium text-slate-200">
                {heroForm.secondaryCtaText || 'Directions'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Homepage Sections Manager: Show/Hide, Edit, Reorder (Blueprint #4) */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Homepage Sections Modular Controller
            </h2>
            <p className="text-xs text-slate-500">
              Toggle visibility (👁️ Show/Hide) and reorder (↕️ Move Up/Down) sections without code.
            </p>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {homepageSections.map((sec, idx) => (
            <div
              key={sec.id}
              className={`py-3.5 px-4 rounded-xl flex items-center justify-between gap-4 transition-colors ${
                sec.isVisible ? 'bg-white hover:bg-slate-50' : 'bg-slate-50 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs font-bold text-slate-400 w-5">
                  #{idx + 1}
                </span>
                <div>
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-2">
                    <span>{sec.name}</span>
                    {!sec.isVisible && (
                      <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-1.5 py-0.2 rounded">
                        Hidden
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-500">{sec.description}</div>
                </div>
              </div>

              {/* Controls: Reorder & Show/Hide */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => moveSection(sec.id, 'up')}
                  title="Move Up"
                  className="p-1.5 text-slate-400 hover:text-slate-800 disabled:opacity-30 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={idx === homepageSections.length - 1}
                  onClick={() => moveSection(sec.id, 'down')}
                  title="Move Down"
                  className="p-1.5 text-slate-400 hover:text-slate-800 disabled:opacity-30 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => toggleSectionVisibility(sec.id)}
                  title={sec.isVisible ? 'Hide section from public site' : 'Show section'}
                  className={`p-1.5 rounded transition-colors cursor-pointer ${
                    sec.isVisible
                      ? 'text-emerald-600 hover:bg-emerald-50'
                      : 'text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  {sec.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
