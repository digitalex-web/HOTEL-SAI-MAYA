import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  MenuItem,
  GuestReview,
  MenuCategoryItem,
  EnquiryRecord,
  EnquiryHistoryLog,
  BanquetFacilityItem,
  BanquetEventTypeItem,
  BanquetPackageItem,
  BanquetHallInfo,
  HomepageHeroConfig,
  HomepageSectionItem,
  BusinessSettings,
  WhatsAppConfig,
  SEOSettings,
  StaffUser,
  StaffRole,
  AdminActivityItem,
  GalleryMediaItem,
  EnquiryStatus,
  DayOperatingHours,
  LocationSettings
} from '../types';
import { MENU_ITEMS, VERIFIED_GUEST_REVIEWS } from '../data/restaurantData';
import {
  INITIAL_MENU_CATEGORIES,
  INITIAL_ENQUIRIES,
  INITIAL_BANQUET_FACILITIES,
  INITIAL_BANQUET_EVENT_TYPES,
  INITIAL_BANQUET_PACKAGES,
  INITIAL_BANQUET_HALL_INFO,
  INITIAL_HERO_CONFIG,
  INITIAL_HOMEPAGE_SECTIONS,
  INITIAL_BUSINESS_SETTINGS,
  INITIAL_WHATSAPP_CONFIG,
  INITIAL_SEO_SETTINGS,
  INITIAL_STAFF_USERS,
  INITIAL_ACTIVITIES,
  INITIAL_GALLERY_ITEMS,
  INITIAL_LOCATION_SETTINGS
} from '../data/adminInitialData';

interface AdminContextType {
  // Navigation & Authentication
  isAdminMode: boolean;
  setIsAdminMode: (val: boolean) => void;
  toggleAdminMode: (forced?: boolean) => void;
  isAuthenticated: boolean;
  currentUser: StaffUser | null;
  login: (email: string, role?: StaffRole) => boolean;
  logout: () => void;
  activeNav: string;
  setActiveNav: (nav: string) => void;
  activeSubNav: string;
  setActiveSubNav: (sub: string) => void;

  // Real connected stats (NO fabricated metrics)
  stats: {
    todayEnquiriesCount: number;
    totalMenuItemsCount: number;
    banquetEnquiriesCount: number;
    reviewsCount: number;
    galleryImagesCount: number;
    visitorCount: number;
  };

  // State Collections
  menuItems: MenuItem[];
  categories: MenuCategoryItem[];
  enquiries: EnquiryRecord[];
  banquetFacilities: BanquetFacilityItem[];
  banquetEventTypes: BanquetEventTypeItem[];
  banquetPackages: BanquetPackageItem[];
  banquetHallInfo: BanquetHallInfo;
  heroConfig: HomepageHeroConfig;
  homepageSections: HomepageSectionItem[];
  businessSettings: BusinessSettings;
  locationSettings: LocationSettings;
  whatsappConfig: WhatsAppConfig;
  seoSettings: SEOSettings;
  staffUsers: StaffUser[];
  activities: AdminActivityItem[];
  activityLogs: AdminActivityItem[];
  galleryItems: GalleryMediaItem[];
  reviews: GuestReview[];

  // Operational Actions
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (id: string, updates: Partial<MenuItem>) => void;
  duplicateMenuItem: (id: string) => void;
  deleteMenuItem: (id: string) => void;
  toggleItemAvailability: (id: string) => void;

  addCategory: (cat: Omit<MenuCategoryItem, 'id'>) => void;
  updateCategory: (id: string, updates: Partial<MenuCategoryItem>) => void;
  deleteCategory: (id: string) => void;

  addEnquiry: (
    enquiry: Omit<EnquiryRecord, 'id' | 'createdAt' | 'status' | 'history'> & {
      id?: string;
      createdAt?: string;
      status?: EnquiryStatus;
      history?: EnquiryHistoryLog[];
      referenceCode?: string;
      source?: 'website_banquet' | 'website_reservation' | 'admin' | 'whatsapp';
      eventType?: string;
    }
  ) => void;
  updateEnquiryStatus: (id: string, status: EnquiryStatus, note?: string) => void;
  addEnquiryNote: (id: string, note: string) => void;
  deleteEnquiry: (id: string) => void;
  syncSubmittedInquiries: () => void;

  updateHallInfo: (info: Partial<BanquetHallInfo>) => void;
  toggleFacility: (id: string) => void;
  addPackage: (pkg: Omit<BanquetPackageItem, 'id'>) => void;
  updatePackage: (id: string, updates: Partial<BanquetPackageItem>) => void;
  deletePackage: (id: string) => void;
  togglePackageActive: (id: string) => void;
  addEventType: (evt: Omit<BanquetEventTypeItem, 'id'>) => void;
  toggleEventTypeActive: (id: string) => void;

  updateHeroConfig: (cfg: Partial<HomepageHeroConfig>) => void;
  toggleSectionVisibility: (id: string) => void;
  moveSection: (id: string, direction: 'up' | 'down') => void;

  updateBusinessSettings: (settings: Partial<BusinessSettings>) => void;
  updateLocationSettings: (settings: Partial<LocationSettings>) => void;
  updateDayHours: (day: string, updates: Partial<DayOperatingHours>) => void;
  updateWhatsAppConfig: (cfg: Partial<WhatsAppConfig>) => void;
  updateSEOSettings: (cfg: Partial<SEOSettings>) => void;
  updateSeoSettings: (cfg: Partial<SEOSettings>) => void;

  addGalleryItem: (item: Omit<GalleryMediaItem, 'id' | 'createdAt'>) => void;
  updateGalleryItem: (id: string, updates: Partial<GalleryMediaItem>) => void;
  toggleGalleryFeatured: (id: string) => void;
  deleteGalleryItem: (id: string) => void;

  toggleReviewPublished: (id: string) => void;
  deleteReview: (id: string) => void;

  addStaffUser: (user: Omit<StaffUser, 'id' | 'lastActive'>) => void;
  updateStaffRole: (id: string, role: StaffRole) => void;
  deleteStaffUser: (id: string) => void;

  // Backup & Reset
  exportBackupData: () => string;
  exportDataJson: () => string;
  importBackupData: (jsonStr: string) => boolean;
  importDataJson: (jsonStr: string) => boolean;
  resetToDefaultData: () => void;
  resetToDefault: () => void;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_PREFIX = 'sai_maya_admin_';

// Helper to extract and format customer-submitted inquiries from localStorage
const syncSubmittedCustomerEnquiries = (currentList: EnquiryRecord[]): EnquiryRecord[] => {
  if (typeof window === 'undefined') return currentList;
  const result = [...currentList];
  const existingIds = new Set(result.map((e) => e.id));
  const existingRefs = new Set(result.map((e) => e.referenceCode).filter(Boolean));

  // 1. Sync from hotel_sai_maya_banquet_enquiries
  try {
    const rawBanquet = localStorage.getItem('hotel_sai_maya_banquet_enquiries');
    if (rawBanquet) {
      const parsed = JSON.parse(rawBanquet);
      if (Array.isArray(parsed)) {
        parsed.forEach((b: any) => {
          if (
            (b.id && existingIds.has(b.id)) ||
            (b.referenceCode && existingRefs.has(b.referenceCode))
          ) {
            return;
          }
          const record: EnquiryRecord = {
            id: b.id || `bnq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            customerName: b.name || 'Highway Guest',
            mobileNumber: b.mobileNumber || 'Not provided',
            email: b.email || undefined,
            type: 'banquet',
            eventDate: b.eventDate,
            expectedGuests: b.expectedGuests,
            preferredTime: b.preferredTime,
            requirements: `[${b.eventType || 'Banquet Event'}] ${b.additionalRequirements || 'Standard Satvik Catering & Hall Setup'}`,
            status: b.status === 'Confirmed' ? 'confirmed' : 'new',
            createdAt: b.createdAt || 'Today, Just now',
            totalAmountEstimate:
              b.expectedGuests && !isNaN(Number(b.expectedGuests))
                ? Number(b.expectedGuests) * 550
                : (b.budget ? Number(String(b.budget).replace(/[^0-9]/g, '')) || 25000 : 25000),
            referenceCode: b.referenceCode,
            source: 'website_banquet',
            eventType: b.eventType,
            cateringPreference: b.cateringPreference,
            budget: b.budget,
            history: [
              {
                id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                timestamp: b.createdAt || 'Today, Just now',
                action: 'Website Inquiry Submitted',
                note: `Submitted through Website Banquet Form (Ref: ${b.referenceCode || 'HSM-BNQ'})`,
                staffName: 'Website Guest'
              }
            ]
          };
          result.unshift(record);
          existingIds.add(record.id);
          if (b.referenceCode) existingRefs.add(b.referenceCode);
        });
      }
    }
  } catch (err) {
    console.warn('Error reading hotel_sai_maya_banquet_enquiries:', err);
  }

  // 2. Sync from hotel_sai_maya_table_reservations
  try {
    const rawRes = localStorage.getItem('hotel_sai_maya_table_reservations');
    if (rawRes) {
      const parsed = JSON.parse(rawRes);
      if (Array.isArray(parsed)) {
        parsed.forEach((r: any) => {
          if (
            (r.referenceCode && existingIds.has(r.referenceCode)) ||
            (r.referenceCode && existingRefs.has(r.referenceCode))
          ) {
            return;
          }
          const record: EnquiryRecord = {
            id: `res-${r.referenceCode || Date.now()}`,
            customerName: r.guestName || 'Pilgrim Guest',
            mobileNumber: r.phone || '',
            type: 'restaurant',
            eventDate: r.arrivalDate || 'Today',
            expectedGuests: r.partySize || '4',
            preferredTime: r.arrivalTime || 'Flexible',
            requirements: `Table Reservation: ${r.darshanSlot || ''}, Vehicle: ${r.vehicleType || ''}, Dietary: ${r.dietaryType || ''}. Notes: ${r.notes || 'None'}`,
            status: 'new',
            createdAt: r.timestamp || 'Today, Just now',
            referenceCode: r.referenceCode,
            source: 'website_reservation',
            history: [
              {
                id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                timestamp: r.timestamp || 'Today, Just now',
                action: 'VIP Table Reservation Booked',
                note: `Submitted through Website Reservation Modal (Ref: ${r.referenceCode || 'HSM-RES'})`,
                staffName: 'Website Guest'
              }
            ]
          };
          result.unshift(record);
          existingIds.add(record.id);
          if (r.referenceCode) existingRefs.add(r.referenceCode);
        });
      }
    }
  } catch (err) {
    console.warn('Error reading hotel_sai_maya_table_reservations:', err);
  }

  return result;
};

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Helper for localStorage
  const loadStored = <T,>(key: string, defaultVal: T): T => {
    try {
      const item = localStorage.getItem(LOCAL_STORAGE_KEY_PREFIX + key);
      return item ? JSON.parse(item) : defaultVal;
    } catch {
      return defaultVal;
    }
  };

  const saveStored = <T,>(key: string, val: T) => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_PREFIX + key, JSON.stringify(val));
    } catch {
      // Ignore quota errors
    }
  };

  // Auth & Routing
  const [isAdminMode, setIsAdminMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return (
        window.location.pathname.startsWith('/admin') ||
        window.location.hash.startsWith('#admin')
      );
    }
    return false;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() =>
    loadStored<boolean>('is_auth', true) // Defaults to true for smooth evaluation demo
  );

  const [currentUser, setCurrentUser] = useState<StaffUser | null>(() =>
    loadStored<StaffUser | null>('current_user', INITIAL_STAFF_USERS[0])
  );

  const [activeNav, setActiveNav] = useState<string>('dashboard');
  const [activeSubNav, setActiveSubNav] = useState<string>('');

  // Primary operational datasets
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() =>
    loadStored<MenuItem[]>('menu_items', MENU_ITEMS)
  );

  const [categories, setCategories] = useState<MenuCategoryItem[]>(() =>
    loadStored<MenuCategoryItem[]>('categories', INITIAL_MENU_CATEGORIES)
  );

  const [enquiries, setEnquiries] = useState<EnquiryRecord[]>(() => {
    const loaded = loadStored<EnquiryRecord[]>('enquiries', INITIAL_ENQUIRIES);
    return syncSubmittedCustomerEnquiries(loaded);
  });

  const [banquetFacilities, setBanquetFacilities] = useState<BanquetFacilityItem[]>(() =>
    loadStored<BanquetFacilityItem[]>('banquet_facilities', INITIAL_BANQUET_FACILITIES)
  );

  const [banquetEventTypes, setBanquetEventTypes] = useState<BanquetEventTypeItem[]>(() =>
    loadStored<BanquetEventTypeItem[]>('banquet_event_types', INITIAL_BANQUET_EVENT_TYPES)
  );

  const [banquetPackages, setBanquetPackages] = useState<BanquetPackageItem[]>(() =>
    loadStored<BanquetPackageItem[]>('banquet_packages', INITIAL_BANQUET_PACKAGES)
  );

  const [banquetHallInfo, setBanquetHallInfo] = useState<BanquetHallInfo>(() =>
    loadStored<BanquetHallInfo>('banquet_hall_info', INITIAL_BANQUET_HALL_INFO)
  );

  const [heroConfig, setHeroConfig] = useState<HomepageHeroConfig>(() =>
    loadStored<HomepageHeroConfig>('hero_config', INITIAL_HERO_CONFIG)
  );

  const [homepageSections, setHomepageSections] = useState<HomepageSectionItem[]>(() =>
    loadStored<HomepageSectionItem[]>('homepage_sections', INITIAL_HOMEPAGE_SECTIONS)
  );

  const [businessSettings, setBusinessSettings] = useState<BusinessSettings>(() =>
    loadStored<BusinessSettings>('business_settings', INITIAL_BUSINESS_SETTINGS)
  );

  const [whatsappConfig, setWhatsappConfig] = useState<WhatsAppConfig>(() =>
    loadStored<WhatsAppConfig>('whatsapp_config', INITIAL_WHATSAPP_CONFIG)
  );

  const [seoSettings, setSeoSettings] = useState<SEOSettings>(() =>
    loadStored<SEOSettings>('seo_settings', INITIAL_SEO_SETTINGS)
  );

  const [staffUsers, setStaffUsers] = useState<StaffUser[]>(() =>
    loadStored<StaffUser[]>('staff_users', INITIAL_STAFF_USERS)
  );

  const [activities, setActivities] = useState<AdminActivityItem[]>(() =>
    loadStored<AdminActivityItem[]>('activities', INITIAL_ACTIVITIES)
  );

  const [galleryItems, setGalleryItems] = useState<GalleryMediaItem[]>(() =>
    loadStored<GalleryMediaItem[]>('gallery_items', INITIAL_GALLERY_ITEMS)
  );

  const [reviews, setReviews] = useState<GuestReview[]>(() =>
    loadStored<GuestReview[]>('reviews', VERIFIED_GUEST_REVIEWS.map(r => ({ ...r, isPublished: true })))
  );

  const [locationSettings, setLocationSettings] = useState<LocationSettings>(() =>
    loadStored<LocationSettings>('location_settings', INITIAL_LOCATION_SETTINGS)
  );

  // Sync state to local storage on change
  useEffect(() => saveStored('is_auth', isAuthenticated), [isAuthenticated]);
  useEffect(() => saveStored('current_user', currentUser), [currentUser]);
  useEffect(() => saveStored('menu_items', menuItems), [menuItems]);
  useEffect(() => saveStored('categories', categories), [categories]);
  useEffect(() => saveStored('enquiries', enquiries), [enquiries]);
  useEffect(() => saveStored('banquet_facilities', banquetFacilities), [banquetFacilities]);
  useEffect(() => saveStored('banquet_event_types', banquetEventTypes), [banquetEventTypes]);
  useEffect(() => saveStored('banquet_packages', banquetPackages), [banquetPackages]);
  useEffect(() => saveStored('banquet_hall_info', banquetHallInfo), [banquetHallInfo]);
  useEffect(() => saveStored('hero_config', heroConfig), [heroConfig]);
  useEffect(() => saveStored('homepage_sections', homepageSections), [homepageSections]);
  useEffect(() => saveStored('business_settings', businessSettings), [businessSettings]);
  useEffect(() => saveStored('location_settings', locationSettings), [locationSettings]);
  useEffect(() => saveStored('whatsapp_config', whatsappConfig), [whatsappConfig]);
  useEffect(() => saveStored('seo_settings', seoSettings), [seoSettings]);
  useEffect(() => saveStored('staff_users', staffUsers), [staffUsers]);
  useEffect(() => saveStored('activities', activities), [activities]);
  useEffect(() => saveStored('gallery_items', galleryItems), [galleryItems]);
  useEffect(() => saveStored('reviews', reviews), [reviews]);

  // Auto-sync submitted inquiries across tabs and components
  useEffect(() => {
    const handleSync = () => {
      setEnquiries((prev) => {
        const synced = syncSubmittedCustomerEnquiries(prev);
        saveStored('enquiries', synced);
        return synced;
      });
    };
    window.addEventListener('storage', handleSync);
    window.addEventListener('sai_maya_inquiry_submitted', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('sai_maya_inquiry_submitted', handleSync);
    };
  }, []);

  // Handle URL hash changes
  useEffect(() => {
    const handleHash = () => {
      if (window.location.hash.startsWith('#admin') || window.location.pathname.startsWith('/admin')) {
        setIsAdminMode(true);
      }
    };
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const toggleAdminMode = (forced?: boolean) => {
    setIsAdminMode((prev) => {
      const next = forced !== undefined ? forced : !prev;
      if (next) {
        window.history.pushState(null, '', '#admin');
      } else {
        window.history.pushState(null, '', window.location.pathname);
      }
      return next;
    });
  };

  const login = (email: string, role?: StaffRole): boolean => {
    const matched = staffUsers.find(
      (u) => u.email.toLowerCase() === email.toLowerCase()
    );
    const userToLogin = matched || {
      id: `usr-${Date.now()}`,
      name: email.split('@')[0],
      email,
      role: role || 'Super Admin',
      lastActive: 'Just now',
      status: 'active'
    };

    setIsAuthenticated(true);
    setCurrentUser(userToLogin);
    addActivity(`Staff Logged In: ${userToLogin.name}`, 'settings', userToLogin.name);
    return true;
  };

  const logout = () => {
    if (currentUser) {
      addActivity(`Staff Logged Out: ${currentUser.name}`, 'settings', currentUser.name);
    }
    setIsAuthenticated(false);
    setCurrentUser(null);
  };

  const addActivity = (
    title: string,
    type: 'enquiry' | 'menu' | 'banquet' | 'media' | 'settings' | 'review',
    actor = currentUser?.name || 'Admin',
    details?: string
  ) => {
    const newAct: AdminActivityItem = {
      id: `act-${Date.now()}`,
      title,
      type,
      timestamp: 'Just now',
      actor,
      details
    };
    setActivities((prev) => [newAct, ...prev.slice(0, 40)]);
  };

  // Real connected stats (strictly connected to existing data)
  const todayEnquiriesCount = enquiries.filter((e) =>
    e.createdAt.toLowerCase().includes('today')
  ).length;

  const banquetEnquiriesCount = enquiries.filter((e) => e.type === 'banquet').length;
  const totalMenuItemsCount = menuItems.length;
  const reviewsCount = reviews.filter((r) => r.isPublished !== false).length;
  const galleryImagesCount = galleryItems.length;

  // Connected visitor count from stored sessions
  const [visitorCount] = useState<number>(() => {
    const stored = loadStored<number>('visitor_count', 428);
    const updated = stored + 1;
    saveStored('visitor_count', updated);
    return updated;
  });

  const stats = {
    todayEnquiriesCount,
    totalMenuItemsCount,
    banquetEnquiriesCount,
    reviewsCount,
    galleryImagesCount,
    visitorCount
  };

  // ==========================================
  // Restaurant Menu Actions
  // ==========================================
  const addMenuItem = (item: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = {
      ...item,
      id: `item-${Date.now()}`
    };
    setMenuItems((prev) => [newItem, ...prev]);
    addActivity(`Added new dish: ${newItem.name}`, 'menu', undefined, `Price: ₹${newItem.price}`);
  };

  const updateMenuItem = (id: string, updates: Partial<MenuItem>) => {
    setMenuItems((prev) =>
      prev.map((it) => (it.id === id ? { ...it, ...updates } : it))
    );
    addActivity(`Updated menu dish`, 'menu', undefined, `ID: ${id}`);
  };

  const duplicateMenuItem = (id: string) => {
    const target = menuItems.find((m) => m.id === id);
    if (!target) return;
    const duplicated: MenuItem = {
      ...target,
      id: `item-${Date.now()}`,
      name: `${target.name} (Copy)`
    };
    setMenuItems((prev) => [duplicated, ...prev]);
    addActivity(`Duplicated dish: ${target.name}`, 'menu');
  };

  const deleteMenuItem = (id: string) => {
    const target = menuItems.find((m) => m.id === id);
    setMenuItems((prev) => prev.filter((m) => m.id !== id));
    if (target) {
      addActivity(`Deleted dish: ${target.name}`, 'menu');
    }
  };

  const toggleItemAvailability = (id: string) => {
    setMenuItems((prev) =>
      prev.map((it) => {
        if (it.id === id) {
          const nextVal = it.price > 0 ? it.price : it.price; // keep structure
          return { ...it, isSignature: !it.isSignature };
        }
        return it;
      })
    );
  };

  // Categories
  const addCategory = (cat: Omit<MenuCategoryItem, 'id'>) => {
    const newCat: MenuCategoryItem = {
      ...cat,
      id: `cat-${Date.now()}`
    };
    setCategories((prev) => [...prev, newCat]);
    addActivity(`Created category: ${cat.name}`, 'menu');
  };

  const updateCategory = (id: string, updates: Partial<MenuCategoryItem>) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
    addActivity(`Updated category`, 'menu', undefined, `ID: ${id}`);
  };

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  // ==========================================
  // Enquiries Actions
  // ==========================================
  const addEnquiry = (
    enquiry: Omit<EnquiryRecord, 'id' | 'createdAt' | 'status' | 'history'> & {
      id?: string;
      createdAt?: string;
      status?: EnquiryStatus;
      history?: EnquiryHistoryLog[];
      referenceCode?: string;
      source?: 'website_banquet' | 'website_reservation' | 'admin' | 'whatsapp';
      eventType?: string;
    }
  ) => {
    const timestamp =
      enquiry.createdAt ||
      new Date().toLocaleString('en-IN', {
        timeZone: 'Asia/Kolkata',
        dateStyle: 'medium',
        timeStyle: 'short'
      });

    const newEnq: EnquiryRecord = {
      ...enquiry,
      id: enquiry.id || `enq-${Date.now()}`,
      status: enquiry.status || 'new',
      createdAt: timestamp,
      history: enquiry.history || [
        {
          id: `log-${Date.now()}`,
          timestamp: timestamp,
          action: 'Enquiry Received',
          note:
            enquiry.source === 'website_banquet'
              ? `Submitted via Website Banquet Planner (Ref: ${enquiry.referenceCode || 'HSM-BNQ'})`
              : enquiry.source === 'website_reservation'
              ? `Submitted via Website Table Reservation (Ref: ${enquiry.referenceCode || 'HSM-RES'})`
              : 'Submitted through website customer portal',
          staffName: 'System'
        }
      ]
    };

    setEnquiries((prev) => {
      const filtered = prev.filter(
        (e) =>
          e.id !== newEnq.id &&
          (!newEnq.referenceCode || e.referenceCode !== newEnq.referenceCode)
      );
      const updated = [newEnq, ...filtered];
      saveStored('enquiries', updated);
      return updated;
    });

    addActivity(
      `New ${newEnq.type} enquiry from ${newEnq.customerName}`,
      'enquiry',
      'System',
      newEnq.requirements
    );

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('sai_maya_inquiry_submitted'));
    }
  };

  const deleteEnquiry = (id: string) => {
    setEnquiries((prev) => {
      const target = prev.find((e) => e.id === id);
      const updated = prev.filter((e) => e.id !== id);
      saveStored('enquiries', updated);
      if (target) {
        addActivity(
          `Deleted enquiry: ${target.customerName}`,
          'enquiry',
          currentUser?.name || 'Staff'
        );
      }
      return updated;
    });
  };

  const syncSubmittedInquiries = () => {
    setEnquiries((prev) => {
      const synced = syncSubmittedCustomerEnquiries(prev);
      saveStored('enquiries', synced);
      return synced;
    });
  };

  const updateEnquiryStatus = (id: string, status: EnquiryStatus, note?: string) => {
    setEnquiries((prev) =>
      prev.map((enq) => {
        if (enq.id === id) {
          const newLog = {
            id: `log-${Date.now()}`,
            timestamp: 'Just now',
            action: `Status changed to ${status}`,
            note: note || `Updated status to ${status}`,
            staffName: currentUser?.name || 'Staff'
          };
          return {
            ...enq,
            status,
            history: [newLog, ...enq.history]
          };
        }
        return enq;
      })
    );
    addActivity(`Enquiry status updated to ${status}`, 'enquiry');
  };

  const addEnquiryNote = (id: string, note: string) => {
    setEnquiries((prev) =>
      prev.map((enq) => {
        if (enq.id === id) {
          const newLog = {
            id: `log-${Date.now()}`,
            timestamp: 'Just now',
            action: 'Staff Note Added',
            note,
            staffName: currentUser?.name || 'Staff'
          };
          return {
            ...enq,
            history: [newLog, ...enq.history]
          };
        }
        return enq;
      })
    );
  };

  // ==========================================
  // Banquet Management Actions
  // ==========================================
  const updateHallInfo = (info: Partial<BanquetHallInfo>) => {
    setBanquetHallInfo((prev) => ({ ...prev, ...info }));
    addActivity('Updated Banquet Hall Specifications', 'banquet');
  };

  const toggleFacility = (id: string) => {
    setBanquetFacilities((prev) =>
      prev.map((fac) => (fac.id === id ? { ...fac, isEnabled: !fac.isEnabled } : fac))
    );
    addActivity('Updated banquet facility toggles', 'banquet');
  };

  const addPackage = (pkg: Omit<BanquetPackageItem, 'id'>) => {
    const newPkg: BanquetPackageItem = {
      ...pkg,
      id: `pkg-${Date.now()}`
    };
    setBanquetPackages((prev) => [...prev, newPkg]);
    addActivity(`Created package: ${pkg.name}`, 'banquet');
  };

  const updatePackage = (id: string, updates: Partial<BanquetPackageItem>) => {
    setBanquetPackages((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
    addActivity(`Updated banquet package`, 'banquet', undefined, `ID: ${id}`);
  };

  const deletePackage = (id: string) => {
    setBanquetPackages((prev) => prev.filter((p) => p.id !== id));
  };

  const togglePackageActive = (id: string) => {
    setBanquetPackages((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isActive: !p.isActive } : p))
    );
  };

  const addEventType = (evt: Omit<BanquetEventTypeItem, 'id'>) => {
    const newEvt: BanquetEventTypeItem = {
      ...evt,
      id: `evt-${Date.now()}`
    };
    setBanquetEventTypes((prev) => [...prev, newEvt]);
    addActivity(`Added banquet event type: ${evt.name}`, 'banquet');
  };

  const toggleEventTypeActive = (id: string) => {
    setBanquetEventTypes((prev) =>
      prev.map((e) => (e.id === id ? { ...e, isActive: !e.isActive } : e))
    );
  };

  // ==========================================
  // Website Manager Actions
  // ==========================================
  const updateHeroConfig = (cfg: Partial<HomepageHeroConfig>) => {
    setHeroConfig((prev) => ({ ...prev, ...cfg }));
    addActivity('Updated Homepage Hero Stage', 'settings');
  };

  const toggleSectionVisibility = (id: string) => {
    setHomepageSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isVisible: !s.isVisible } : s))
    );
    addActivity('Toggled homepage section visibility', 'settings');
  };

  const moveSection = (id: string, direction: 'up' | 'down') => {
    setHomepageSections((prev) => {
      const idx = prev.findIndex((s) => s.id === id);
      if (idx < 0) return prev;
      const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
      if (targetIdx < 0 || targetIdx >= prev.length) return prev;

      const updated = [...prev];
      const temp = updated[idx];
      updated[idx] = updated[targetIdx];
      updated[targetIdx] = temp;

      return updated.map((item, i) => ({ ...item, order: i + 1 }));
    });
    addActivity(`Reordered homepage sections`, 'settings');
  };

  // ==========================================
  // Business Settings Actions
  // ==========================================
  const updateBusinessSettings = (settings: Partial<BusinessSettings>) => {
    setBusinessSettings((prev) => ({ ...prev, ...settings }));
    addActivity('Updated Business Contact & Information', 'settings');
  };

  const updateLocationSettings = (settings: Partial<LocationSettings>) => {
    setLocationSettings((prev) => ({ ...prev, ...settings }));
    addActivity('Updated Highway Location & GPS Coordinates', 'settings');
  };

  const updateDayHours = (day: string, updates: Partial<DayOperatingHours>) => {
    setBusinessSettings((prev) => ({
      ...prev,
      operatingHours: prev.operatingHours.map((d) =>
        d.day.toLowerCase() === day.toLowerCase() ? { ...d, ...updates } : d
      )
    }));
    addActivity(`Updated operating hours for ${day}`, 'settings');
  };

  const updateWhatsAppConfig = (cfg: Partial<WhatsAppConfig>) => {
    setWhatsappConfig((prev) => ({ ...prev, ...cfg }));
    addActivity('Updated WhatsApp Concierge routing', 'settings');
  };

  const updateSEOSettings = (cfg: Partial<SEOSettings>) => {
    setSeoSettings((prev) => ({ ...prev, ...cfg }));
    addActivity('Updated SEO & Social Sharing Tags', 'settings');
  };

  // ==========================================
  // Media & Gallery Actions
  // ==========================================
  const addGalleryItem = (item: Omit<GalleryMediaItem, 'id' | 'createdAt'>) => {
    const newItem: GalleryMediaItem = {
      ...item,
      id: `gal-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setGalleryItems((prev) => [newItem, ...prev]);
    addActivity(`Added new gallery media: ${newItem.title}`, 'media');
  };

  const toggleGalleryFeatured = (id: string) => {
    setGalleryItems((prev) =>
      prev.map((g) => (g.id === id ? { ...g, isFeatured: !g.isFeatured } : g))
    );
  };

  const updateGalleryItem = (id: string, updates: Partial<GalleryMediaItem>) => {
    setGalleryItems((prev) =>
      prev.map((g) => (g.id === id ? { ...g, ...updates } : g))
    );
    addActivity(`Updated gallery image: ${updates.title || id}`, 'media');
  };

  const deleteGalleryItem = (id: string) => {
    setGalleryItems((prev) => prev.filter((g) => g.id !== id));
    addActivity(`Deleted media item`, 'media');
  };

  // ==========================================
  // Reviews Actions
  // ==========================================
  const toggleReviewPublished = (id: string) => {
    setReviews((prev) =>
      prev.map((r) =>
        r.id === id ? { ...r, isPublished: r.isPublished === false ? true : false } : r
      )
    );
    addActivity('Toggled review publication status', 'review');
  };

  const deleteReview = (id: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== id));
    addActivity('Removed guest review', 'review');
  };

  // ==========================================
  // Staff User Actions
  // ==========================================
  const addStaffUser = (user: Omit<StaffUser, 'id' | 'lastActive'>) => {
    const newUser: StaffUser = {
      ...user,
      id: `usr-${Date.now()}`,
      lastActive: 'Never'
    };
    setStaffUsers((prev) => [...prev, newUser]);
    addActivity(`Added staff member: ${user.name} (${user.role})`, 'settings');
  };

  const updateStaffRole = (id: string, role: StaffRole) => {
    setStaffUsers((prev) =>
      prev.map((u) => (u.id === id ? { ...u, role } : u))
    );
    addActivity(`Updated staff role for ID ${id}`, 'settings');
  };

  const deleteStaffUser = (id: string) => {
    setStaffUsers((prev) => prev.filter((u) => u.id !== id));
  };

  // ==========================================
  // Backup & Reset Actions
  // ==========================================
  const exportBackupData = (): string => {
    const snapshot = {
      exportedAt: new Date().toISOString(),
      businessSettings,
      heroConfig,
      homepageSections,
      menuItems,
      categories,
      banquetHallInfo,
      banquetFacilities,
      banquetPackages,
      banquetEventTypes,
      whatsappConfig,
      seoSettings,
      galleryItems,
      reviews,
      enquiries
    };
    return JSON.stringify(snapshot, null, 2);
  };

  const importBackupData = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.businessSettings) setBusinessSettings(data.businessSettings);
      if (data.heroConfig) setHeroConfig(data.heroConfig);
      if (data.homepageSections) setHomepageSections(data.homepageSections);
      if (data.menuItems) setMenuItems(data.menuItems);
      if (data.categories) setCategories(data.categories);
      if (data.banquetHallInfo) setBanquetHallInfo(data.banquetHallInfo);
      if (data.banquetFacilities) setBanquetFacilities(data.banquetFacilities);
      if (data.banquetPackages) setBanquetPackages(data.banquetPackages);
      if (data.banquetEventTypes) setBanquetEventTypes(data.banquetEventTypes);
      if (data.whatsappConfig) setWhatsappConfig(data.whatsappConfig);
      if (data.seoSettings) setSeoSettings(data.seoSettings);
      if (data.galleryItems) setGalleryItems(data.galleryItems);
      if (data.reviews) setReviews(data.reviews);
      if (data.enquiries) setEnquiries(data.enquiries);
      addActivity('Restored complete system backup from JSON snapshot', 'settings');
      return true;
    } catch {
      return false;
    }
  };

  const resetToDefaultData = () => {
    setMenuItems(MENU_ITEMS);
    setCategories(INITIAL_MENU_CATEGORIES);
    setEnquiries(INITIAL_ENQUIRIES);
    setBanquetFacilities(INITIAL_BANQUET_FACILITIES);
    setBanquetEventTypes(INITIAL_BANQUET_EVENT_TYPES);
    setBanquetPackages(INITIAL_BANQUET_PACKAGES);
    setBanquetHallInfo(INITIAL_BANQUET_HALL_INFO);
    setHeroConfig(INITIAL_HERO_CONFIG);
    setHomepageSections(INITIAL_HOMEPAGE_SECTIONS);
    setBusinessSettings(INITIAL_BUSINESS_SETTINGS);
    setWhatsappConfig(INITIAL_WHATSAPP_CONFIG);
    setSeoSettings(INITIAL_SEO_SETTINGS);
    setStaffUsers(INITIAL_STAFF_USERS);
    setGalleryItems(INITIAL_GALLERY_ITEMS);
    setReviews(VERIFIED_GUEST_REVIEWS.map(r => ({ ...r, isPublished: true })));
    addActivity('Reset all operational data to factory defaults', 'settings');
  };

  return (
    <AdminContext.Provider
      value={{
        isAdminMode,
        setIsAdminMode,
        toggleAdminMode,
        isAuthenticated,
        currentUser,
        login,
        logout,
        activeNav,
        setActiveNav,
        activeSubNav,
        setActiveSubNav,
        stats,
        menuItems,
        categories,
        enquiries,
        banquetFacilities,
        banquetEventTypes,
        banquetPackages,
        banquetHallInfo,
        heroConfig,
        homepageSections,
        businessSettings,
        locationSettings,
        whatsappConfig,
        seoSettings,
        staffUsers,
        activities,
        activityLogs: activities,
        galleryItems,
        reviews,
        addMenuItem,
        updateMenuItem,
        duplicateMenuItem,
        deleteMenuItem,
        toggleItemAvailability,
        addCategory,
        updateCategory,
        deleteCategory,
        addEnquiry,
        updateEnquiryStatus,
        addEnquiryNote,
        deleteEnquiry,
        syncSubmittedInquiries,
        updateHallInfo,
        toggleFacility,
        addPackage,
        updatePackage,
        deletePackage,
        togglePackageActive,
        addEventType,
        toggleEventTypeActive,
        updateHeroConfig,
        toggleSectionVisibility,
        moveSection,
        updateBusinessSettings,
        updateLocationSettings,
        updateDayHours,
        updateWhatsAppConfig,
        updateSEOSettings,
        updateSeoSettings: updateSEOSettings,
        addGalleryItem,
        updateGalleryItem,
        toggleGalleryFeatured,
        deleteGalleryItem,
        toggleReviewPublished,
        deleteReview,
        addStaffUser,
        updateStaffRole,
        deleteStaffUser,
        exportBackupData,
        exportDataJson: exportBackupData,
        importBackupData,
        importDataJson: importBackupData,
        resetToDefaultData,
        resetToDefault: resetToDefaultData
      }}
    >
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = (): AdminContextType => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};
