import {
  MenuCategoryItem,
  EnquiryRecord,
  BanquetFacilityItem,
  BanquetEventTypeItem,
  BanquetPackageItem,
  BanquetHallInfo,
  HomepageHeroConfig,
  HomepageSectionItem,
  BusinessSettings,
  WhatsAppConfig,
  SEOSettings,
  StaffUser,
  AdminActivityItem,
  GalleryMediaItem
} from '../types';
import { RESTAURANT_METADATA } from './restaurantData';

export const INITIAL_MENU_CATEGORIES: MenuCategoryItem[] = [
  {
    id: "cat-thali",
    name: "Royal Thalis & Heritage Maharashtrian",
    slug: "thali",
    description: "Authentic Khandeshi, Puneri, and royal temple recipes served in heritage bell-metal ware.",
    image: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=400&q=80",
    displayOrder: 1,
    isActive: true
  },
  {
    id: "cat-punjabi",
    name: "Slow-Cooked Punjabi & Clay Oven Delicacies",
    slug: "punjabi",
    description: "Charcoal-smoked North Indian gravies, rich cottage cheese, and slow-fermented tandoori breads.",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=400&q=80",
    displayOrder: 2,
    isActive: true
  },
  {
    id: "cat-express",
    name: "Highway Express Starters & Artisanal Beverages",
    slug: "express",
    description: "Instant 5-15 minute pilgrim pick-me-ups, fresh kullad masala tea, and digestion-soothing tonics.",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=400&q=80",
    displayOrder: 3,
    isActive: true
  }
];

export const INITIAL_ENQUIRIES: EnquiryRecord[] = [
  {
    id: "enq-101",
    customerName: "Rahul & Archana Patil",
    mobileNumber: "+91 98231 44520",
    email: "rahul.patil@example.com",
    type: "banquet",
    eventDate: "2026-10-10",
    expectedGuests: "85",
    preferredTime: "Evening / Dinner (6:00 PM – 11:00 PM)",
    requirements: "Grandmother's 75th Birthday Celebration. Pure Satvik Khandeshi Thali feast with stage floral backdrop.",
    status: "new",
    createdAt: "Today, 09:20 AM",
    totalAmountEstimate: 42500,
    history: [
      {
        id: "log-1",
        timestamp: "Today, 09:20 AM",
        action: "Enquiry Received",
        note: "Submitted via Website Banquet Planner",
        staffName: "System"
      }
    ]
  },
  {
    id: "enq-102",
    customerName: "Pooja Sharma",
    mobileNumber: "+91 94220 89112",
    email: "pooja.sharma@example.com",
    type: "takeaway",
    eventDate: "2026-09-16",
    expectedGuests: "12",
    preferredTime: "1:30 PM (Highway Pickup)",
    requirements: "12x Imperial Maharashtrian Thali packed hot for Mumbai–Shirdi pilgrimage coach transit.",
    status: "contacted",
    createdAt: "Today, 08:15 AM",
    totalAmountEstimate: 4740,
    history: [
      {
        id: "log-2",
        timestamp: "Today, 08:15 AM",
        action: "Enquiry Received",
        note: "WhatsApp highway express pre-order",
        staffName: "System"
      },
      {
        id: "log-3",
        timestamp: "Today, 08:45 AM",
        action: "Called Customer",
        note: "Confirmed ETA at Kopargaon bypass around 1:30 PM; packaging ordered.",
        staffName: "Sunil Patil (Manager)"
      }
    ]
  },
  {
    id: "enq-103",
    customerName: "Dr. Amitesh Kothari",
    mobileNumber: "+91 98210 77412",
    email: "dr.kothari@example.com",
    type: "banquet",
    eventDate: "2026-11-14",
    expectedGuests: "120",
    preferredTime: "Full Day Slot",
    requirements: "Pre-wedding Ring Ceremony (Sakharpuda). Strict Jain menu (no root veggies, separate pans).",
    status: "follow-up",
    createdAt: "Yesterday, 04:30 PM",
    totalAmountEstimate: 90000,
    history: [
      {
        id: "log-4",
        timestamp: "Yesterday, 04:30 PM",
        action: "Enquiry Received",
        note: "Direct website inquiry",
        staffName: "System"
      },
      {
        id: "log-5",
        timestamp: "Yesterday, 06:10 PM",
        action: "WhatsApp Quotation Shared",
        note: "Sent Jain banquet catalog; awaiting family hall visit on Sunday.",
        staffName: "Sneha Deshmukh (Banquet Mgr)"
      }
    ]
  },
  {
    id: "enq-104",
    customerName: "Mahesh Deshmukh (Shree Tours)",
    mobileNumber: "+91 97650 33441",
    email: "shreetours.pune@example.com",
    type: "restaurant",
    eventDate: "2026-09-18",
    expectedGuests: "32",
    preferredTime: "12:45 PM",
    requirements: "Pilgrim Luxury Bus halting after Shirdi Darshan. Dedicated cluster table & fast thali service.",
    status: "confirmed",
    createdAt: "2 days ago",
    totalAmountEstimate: 12800,
    history: [
      {
        id: "log-6",
        timestamp: "2 days ago",
        action: "Reserved & Advance Paid",
        note: "Coach bay #2 reserved for bus MH-12-AB-9898.",
        staffName: "Sunil Patil (Manager)"
      }
    ]
  },
  {
    id: "enq-105",
    customerName: "Vikram Shinde",
    mobileNumber: "+91 99221 00329",
    type: "general",
    requirements: "Inquiring about EV charging station status and overnight bus parking policy.",
    status: "completed",
    createdAt: "3 days ago",
    history: [
      {
        id: "log-7",
        timestamp: "3 days ago",
        action: "Clarified on Call",
        note: "Assisted with EV chargers (30kW CCS2) on premises.",
        staffName: "Rajendra Kulkarni"
      }
    ]
  }
];

export const INITIAL_BANQUET_FACILITIES: BanquetFacilityItem[] = [
  { id: "fac-ac", name: "Air Conditioning", isEnabled: true, iconName: "Wind", description: "Centralized climate control throughout main hall" },
  { id: "fac-parking", name: "Parking", isEnabled: true, iconName: "Car", description: "80+ private cars & 4 designated Volvo coach bays" },
  { id: "fac-stage", name: "Stage", isEnabled: true, iconName: "Layers", description: "Carpeted ceremonial elevated stage with warm lighting" },
  { id: "fac-sound", name: "Sound System", isEnabled: false, iconName: "Volume2", description: "High-clarity A/V sound system, podium & wireless mic (TBC)" },
  { id: "fac-decor", name: "Decoration", isEnabled: true, iconName: "Sparkles", description: "Auspicious brass urlis, marigold garlands & ambient backdrops" },
  { id: "fac-catering", name: "Catering", isEnabled: true, iconName: "Utensils", description: "100% Satvik Pure Veg, Jain, & Royal Maharashtrian Live Feasts" },
  { id: "fac-wifi", name: "Wi-Fi", isEnabled: true, iconName: "Wifi", description: "High-speed optical fiber for live streaming & guests" },
  { id: "fac-projector", name: "Projector", isEnabled: false, iconName: "Tv", description: "Ceiling-mounted 4K projector & retractable screen (TBC)" },
  { id: "fac-dining", name: "Dining", isEnabled: true, iconName: "Coffee", description: "Dedicated banquet buffet enclosure separated from ceremony area" }
];

export const INITIAL_BANQUET_EVENT_TYPES: BanquetEventTypeItem[] = [
  { id: "evt-bday", name: "Birthday Celebrations", description: "Vibrant and intimate family birthday milestones with customized cake cutting and dessert bar.", isActive: true },
  { id: "evt-eng", name: "Engagement & Ring Ceremony", description: "Auspicious Sakharpuda and ring exchanges surrounded by sacred traditional aesthetics.", isActive: true },
  { id: "evt-wed", name: "Wedding Functions & Pre-Wedding", description: "Haldi, Sangeet, Mehendi and intimate marriage feasts crafted with divine warmth.", isActive: true },
  { id: "evt-fam", name: "Family Get-Togethers & Jubilees", description: "Reunion feasts for traveling joint families post-Shirdi Samadhi Mandir darshan.", isActive: true },
  { id: "evt-corp", name: "Corporate Meetings & Executive Retreats", description: "Calm spiritual retreats, strategy roundtables, and executive luncheon banquets.", isActive: true },
  { id: "evt-puja", name: "Auspicious Pujas & Satsangs", description: "Spiritual gatherings, Sai Baba bhajan mandalis, and satvik paat prasad offerings.", isActive: true }
];

export const INITIAL_BANQUET_PACKAGES: BanquetPackageItem[] = [
  {
    id: "pkg-silver",
    name: "Silver Celebration Package",
    pricePerGuest: 450,
    guestCapacity: "40 – 100 Guests",
    tagline: "Ideal for birthdays, baby showers, and family get-togethers.",
    includes: [
      "Banquet hall rental for 4 hours",
      "Welcome Badam Thandai or Sol Kadhi",
      "Buffet: 2 Premium Sabzis, Dal Tadka, Jeera Rice, Tandoori Breads",
      "1 Festive Indian Dessert (Gulab Jamun / Shrikhand)",
      "Standard banquet chair arrangement & table linen"
    ],
    isActive: true
  },
  {
    id: "pkg-gold",
    name: "Royal Shubh Muhurat Package",
    pricePerGuest: 750,
    guestCapacity: "75 – 250 Guests",
    tagline: "Designed for engagements, golden anniversaries, and sacred pujas.",
    includes: [
      "Full session hall access (6 hours)",
      "Imperial Maharashtrian or Jain Satvik Live Feast (3 Sabzis, Pulao, Varan-Bhaat)",
      "2 Royal Sweets (Basundi & Moong Dal Halwa)",
      "Floral entrance toran & ceremonial stage backdrop",
      "Dedicated Event Coordinator & prioritized valet coach parking",
      "Bridal / Family preparation private green room"
    ],
    isActive: true
  },
  {
    id: "pkg-platinum",
    name: "Platinum Grand Imperial Gala",
    pricePerGuest: 1150,
    guestCapacity: "100 – 300 Guests",
    tagline: "The pinnacle of luxury hospitality for monumental celebrations, wedding receptions, and royal family milestones.",
    includes: [
      "Full Day AC Hall Access (Up to 10 Hours)",
      "Welcome Drink Bar (3 Coolers & Signature Mocktails)",
      "4 Live-Counter Starters (Tandoori Paneer Tikka, Crispy Corn, Hara Bhara Kebab, Kothimbir Vadi)",
      "Royal 5-Course Multi-Cuisine Feast with Live Jowar Bhakri & Gir Cow Ghee Station",
      "3 Artisanal Sweets + Live Hot Jalebi & Rabdi Station",
      "Designer Stage Floral Décor & Ambient Architectural LED Uplighting",
      "High-Fidelity Sound System with Sound Engineer & Wireless Mics",
      "2 Air-Conditioned VIP Preparation Suites (Green Rooms)",
      "Dedicated Valet Parking Fleet Escort & Priority Bay Allocation",
      "High-Speed Wi-Fi for Virtual Ceremony Live Streaming"
    ],
    isActive: true
  },
  {
    id: "pkg-pilgrim",
    name: "Pilgrim Satsang & Thali Gathering",
    pricePerGuest: 380,
    guestCapacity: "30 – 150 Guests",
    tagline: "Customized for bus tour groups and darshan yatris.",
    includes: [
      "Flexible timing synchronized with Shirdi Aarti schedule",
      "Unlimited Sai Maya Heritage Thali buffet with Gir cow ghee",
      "Chilled mineral water & kullad masala chai on arrival",
      "Dedicated express dining area with fast service",
      "Free driver meal & dedicated coach parking bay"
    ],
    isActive: true
  }
];

export const INITIAL_BANQUET_HALL_INFO: BanquetHallInfo = {
  name: "Sanctuary Celebration Hall & Banquet",
  description: "A prestigious, serene, climate-controlled indoor venue situated right along the Shirdi–Kopargaon highway corridor. Designed to host auspicious celebrations, sacred rites, and unforgettable family feasts with flawless satvik hospitality.",
  minCapacity: "40",
  maxCapacity: "250",
  seatingArrangements: "Round table clusters (up to 160 pax), ceremonial theater rows (up to 250 pax), or traditional wooden paat dining arrangements.",
  facilitiesNote: "Note: Capacities, stage dimensions, and A/V sound systems are confirmed per customized floor plan upon consultation.",
  contactCTA: "Schedule a Hall Walkthrough or Check Date"
};

export const INITIAL_HERO_CONFIG: HomepageHeroConfig = {
  title: "Pure Vegetarian Taste for Every Journey",
  subtitle: "A serene culinary sanctuary on State Highway 10. Relish slow-crafted royal Maharashtrian thalis, charcoal-fired Punjabi delicacies, and pure satvik dining just 7 minutes from Shirdi Samadhi Mandir.",
  heroImage: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=1600&q=85",
  primaryCtaText: "Explore Sensory Menu",
  secondaryCtaText: "Get Highway Directions"
};

export const INITIAL_HOMEPAGE_SECTIONS: HomepageSectionItem[] = [
  { id: "sec-hero", name: "Hero Stage", description: "Top greeting banner with instant CTA buttons and highway badges", isVisible: true, order: 1 },
  { id: "sec-philosophy", name: "Sanctuary Ethos & Heritage", description: "Culinary philosophy, purity vows, and bell-metal traditions", isVisible: true, order: 2 },
  { id: "sec-menu", name: "The Sensory Menu", description: "Interactive thalis, express starters, aroma profiles, and WhatsApp cart", isVisible: true, order: 3 },
  { id: "sec-banquet", name: "Banquet Hall & Events", description: "Event stages, upcoming calendar availability, and inquiry form", isVisible: true, order: 4 },
  { id: "sec-transit", name: "VIP Transit & Why Sai Maya", description: "15-minute express dining, EV charging, clean washrooms, Aarti synchronizer", isVisible: true, order: 5 },
  { id: "sec-instagram", name: "Visual Social Chronicle", description: "Instagram highlights and story lightbox", isVisible: true, order: 6 },
  { id: "sec-reviews", name: "Verified Pilgrim Chronicles", description: "Guest reviews carousel with touch swipe and 4.8★ index", isVisible: true, order: 7 },
  { id: "sec-location", name: "Highway Hub & Geo-Navigation", description: "Interactive map, route proximity, and highway ingress guides", isVisible: true, order: 8 }
];

export const INITIAL_BUSINESS_SETTINGS: BusinessSettings = {
  businessName: RESTAURANT_METADATA.name,
  category: "Pure Vegetarian Restaurant & Banquet Hall",
  phone: RESTAURANT_METADATA.phone,
  whatsappNumber: RESTAURANT_METADATA.whatsappNumber,
  email: "contact@hotelsaimaya.com",
  address: RESTAURANT_METADATA.address,
  googleMapsEmbedUrl: RESTAURANT_METADATA.googleMapsEmbedUrl,
  googleMapsDirectionsUrl: RESTAURANT_METADATA.googleMapsDirectionsUrl,
  instagramHandle: RESTAURANT_METADATA.instagramHandle,
  instagramFollowers: RESTAURANT_METADATA.instagramFollowers,
  openingHoursSummary: RESTAURANT_METADATA.openingHours,
  operatingHours: [
    { day: "Monday", isOpen: true, openTime: "06:00 AM", closeTime: "11:30 PM" },
    { day: "Tuesday", isOpen: true, openTime: "06:00 AM", closeTime: "11:30 PM" },
    { day: "Wednesday", isOpen: true, openTime: "06:00 AM", closeTime: "11:30 PM" },
    { day: "Thursday", isOpen: true, openTime: "06:00 AM", closeTime: "11:30 PM" },
    { day: "Friday", isOpen: true, openTime: "06:00 AM", closeTime: "11:30 PM" },
    { day: "Saturday", isOpen: true, openTime: "06:00 AM", closeTime: "11:30 PM" },
    { day: "Sunday", isOpen: true, openTime: "06:00 AM", closeTime: "11:30 PM" }
  ]
};

export const INITIAL_WHATSAPP_CONFIG: WhatsAppConfig = {
  whatsappNumber: RESTAURANT_METADATA.whatsappNumber,
  enableRestaurant: true,
  enableTakeaway: true,
  enableBanquet: true,
  enableGeneral: true,
  restaurantTemplate: "Namaskar Hotel Sai Maya! I am en route to Shirdi via MH SH 10 and would like assistance with highway table reservation.",
  takeawayTemplate: "Namaskar Hotel Sai Maya! I would like to place an advance highway express takeaway order for my travel party.",
  banquetTemplate: "Namaskar Hotel Sai Maya! I would like to enquire about banquet hall booking and pure vegetarian catering packages.",
  generalTemplate: "Namaskar Hotel Sai Maya! I have an inquiry regarding highway parking and temple transit."
};

export const INITIAL_SEO_SETTINGS: SEOSettings = {
  title: "Hotel Sai Maya (New / Veg) | Pure Veg Restaurant & Banquet on Shirdi Highway",
  metaDescription: "Experience authentic royal Maharashtrian thalis, Jain food, and luxury banquet facilities on MH SH 10 (Shirdi–Kopargaon). 7 mins from Sai Baba Temple.",
  focusKeywords: ["Shirdi pure veg restaurant", "Hotel Sai Maya", "Shirdi banquet hall", "Maharashtrian thali highway", "Jain food Shirdi", "Kopargaon highway dining"],
  keywords: ["Shirdi pure veg restaurant", "Hotel Sai Maya", "Shirdi banquet hall", "Maharashtrian thali highway", "Jain food Shirdi", "Kopargaon highway dining"],
  ogImage: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=1200&q=80",
  socialTitle: "Hotel Sai Maya (New / Veg) — Luxury Transient Dining & Banquet",
  socialDescription: "Pure vegetarian culinary sanctuary and banquet hall on MH SH 10, Shirdi.",
  canonicalUrl: "https://hotelsaimaya.com",
  enableSitemap: true,
  enableRobots: true
};

export const INITIAL_LOCATION_SETTINGS = {
  address: "Hotel Sai Maya (New / Veg), MH SH 10, Shirdi–Kopargaon Highway Corridor, Ahmednagar District, Maharashtra 423109",
  corridor: "MH SH 10 (Shirdi–Kopargaon Highway Corridor)",
  coordinates: {
    lat: 19.7695,
    lng: 74.4762
  },
  googleMapsEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15024.123456789!2d74.4762!3d19.7695!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTnCsDQ2JzEwLjIiTiA3NMKwMjhJzM0LjMiRQ!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin",
  googleMapsDirectionsUrl: "https://maps.google.com/?q=Hotel+Sai+Maya+New+Veg+Shirdi",
  nearbyLandmarks: [
    { name: "Shree Sai Baba Samadhi Mandir", distance: "4.2 km (7 mins)" },
    { name: "Sainagar Shirdi Railway Station", distance: "3.1 km (5 mins)" },
    { name: "Kopargaon Junction Railway Station", distance: "14 km (18 mins)" },
    { name: "Shirdi International Airport (SAG)", distance: "18 km (25 mins)" },
    { name: "Shani Shingnapur Corridor Ingress", distance: "68 km (75 mins)" }
  ]
};

export const INITIAL_STAFF_USERS: StaffUser[] = [
  {
    id: "usr-1",
    name: "Rajendra Kulkarni",
    email: "admin@hotelsaimaya.com",
    role: "Super Admin",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80",
    lastActive: "Just now",
    status: "active"
  },
  {
    id: "usr-2",
    name: "Sunil Patil",
    email: "manager@hotelsaimaya.com",
    role: "Manager",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
    lastActive: "15 mins ago",
    status: "active"
  },
  {
    id: "usr-3",
    name: "Sneha Deshmukh",
    email: "banquet@hotelsaimaya.com",
    role: "Banquet Manager",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80",
    lastActive: "1 hour ago",
    status: "active"
  },
  {
    id: "usr-4",
    name: "Devendra Joshi",
    email: "kitchen@hotelsaimaya.com",
    role: "Restaurant Staff",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80",
    lastActive: "3 hours ago",
    status: "active"
  },
  {
    id: "usr-5",
    name: "Priyanka More",
    email: "media@hotelsaimaya.com",
    role: "Content Manager",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80",
    lastActive: "Yesterday",
    status: "active"
  }
];

export const INITIAL_ACTIVITIES: AdminActivityItem[] = [
  {
    id: "act-1",
    title: "New banquet enquiry from Rahul Patil",
    type: "banquet",
    timestamp: "10 minutes ago",
    actor: "Website Guest Form",
    details: "85 Guests • Birthday Celebration • 10 Oct 2026"
  },
  {
    id: "act-2",
    title: "New WhatsApp highway enquiry",
    type: "enquiry",
    timestamp: "45 minutes ago",
    actor: "Pooja Sharma",
    details: "12 Thalis takeaway for pilgrimage coach"
  },
  {
    id: "act-3",
    title: "Menu Item Updated",
    type: "menu",
    timestamp: "2 hours ago",
    actor: "Sunil Patil (Manager)",
    details: "Adjusted price for Khandeshi Shev Bhaji"
  },
  {
    id: "act-4",
    title: "New Gallery Image Added",
    type: "media",
    timestamp: "Yesterday",
    actor: "Priyanka More (Content Mgr)",
    details: "Sanctuary celebration hall evening chandelier lighting"
  },
  {
    id: "act-5",
    title: "Business Contact Information Updated",
    type: "settings",
    timestamp: "2 days ago",
    actor: "Rajendra Kulkarni (Super Admin)",
    details: "Verified WhatsApp routing for highway concierge"
  }
];

export const INITIAL_GALLERY_ITEMS: GalleryMediaItem[] = [
  {
    id: "gal-1",
    title: "Sanctuary Celebration Hall",
    category: "banquet",
    subCategory: "hall",
    image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1000&q=85",
    caption: "Grand pillar-free hall with ambient warm chandeliers.",
    isFeatured: true,
    isPublished: true,
    createdAt: "2026-08-10"
  },
  {
    id: "gal-2",
    title: "Flexible Banquet Seating",
    category: "banquet",
    subCategory: "seating",
    image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1000&q=85",
    caption: "Elegantly arranged round-table seating for festive family meals.",
    isFeatured: true,
    isPublished: true,
    createdAt: "2026-08-12"
  },
  {
    id: "gal-3",
    title: "100% Satvik Feast & Buffet",
    category: "banquet",
    subCategory: "dining",
    image: "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=1000&q=85",
    caption: "Hygienic buffet line serving hot Maharashtrian delicacies.",
    isFeatured: true,
    isPublished: true,
    createdAt: "2026-08-15"
  },
  {
    id: "gal-4",
    title: "Auspicious Floral & Ambient Décor",
    category: "banquet",
    subCategory: "decorations",
    image: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1000&q=85",
    caption: "Marigold, jasmine, and traditional brass urlis.",
    isFeatured: false,
    isPublished: true,
    createdAt: "2026-08-20"
  },
  {
    id: "gal-5",
    title: "Hotel Sai Maya Main Dining Sanctuary",
    category: "restaurant",
    subCategory: "dining",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1000&q=85",
    caption: "High ceilings, natural air flow, and serene highway dining atmosphere.",
    isFeatured: true,
    isPublished: true,
    createdAt: "2026-08-25"
  },
  {
    id: "gal-6",
    title: "Sai Maya Imperial Maharashtrian Thali",
    category: "restaurant",
    subCategory: "food",
    image: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=1000&q=85",
    caption: "Heritage bell-metal dinnerware filled with Khandeshi specialties.",
    isFeatured: true,
    isPublished: true,
    createdAt: "2026-08-28"
  }
];
