import { MenuItem, InstagramStoryItem, TransitAmenity, RouteProximity, BanquetGalleryStage, BanquetInquiryFormData, BanquetCalendarDate, GuestReview } from '../types';

export const RESTAURANT_METADATA = {
  name: "Hotel Sai Maya (New / Veg)",
  tagline: "Luxury Transient Dining & Pilgrim Sanctuary",
  subTagline: "A refined culinary pause on your pilgrimage along the Shirdi–Kopargaon corridor.",
  address: "MH State Highway 10 (Shirdi–Kopargaon Expressway), Dist. Ahmednagar, Maharashtra 423109",
  phone: "+91 98220 54321",
  whatsappNumber: "919822054321",
  instagramHandle: "@hotel_sai_maya_new",
  instagramFollowers: "24.8K",
  rating: "4.8",
  reviewCount: "1,940+",
  openingHours: "06:00 AM – 11:30 PM (Continuous Highway Service)",
  googleMapsEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3752.923832819875!2d74.4756!3d19.7719!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdc599182390f05%3A0x19a00ec1fba3efb8!2sShirdi%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin",
  googleMapsDirectionsUrl: "https://maps.google.com/?q=Hotel+Sai+Maya+New+Veg+Shirdi+Kopargaon+Highway",
};

export const MENU_ITEMS: MenuItem[] = [
  // 1. Royal Thalis & Heritage Maharashtrian
  {
    id: "thali-01",
    name: "Sai Maya Imperial Maharashtrian Thali",
    category: "thali",
    categoryLabel: "Royal Thalis & Heritage Maharashtrian",
    price: 395,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: true,
    aromaProfile: "Woodfire-roasted Goda masala, pure Gir cow ghee, roasted sesame & wild kokum nectar.",
    story: "Served in heavy heritage kansa (bell metal) dinnerware. Features authentic Khandeshi Shev Bhaji, Matki Usal, Pitla Bhakri, Bharli Vangi, Indrayani scented rice with Varan-Tup, warm Jowar Bhakri, Sol Kadhi, hand-churned Shrikhand and Mirchi Thecha.",
    cookingTimeMinutes: 12,
    image: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Medium"
  },
  {
    id: "thali-02",
    name: "Slow-Cooked Khandeshi Shev Bhaji",
    category: "thali",
    categoryLabel: "Royal Thalis & Heritage Maharashtrian",
    price: 260,
    isPureVeg: true,
    isJainAvailable: false,
    isSignature: true,
    aromaProfile: "Black stone-flower (Dagad Phool), dry coconut, wood-charred onions & cold-pressed groundnut oil.",
    story: "The revered soul food of the northern Maharashtra highway. Spicy stone-ground black gravy simmered for 4 hours, crowned with thick artisan Ratlami chickpea crisps that soften into velvet.",
    cookingTimeMinutes: 10,
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Khandeshi Bold"
  },
  {
    id: "thali-03",
    name: "Gavran Bharli Vangi with Fresh Jowar Bhakri",
    category: "thali",
    categoryLabel: "Royal Thalis & Heritage Maharashtrian",
    price: 280,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Roasted peanut meal, toasted white sesame, jaggery hint and aromatic Malvani-Khandeshi spices.",
    story: "Farm-fresh baby purple brinjals stuffed generously with roasted ground peanuts, crushed spices, and fresh coriander, served beside two wood-fired puffed jowar flatbreads.",
    cookingTimeMinutes: 14,
    image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Medium"
  },
  {
    id: "thali-04",
    name: "Zunka Bhakar & Kolhapuri Kharda Thecha Platter",
    category: "thali",
    categoryLabel: "Royal Thalis & Heritage Maharashtrian",
    price: 240,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Tempered mustard seeds, roasted chickpea flour, garlic cloves and fresh curry leaves.",
    story: "Coarsely hand-pounded green chili garlic thecha accompanied by hot, crumbly dry-roasted gram flour zunka and a generous dollop of hand-churned cultured white butter (Loni).",
    cookingTimeMinutes: 8,
    image: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Khandeshi Bold"
  },
  {
    id: "thali-05",
    name: "Satvik Indrayani Khichdi with Gir Cow Ghee",
    category: "thali",
    categoryLabel: "Royal Thalis & Heritage Maharashtrian",
    price: 230,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Sweet fragrant Indrayani rice, yellow moong lentils, whole cumin and golden A2 desi ghee.",
    story: "Prepared specifically for fasting pilgrims and travelers seeking pure Satvik nourishment. Light on the palate, soothing for the soul after prolonged highway drive.",
    cookingTimeMinutes: 9,
    image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Mild"
  },

  // 2. Slow-Fire Punjabi Gravies & Clay Oven Tandoor
  {
    id: "punjabi-01",
    name: "Kasturi Paneer Lababdar",
    category: "punjabi",
    categoryLabel: "Slow-Fire Punjabi Gravies & Clay Oven Tandoor",
    price: 340,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: true,
    aromaProfile: "Sun-dried Himalayan kasuri methi, makhana paste, cardamom pod and silky tomato glaze.",
    story: "Soft cubes of fresh artisanal malai paneer bathed in a rich, slow-simmered onion-tomato-cashew velouté, finished with grated cottage cheese and house-churned cream.",
    cookingTimeMinutes: 14,
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Medium"
  },
  {
    id: "punjabi-02",
    name: "Purani Dilli Dal Bukhara Style (18-Hour Slow Fire)",
    category: "punjabi",
    categoryLabel: "Slow-Fire Punjabi Gravies & Clay Oven Tandoor",
    price: 310,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: true,
    aromaProfile: "Smoky charcoal tandoor embers, slow-simmered whole urad, fresh cream and vine tomatoes.",
    story: "Simmered continuously overnight over glowing charcoal coals. Lusciously velvety texture without artificial thickeners, finished with a generous dollop of white butter.",
    cookingTimeMinutes: 6,
    image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Mild"
  },
  {
    id: "punjabi-03",
    name: "Angara Paneer Tikka from the Clay Oven",
    category: "punjabi",
    categoryLabel: "Slow-Fire Punjabi Gravies & Clay Oven Tandoor",
    price: 330,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Kashmiri deghi mirch, smoked mustard oil, hung yogurt and ground roasted cumin.",
    story: "Thick hand-cut cottage cheese steaks skewered with bell peppers and baby onions, charred to caramelized perfection inside our intense clay oven.",
    cookingTimeMinutes: 12,
    image: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Medium"
  },
  {
    id: "punjabi-04",
    name: "Amritsari Chur-Chur Naan with Pindi Chole",
    category: "punjabi",
    categoryLabel: "Slow-Fire Punjabi Gravies & Clay Oven Tandoor",
    price: 290,
    isPureVeg: true,
    isJainAvailable: false,
    isSignature: true,
    aromaProfile: "Ajwain seeds, layered pure ghee flakes, dry anardana (pomegranate seed) and black tea broth.",
    story: "Flaky, multi-layered tandoori bread crushed by hand with pure desi ghee, paired with dark, tangy chickpeas simmered with whole cinnamon, black cardamom, and dried gooseberry.",
    cookingTimeMinutes: 11,
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Medium"
  },
  {
    id: "punjabi-05",
    name: "Awadhi Subz Dum Biryani Handi",
    category: "punjabi",
    categoryLabel: "Slow-Fire Punjabi Gravies & Clay Oven Tandoor",
    price: 340,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Kashmir saffron strands, rose water, star anise, mint leaves and aged basmati.",
    story: "Prepared in traditional earthenware handis sealed with dough. Slow steamed so vegetable juices infuse every long grain of vintage aged basmati rice.",
    cookingTimeMinutes: 15,
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Mild"
  },

  // 3. Highway Express Starters & Artisanal Beverages
  {
    id: "express-01",
    name: "Express Transit Kothimbir Vadi (Ready in 6 Mins)",
    category: "express",
    categoryLabel: "Highway Express Starters & Artisanal Beverages",
    price: 190,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: true,
    aromaProfile: "Fresh winter coriander, roasted white sesame seeds, ginger extract and nutty gram flour.",
    story: "Steamed savory coriander-flour diamond cakes, crisped in cold-pressed peanut oil until golden. Designed specifically for travelers in transit needing rapid, hot nourishment.",
    cookingTimeMinutes: 6,
    image: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Medium"
  },
  {
    id: "express-02",
    name: "Royal Kesariya Badam Thandai (Cold-Pressed)",
    category: "express",
    categoryLabel: "Highway Express Starters & Artisanal Beverages",
    price: 180,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: true,
    aromaProfile: "Stone-ground Mamra almonds, royal saffron filaments, poppy seeds, fennel and green cardamom.",
    story: "A regal cooling tonic prepared according to ancient temple texts. Relieves highway driver fatigue and provides instant rejuvenation under the Deccan sun.",
    cookingTimeMinutes: 3,
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Mild"
  },
  {
    id: "express-03",
    name: "Artisanal Sol Kadhi with Wild Kokum",
    category: "express",
    categoryLabel: "Highway Express Starters & Artisanal Beverages",
    price: 140,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Fresh thick coconut milk, tart wild Malabar kokum, pink rock salt and crushed cumin.",
    story: "Pink digestive elixir made with freshly grated coconut extract and pure sun-dried kokum. Celebrated across the Konkan and Khandesh for soothing digestion.",
    cookingTimeMinutes: 2,
    image: "https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Mild"
  },
  {
    id: "express-04",
    name: "Clay Kullad Masala Chai & Highway Bun Maska",
    category: "express",
    categoryLabel: "Highway Express Starters & Artisanal Beverages",
    price: 120,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Crushed fresh ginger root, green cardamom, cloves, and warm sweet baked bread.",
    story: "Steaming spiced tea brewed in slow milk reduction served in porous earthen cups with soft warm pav lathered in salty Amul churned butter.",
    cookingTimeMinutes: 4,
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Mild"
  },
  {
    id: "express-05",
    name: "Crispy Farm Corn & Roasted Pepper Toss",
    category: "express",
    categoryLabel: "Highway Express Starters & Artisanal Beverages",
    price: 240,
    isPureVeg: true,
    isJainAvailable: true,
    isSignature: false,
    aromaProfile: "Cracked telicherry pepper, charred sweetcorn, lime zest and curry oil.",
    story: "Crisp sweetcorn kernels flash-fried and tossed with crackling green chilies, bell peppers, chaat spices, and fresh mint leaves.",
    cookingTimeMinutes: 8,
    image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=1000&q=85",
    spiciness: "Medium"
  }
];

export const INSTAGRAM_STORIES: InstagramStoryItem[] = [
  {
    id: "story-01",
    title: "Dawn Harvest: 6:00 AM Farm Ingress",
    timestamp: "2h ago",
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80",
    likes: "1.4k",
    comments: "84",
    caption: "The foundation of Satvik cuisine begins at daybreak. Fresh seasonal greens, handpicked brinjals, and crisp coriander arrive straight from local Godavari riverbank farms.",
    badge: "Purity Ingress"
  },
  {
    id: "story-02",
    title: "Clay Tandoor Roaring: 450°C Woodfire",
    timestamp: "4h ago",
    image: "https://images.unsplash.com/photo-1506354666786-959d6d497f1a?auto=format&fit=crop&w=800&q=80",
    likes: "2.8k",
    comments: "142",
    caption: "No gas shortcuts. Pure natural wood charcoals breathing heat into our handcrafted tandoors. Butter-glazed garlic naans and melt-in-mouth paneer tikka.",
    badge: "Clay Fire"
  },
  {
    id: "story-03",
    title: "Transit Sanctuary: Private Coach Lot",
    timestamp: "6h ago",
    image: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80",
    likes: "972",
    comments: "56",
    caption: "45+ dedicated bays for luxury SUVs, Fortuners, and pilgrimage family coaches. Dedicated security personnel, 24/7 CCTV, and high-speed EV chargers.",
    badge: "VIP Ingress"
  },
  {
    id: "story-04",
    title: "Heritage Kansa Brass Thalis for Pilgrims",
    timestamp: "8h ago",
    image: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=800&q=80",
    likes: "3.2k",
    comments: "210",
    caption: "Dining in kansa alloy balances digestion according to Ayurveda. Every thali is an offering of pure gratitude before or after Shirdi Baba darshan.",
    badge: "Satvik Tradition"
  }
];

export const TRANSIT_AMENITIES: TransitAmenity[] = [
  {
    id: "amenity-01",
    title: "Private Secured Fleet & Coach Parking",
    subtitle: "45+ Dedicated Bays on MH SH 10",
    iconName: "ShieldCheck",
    badge: "24/7 Surveillance",
    description: "Spacious paved parking capable of accommodating luxury SUVs (BMW, Mercedes, Fortuner) and family tour buses with unobstructed entry and exit ramps.",
    features: ["Valet Assistance on request", "60kW Dual EV Fast Chargers", "Dedicated Bus Driver Rest Lounge"]
  },
  {
    id: "amenity-02",
    title: "Sanitized Executive Rest Suites & VIP Restrooms",
    subtitle: "Continuous Housekeeping Protocol",
    iconName: "Sparkles",
    badge: "Pristine Standards",
    description: "Zero-compromise hygiene. Freshly sterilized restrooms with premium touchless fixtures, infant diaper changing stations, and wheelchair accessible stalls.",
    features: ["Hourly Sanitization Records", "Air-conditioned Powder Room", "Fresh Cotton Hand Towels"]
  },
  {
    id: "amenity-03",
    title: "15-Minute 'Rush Darshan' Express Turnaround",
    subtitle: "Synchronized to Temple Aartis",
    iconName: "Clock",
    badge: "Express Priority",
    description: "Traveling on a strict schedule for Kakad, Madhyan or Dhoop Aarti? Our express kitchen pipeline guarantees hot royal thalis and gravies within 15 minutes of ordering.",
    features: ["Highway Pre-Order via WhatsApp", "Takeaway Highway Bento Packs", "Instant Dining Table Allocation"]
  },
  {
    id: "amenity-04",
    title: "Corridor Ingress: Samruddhi & MH SH 10",
    subtitle: "Direct Expressway Flyover Access",
    iconName: "Compass",
    badge: "Prime Arterial Hub",
    description: "Located right on Maharashtra State Highway 10, just moments from the Nagpur-Mumbai Hindu Hrudaysamrat Balasaheb Thackeray Samruddhi Mahamarg interchange.",
    features: ["No Traffic Chokepoints", "Wide 40ft Gated Driveway", "Signposted 500m Advance Markers"]
  }
];

export const ROUTE_PROXIMITIES: RouteProximity[] = [
  {
    landmark: "Shirdi Sai Baba Samadhi Mandir",
    distance: "5.2 km",
    drivingTime: "7 Mins",
    routeHighlight: "Direct arterial signal-free highway drive towards Temple Gate No. 2",
    icon: "Compass"
  },
  {
    landmark: "New Sai Baba Sansthan Prasadalaya",
    distance: "3.4 km",
    drivingTime: "4 Mins",
    routeHighlight: "Straight corridor on MH SH 10; closest luxury transient stop",
    icon: "Utensils"
  },
  {
    landmark: "Kopargaon Railway Station (KPG)",
    distance: "9.8 km",
    drivingTime: "12 Mins",
    routeHighlight: "Convenient bypass avoiding crowded inner-town market traffic",
    icon: "Train"
  },
  {
    landmark: "Samruddhi Expressway Interchange",
    distance: "14 km",
    drivingTime: "15 Mins",
    routeHighlight: "Seamless high-speed connection for Mumbai, Pune & Nagpur travelers",
    icon: "Navigation"
  }
];

/**
 * Pure JavaScript / TypeScript WhatsApp Concierge Generator
 * Formats a clean, high-end encoded message directly to Hotel Sai Maya concierge
 */
export function triggerWhatsAppOrder(itemOrDetails?: {
  itemName?: string;
  price?: number;
  dietary?: string;
  guestName?: string;
  partySize?: number;
  eta?: string;
  cartItems?: { name: string; quantity: number; price: number; dietary: string }[];
  totalAmount?: number;
  vehicleNumber?: string;
  specialRequest?: string;
}) {
  const number = RESTAURANT_METADATA.whatsappNumber;
  let text = "";

  if (itemOrDetails?.cartItems && itemOrDetails.cartItems.length > 0) {
    text = `*HOTEL SAI MAYA (NEW / VEG) — HIGHWAY EXPRESS PRE-ORDER*\n\n` +
      `Namaskar Concierge! I would like to place an advance transient dining order:\n\n` +
      itemOrDetails.cartItems.map((ci, idx) => 
        `${idx + 1}. *${ci.name}* x ${ci.quantity} (₹${ci.price * ci.quantity}) [${ci.dietary}]`
      ).join("\n") +
      `\n\n*Estimated Total:* ₹${itemOrDetails.totalAmount || 0}\n` +
      (itemOrDetails.guestName ? `*Guest Name:* ${itemOrDetails.guestName}\n` : "") +
      (itemOrDetails.partySize ? `*Travel Party:* ${itemOrDetails.partySize} Guests\n` : "") +
      (itemOrDetails.eta ? `*Estimated Arrival (ETA):* ${itemOrDetails.eta}\n` : "") +
      (itemOrDetails.vehicleNumber ? `*Vehicle No:* ${itemOrDetails.vehicleNumber}\n` : "") +
      (itemOrDetails.specialRequest ? `*Note:* ${itemOrDetails.specialRequest}\n` : "") +
      `\nPlease confirm table readiness / packaging status upon our arrival on MH SH 10. Thank you!`;
  } else if (itemOrDetails?.itemName) {
    text = `*HOTEL SAI MAYA (NEW / VEG) — INSTANT DISH INQUIRY*\n\n` +
      `Namaskar! I am currently on the Shirdi Highway corridor and wish to pre-order:\n` +
      `*Dish:* ${itemOrDetails.itemName} (₹${itemOrDetails.price})\n` +
      (itemOrDetails.dietary ? `*Preference:* ${itemOrDetails.dietary}\n` : "") +
      (itemOrDetails.eta ? `*ETA:* ${itemOrDetails.eta}\n` : "") +
      `\nPlease prepare this for our arrival. Thank you!`;
  } else {
    text = `*HOTEL SAI MAYA (NEW / VEG) — HIGHWAY CONCIERGE ASSISTANCE*\n\n` +
      `Namaskar! I am en route to Shirdi via MH SH 10. I would like assistance with:\n` +
      `• Table reservation for our pilgrimage party\n` +
      `• 15-Minute Express Dining timing\n` +
      `• VIP vehicle parking & route ingress\n\n` +
      `Kindly assist us. Thank you!`;
  }

  const encoded = encodeURIComponent(text);
  const whatsappUrl = `https://wa.me/${number}?text=${encoded}`;
  window.open(whatsappUrl, "_blank", "noopener,noreferrer");
}

export function triggerWhatsAppBanquetInquiry(details?: Partial<BanquetInquiryFormData>) {
  const number = RESTAURANT_METADATA.whatsappNumber;
  let text = `*HOTEL SAI MAYA (NEW / VEG) — BANQUET & EVENTS INQUIRY*\n\n` +
    `Namaskar Events Concierge! I would like to inquire regarding booking the banquet hall:\n\n`;

  if (details?.name) text += `*Organizer / Host Name:* ${details.name}\n`;
  if (details?.mobileNumber) text += `*Mobile Number:* ${details.mobileNumber}\n`;
  if (details?.eventType) text += `*Event Type:* ${details.eventType}\n`;
  if (details?.eventDate) text += `*Proposed Date:* ${details.eventDate}\n`;
  if (details?.expectedGuests) text += `*Expected Guests:* ${details.expectedGuests} (Layout to be confirmed)\n`;
  if (details?.preferredTime) text += `*Preferred Time Slot:* ${details.preferredTime}\n`;
  if (details?.additionalRequirements) text += `*Special Requirements / Menu:* ${details.additionalRequirements}\n`;

  text += `\nPlease share hall availability, pure-vegetarian catering packages, and arrange a consultation at your earliest convenience. Thank you!`;

  const encoded = encodeURIComponent(text);
  const whatsappUrl = `https://wa.me/${number}?text=${encoded}`;
  window.open(whatsappUrl, "_blank", "noopener,noreferrer");
}

export const BANQUET_GALLERY_STAGES: BanquetGalleryStage[] = [
  {
    id: "hall",
    label: "Hall",
    title: "Sanctuary Celebration Hall",
    image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=85",
    description: "Spacious, well-ventilated, climate-controlled indoor event space bathed in warm amber chandelier illumination, designed for sacred and joyful family gatherings.",
    statusNote: "Dimensions & exact guest capacity to be confirmed based on setup"
  },
  {
    id: "seating",
    label: "Seating",
    title: "Flexible Banquet Seating",
    image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1200&q=85",
    description: "Versatile layouts including round-table banquet clusters, theater-style ceremonial rows, or traditional floor paat arrangements for auspicious pujas.",
    statusNote: "Seating configuration customized on request (To be confirmed)"
  },
  {
    id: "dining",
    label: "Dining",
    title: "100% Satvik Feast & Buffet",
    image: "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=1200&q=85",
    description: "Dedicated banquet buffet line serving freshly prepared Royal Maharashtrian delicacies, slow-cooked gravies, tandoor flatbreads, and custom no-onion-garlic Jain menus.",
    statusNote: "Special customized per-plate event menus available upon inquiry"
  },
  {
    id: "decoration",
    label: "Decoration",
    title: "Auspicious Floral & Ambient Décor",
    image: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1200&q=85",
    description: "Warm brass urlis with marigold and jasmine accents, elegant stage drapery, warm string lights, and entrance archways tailored to spiritual and joyous milestones.",
    statusNote: "External or in-house decorator arrangements to be confirmed"
  },
  {
    id: "event-setup",
    label: "Event Setup",
    title: "Ceremonial Stage & Milestone Layout",
    image: "https://images.unsplash.com/photo-1527529482837-4698179dc6ce?auto=format&fit=crop&w=1200&q=85",
    description: "Complete stage platform setup with dedicated ceremonial backdrop, spotlighting, gift display tables, and seamless guest circulation corridors.",
    statusNote: "A/V sound system, podium, & mic availability to be confirmed"
  }
];

export interface CalendarMonthData {
  monthName: string;
  year: number;
  monthIndex: number; // 0-based: 9 for Oct, 10 for Nov
  startDayOffset: number; // 0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri, 5=Sat, 6=Sun
  totalDays: number;
  days: BanquetCalendarDate[];
}

export const BANQUET_CALENDAR_DATA: CalendarMonthData[] = [
  {
    monthName: "October",
    year: 2026,
    monthIndex: 9,
    startDayOffset: 3, // Oct 1, 2026 is Thursday (0=Mon, 1=Tue, 2=Wed, 3=Thu)
    totalDays: 31,
    days: [
      { date: "2026-10-01", dayNumber: 1, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open", occasionNote: "Regular Weekday • Lunch & Dinner slots open" },
      { date: "2026-10-02", dayNumber: 2, dayOfWeek: "Fri", status: "peak", label: "Gandhi Jayanti", morningSlot: "fast-filling", eveningSlot: "open", occasionNote: "National Holiday Long Weekend • High Pilgrim Transit" },
      { date: "2026-10-03", dayNumber: 3, dayOfWeek: "Sat", status: "booked", label: "Reserved", morningSlot: "reserved", eveningSlot: "reserved", occasionNote: "Private Family Golden Jubilee Banquet" },
      { date: "2026-10-04", dayNumber: 4, dayOfWeek: "Sun", status: "peak", label: "Sunday Rush", morningSlot: "fast-filling", eveningSlot: "open", occasionNote: "Sunday Post-Kakad Aarti Gathering" },
      { date: "2026-10-05", dayNumber: 5, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-06", dayNumber: 6, dayOfWeek: "Tue", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-07", dayNumber: 7, dayOfWeek: "Wed", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-08", dayNumber: 8, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-09", dayNumber: 9, dayOfWeek: "Fri", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-10", dayNumber: 10, dayOfWeek: "Sat", status: "muhurat", label: "Shubh Muhurat", morningSlot: "open", eveningSlot: "fast-filling", occasionNote: "Auspicious Engagement & Sakharpuda Date" },
      { date: "2026-10-11", dayNumber: 11, dayOfWeek: "Sun", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-12", dayNumber: 12, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-13", dayNumber: 13, dayOfWeek: "Tue", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-14", dayNumber: 14, dayOfWeek: "Wed", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-15", dayNumber: 15, dayOfWeek: "Thu", status: "peak", label: "Navratri Starts", morningSlot: "fast-filling", eveningSlot: "open", occasionNote: "Navratri Ghatasthapana • Pure Satvik Feast Demand" },
      { date: "2026-10-16", dayNumber: 16, dayOfWeek: "Fri", status: "peak", label: "Festive Season", morningSlot: "open", eveningSlot: "fast-filling", occasionNote: "Navratri Pilgrimage Wave" },
      { date: "2026-10-17", dayNumber: 17, dayOfWeek: "Sat", status: "booked", label: "Reserved", morningSlot: "reserved", eveningSlot: "reserved", occasionNote: "Confirmed Pre-Wedding Bhajan & Sangeet Gathering" },
      { date: "2026-10-18", dayNumber: 18, dayOfWeek: "Sun", status: "peak", label: "Peak Transit", morningSlot: "fast-filling", eveningSlot: "open", occasionNote: "Weekend Aarti Pilgrimage Rush" },
      { date: "2026-10-19", dayNumber: 19, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-20", dayNumber: 20, dayOfWeek: "Tue", status: "peak", label: "Dussehra", morningSlot: "fast-filling", eveningSlot: "fast-filling", occasionNote: "Vijayadashami / Sai Baba Punyatithi Festival Corridor" },
      { date: "2026-10-21", dayNumber: 21, dayOfWeek: "Wed", status: "peak", label: "Punyatithi Utsav", morningSlot: "fast-filling", eveningSlot: "fast-filling", occasionNote: "Major Pilgrim Footfall in Shirdi" },
      { date: "2026-10-22", dayNumber: 22, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-23", dayNumber: 23, dayOfWeek: "Fri", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-24", dayNumber: 24, dayOfWeek: "Sat", status: "muhurat", label: "Lagna Muhurat", morningSlot: "open", eveningSlot: "fast-filling", occasionNote: "Auspicious Family Function Window" },
      { date: "2026-10-25", dayNumber: 25, dayOfWeek: "Sun", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-26", dayNumber: 26, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-27", dayNumber: 27, dayOfWeek: "Tue", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-28", dayNumber: 28, dayOfWeek: "Wed", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-29", dayNumber: 29, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-30", dayNumber: 30, dayOfWeek: "Fri", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-10-31", dayNumber: 31, dayOfWeek: "Sat", status: "muhurat", label: "Muhurat Weekend", morningSlot: "fast-filling", eveningSlot: "open", occasionNote: "Pre-Diwali Celebration Slot" }
    ]
  },
  {
    monthName: "November",
    year: 2026,
    monthIndex: 10,
    startDayOffset: 6, // Nov 1, 2026 is Sunday (0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri, 5=Sat, 6=Sun)
    totalDays: 30,
    days: [
      { date: "2026-11-01", dayNumber: 1, dayOfWeek: "Sun", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-02", dayNumber: 2, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-03", dayNumber: 3, dayOfWeek: "Tue", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-04", dayNumber: 4, dayOfWeek: "Wed", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-05", dayNumber: 5, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-06", dayNumber: 6, dayOfWeek: "Fri", status: "peak", label: "Diwali Dhanteras", morningSlot: "fast-filling", eveningSlot: "open", occasionNote: "Diwali Festivities Begin • Fast-filling dinner slots" },
      { date: "2026-11-07", dayNumber: 7, dayOfWeek: "Sat", status: "peak", label: "Diwali Weekend", morningSlot: "fast-filling", eveningSlot: "fast-filling", occasionNote: "High Family Gathering Demand" },
      { date: "2026-11-08", dayNumber: 8, dayOfWeek: "Sun", status: "booked", label: "Reserved", morningSlot: "reserved", eveningSlot: "reserved", occasionNote: "Corporate Executive Year-End Spiritual Retreat" },
      { date: "2026-11-09", dayNumber: 9, dayOfWeek: "Mon", status: "peak", label: "Diwali Padwa", morningSlot: "fast-filling", eveningSlot: "open", occasionNote: "New Year Celebrations & Maharashtrian Feasts" },
      { date: "2026-11-10", dayNumber: 10, dayOfWeek: "Tue", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-11", dayNumber: 11, dayOfWeek: "Wed", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-12", dayNumber: 12, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-13", dayNumber: 13, dayOfWeek: "Fri", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-14", dayNumber: 14, dayOfWeek: "Sat", status: "muhurat", label: "Tulsi Vivah", morningSlot: "open", eveningSlot: "fast-filling", occasionNote: "Wedding Season Inaugural Shubh Muhurat" },
      { date: "2026-11-15", dayNumber: 15, dayOfWeek: "Sun", status: "muhurat", label: "Peak Muhurat", morningSlot: "fast-filling", eveningSlot: "reserved", occasionNote: "Evening Reserved for Ring Ceremony • Lunch Available" },
      { date: "2026-11-16", dayNumber: 16, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-17", dayNumber: 17, dayOfWeek: "Tue", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-18", dayNumber: 18, dayOfWeek: "Wed", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-19", dayNumber: 19, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-20", dayNumber: 20, dayOfWeek: "Fri", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-21", dayNumber: 21, dayOfWeek: "Sat", status: "booked", label: "Reserved", morningSlot: "reserved", eveningSlot: "reserved", occasionNote: "Grand 80th Birthday Celebration" },
      { date: "2026-11-22", dayNumber: 22, dayOfWeek: "Sun", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-23", dayNumber: 23, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-24", dayNumber: 24, dayOfWeek: "Tue", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-25", dayNumber: 25, dayOfWeek: "Wed", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-26", dayNumber: 26, dayOfWeek: "Thu", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-27", dayNumber: 27, dayOfWeek: "Fri", status: "muhurat", label: "Auspicious Date", morningSlot: "open", eveningSlot: "fast-filling" },
      { date: "2026-11-28", dayNumber: 28, dayOfWeek: "Sat", status: "muhurat", label: "Lagna Weekend", morningSlot: "fast-filling", eveningSlot: "fast-filling", occasionNote: "High Demand Wedding Weekend" },
      { date: "2026-11-29", dayNumber: 29, dayOfWeek: "Sun", status: "available", morningSlot: "open", eveningSlot: "open" },
      { date: "2026-11-30", dayNumber: 30, dayOfWeek: "Mon", status: "available", morningSlot: "open", eveningSlot: "open" }
    ]
  }
];

export const VERIFIED_GUEST_REVIEWS: GuestReview[] = [
  {
    id: "rev-01",
    guestName: "Aniket & Shweta Kulkarni",
    location: "Dadar, Mumbai, MH",
    travelContext: "Family Pilgrimage & Grandmother's 75th Birthday",
    rating: 5.0,
    reviewDate: "October 2025",
    reviewText: "We stopped with 42 family members returning from Shirdi Samadhi Mandir. The staff arranged a comfortable banquet seating cluster for all our senior elders. The Imperial Maharashtrian Thali and hot Jowar Bhakri with Gir cow ghee were divine. Truly spotless washrooms!",
    highlightDishOrAmenity: "Imperial Maharashtrian Thali & Family Seating",
    isVerifiedGuest: true,
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80"
  },
  {
    id: "rev-02",
    guestName: "Dr. Ramesh & Manjula Patel",
    location: "Adajan, Surat, GJ",
    travelContext: "Annual Shirdi Yatra • Strict Jain Travellers",
    rating: 5.0,
    reviewDate: "November 2025",
    reviewText: "Finding 100% pure vegetarian cuisine that takes Jain dietary restrictions seriously on the highway is rare. Sai Maya served pure no-onion, no-garlic Paneer Butter Masala and Phulkas prepared in separate cookware with utmost devotion. Outstanding satvik hospitality.",
    highlightDishOrAmenity: "Dedicated Jain Satvik Menu & Pristine Purity",
    isVerifiedGuest: true,
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80"
  },
  {
    id: "rev-03",
    guestName: "Col. Vikramaditya Rao (Retd.)",
    location: "Koregaon Park, Pune, MH",
    travelContext: "Luxury Coach Highway Transit (18 Pax)",
    rating: 4.9,
    reviewDate: "December 2025",
    reviewText: "We arrived in our 20-seater luxury coach at 10:15 PM after temple darshan. Ample dedicated coach parking and courteous security. The Dal Tadka simmered in brass pots with clay oven Garlic Naan was exceptional. Clean, calm, and dignified ambience.",
    highlightDishOrAmenity: "Luxury Coach Parking & Midnight Highway Service",
    isVerifiedGuest: true,
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80"
  },
  {
    id: "rev-04",
    guestName: "Sangeeta & Milind Deshmukh",
    location: "Gangapur Road, Nashik, MH",
    travelContext: "Pre-Wedding Sakharpuda Banquet Consultation",
    rating: 5.0,
    reviewDate: "January 2026",
    reviewText: "We inquired for an intimate family ring ceremony of 60 guests. The banquet team gave us a detailed walkthrough of the hall stages, satvik catering tasting, and parking logistics. Transparent pricing and warm cultural reverence.",
    highlightDishOrAmenity: "Banquet Hall Space & Event Concierge",
    isVerifiedGuest: true,
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80"
  },
  {
    id: "rev-05",
    guestName: "Rajesh Singhania & Family",
    location: "South Tukoganj, Indore, MP",
    travelContext: "Post-Kakad Aarti Highway Breakfast",
    rating: 5.0,
    reviewDate: "February 2026",
    reviewText: "The 15-minute Aarti Synchronizer on their website helped us pace our trip from Indore. We reached Shirdi on schedule for Kakad Aarti, then drove 7 minutes to Sai Maya for early breakfast. Fresh poha, ginger chai, and hot stuffed parathas gave us so much peace.",
    highlightDishOrAmenity: "Aarti Synchronizer & Morning Highway Breakfast",
    isVerifiedGuest: true,
    avatarUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=200&q=80"
  },
  {
    id: "rev-06",
    guestName: "Meera & Harish Sundaram",
    location: "Indiranagar, Bengaluru, KA",
    travelContext: "South Indian Pilgrim Tour to Shirdi & Shani Shingnapur",
    rating: 4.9,
    reviewDate: "March 2026",
    reviewText: "High aesthetic standards rarely seen on highway corridors. The brass urlis, marigold fragrance, soft instrumental devotional music, and genuine warmth of the staff made our journey unforgettable. 100% recommended for every pilgrim.",
    highlightDishOrAmenity: "Sanctuary Ambience & Satvik Purity",
    isVerifiedGuest: true,
    avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80"
  }
];
