export interface MenuItem {
  id: string;
  name: string;
  category: 'thali' | 'punjabi' | 'express';
  categoryLabel: string;
  price: number;
  isPureVeg: boolean;
  isJainAvailable: boolean;
  isSignature: boolean;
  aromaProfile: string;
  story: string;
  cookingTimeMinutes: number;
  image: string;
  spiciness: 'Mild' | 'Medium' | 'Khandeshi Bold';
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
  dietaryPreference: 'Standard Satvik' | 'Strict Jain' | 'Mild Spices' | 'Extra Desi Ghee';
  specialInstructions?: string;
}

export interface InstagramStoryItem {
  id: string;
  title: string;
  timestamp: string;
  image: string;
  likes: string;
  comments: string;
  caption: string;
  badge: string;
}

export interface TransitAmenity {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  badge: string;
  description: string;
  features: string[];
}

export interface RouteProximity {
  landmark: string;
  distance: string;
  drivingTime: string;
  routeHighlight: string;
  icon: string;
}

export type BanquetEventType =
  | 'Birthday Celebrations'
  | 'Engagement & Family Functions'
  | 'Family Get-Togethers'
  | 'Meetings & Small Events'
  | 'Other Occasions';

export interface BanquetInquiryFormData {
  name: string;
  mobileNumber: string;
  eventType: BanquetEventType;
  eventDate: string;
  expectedGuests: string;
  preferredTime: 'Morning / Lunch (10:00 AM – 3:00 PM)' | 'Evening / Dinner (6:00 PM – 11:00 PM)' | 'Full Day Slot' | 'Flexible';
  additionalRequirements: string;
}

export interface SavedBanquetEnquiry extends BanquetInquiryFormData {
  id: string;
  referenceCode: string;
  createdAt: string;
  status: 'Saved & Registered' | 'Under Review' | 'Confirmed';
}

export interface BanquetGalleryStage {
  id: string;
  label: string;
  title: string;
  image: string;
  description: string;
  statusNote: string;
}

export type BanquetDateStatus = 'available' | 'peak' | 'booked' | 'muhurat';

export interface BanquetCalendarDate {
  date: string; // YYYY-MM-DD
  dayNumber: number;
  dayOfWeek: string;
  status: BanquetDateStatus;
  label?: string;
  morningSlot: 'open' | 'reserved' | 'fast-filling';
  eveningSlot: 'open' | 'reserved' | 'fast-filling';
  occasionNote?: string;
}

export interface GuestReview {
  id: string;
  guestName: string;
  location: string;
  travelContext: string;
  rating: number;
  reviewDate: string;
  reviewText: string;
  highlightDishOrAmenity: string;
  isVerifiedGuest: boolean;
  avatarUrl?: string;
  isPublished?: boolean;
}

// ==========================================
// Hotel Sai Maya — Admin Management Types
// ==========================================

export type EnquiryType = 'restaurant' | 'takeaway' | 'banquet' | 'general';
export type EnquiryStatus = 'new' | 'contacted' | 'follow-up' | 'confirmed' | 'completed' | 'cancelled';

export interface EnquiryHistoryLog {
  id: string;
  timestamp: string;
  action: string;
  note?: string;
  staffName: string;
}

export interface EnquiryRecord {
  id: string;
  customerName: string;
  mobileNumber: string;
  email?: string;
  type: EnquiryType;
  eventDate?: string;
  expectedGuests?: string | number;
  preferredTime?: string;
  requirements?: string;
  status: EnquiryStatus;
  createdAt: string;
  totalAmountEstimate?: number;
  history: EnquiryHistoryLog[];
  referenceCode?: string;
  source?: 'website_banquet' | 'website_reservation' | 'admin' | 'whatsapp';
  eventType?: string;
  cateringPreference?: string;
  budget?: string;
}

export interface MenuCategoryItem {
  id: string;
  name: string;
  slug: string;
  description: string;
  image?: string;
  displayOrder: number;
  isActive: boolean;
}

export interface BanquetFacilityItem {
  id: string;
  name: string;
  isEnabled: boolean;
  description?: string;
  iconName?: string;
}

export interface BanquetEventTypeItem {
  id: string;
  name: string;
  description: string;
  image?: string;
  isActive: boolean;
}

export interface BanquetPackageItem {
  id: string;
  name: string;
  pricePerGuest?: number;
  guestCapacity: string;
  includes: string[];
  isActive: boolean;
  tagline?: string;
}

export interface BanquetHallInfo {
  name: string;
  description: string;
  minCapacity: string;
  maxCapacity: string;
  seatingArrangements: string;
  facilitiesNote: string;
  contactCTA: string;
}

export interface HomepageHeroConfig {
  title: string;
  subtitle: string;
  heroImage: string;
  primaryCtaText: string;
  secondaryCtaText: string;
}

export interface HomepageSectionItem {
  id: string;
  name: string;
  description: string;
  isVisible: boolean;
  order: number;
}

export interface DayOperatingHours {
  day: string;
  isOpen: boolean;
  openTime: string;
  closeTime: string;
}

export interface BusinessSettings {
  businessName: string;
  category: string;
  phone: string;
  whatsappNumber: string;
  email: string;
  address: string;
  googleMapsEmbedUrl: string;
  googleMapsDirectionsUrl: string;
  instagramHandle: string;
  instagramFollowers: string;
  openingHoursSummary: string;
  operatingHours: DayOperatingHours[];
}

export interface WhatsAppConfig {
  whatsappNumber: string;
  enableRestaurant: boolean;
  enableTakeaway: boolean;
  enableBanquet: boolean;
  enableGeneral: boolean;
  restaurantTemplate: string;
  takeawayTemplate: string;
  banquetTemplate: string;
  generalTemplate: string;
}

export interface SEOSettings {
  title: string;
  metaDescription: string;
  focusKeywords: string[];
  keywords: string[];
  ogImage: string;
  socialTitle: string;
  socialDescription: string;
  canonicalUrl: string;
  enableSitemap: boolean;
  enableRobots: boolean;
}

export interface LocationLandmark {
  name: string;
  distance: string;
}

export interface LocationSettings {
  address: string;
  corridor: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  googleMapsEmbedUrl: string;
  googleMapsDirectionsUrl: string;
  nearbyLandmarks: LocationLandmark[];
}

export type StaffRole =
  | 'Super Admin'
  | 'Manager'
  | 'Restaurant Staff'
  | 'Banquet Manager'
  | 'Content Manager'
  | 'super_admin'
  | 'manager'
  | 'restaurant_staff'
  | 'banquet_manager'
  | 'content_manager';

export type AdminRole = StaffRole;

export interface StaffUser {
  id: string;
  name: string;
  email: string;
  role: StaffRole;
  avatar?: string;
  lastActive: string;
  lastLoginAt?: string;
  status: 'active' | 'inactive';
  isActive?: boolean;
  mobile?: string;
}

export type AdminUser = StaffUser;

export interface AdminActivityItem {
  id: string;
  title: string;
  type: 'enquiry' | 'menu' | 'banquet' | 'media' | 'settings' | 'review';
  timestamp: string;
  actor: string;
  details?: string;
  action?: string;
  staffName?: string;
}

export interface GalleryMediaItem {
  id: string;
  title: string;
  category: 'restaurant' | 'banquet';
  subCategory: 'exterior' | 'interior' | 'dining' | 'food' | 'hall' | 'seating' | 'decorations' | 'events';
  image: string;
  caption: string;
  isFeatured: boolean;
  isPublished: boolean;
  createdAt: string;
}

export type AdminNavSection =
  | 'dashboard'
  | 'website'
  | 'restaurant'
  | 'banquet'
  | 'enquiries'
  | 'media'
  | 'reviews'
  | 'settings'
  | 'location'
  | 'seo'
  | 'users'
  | 'backup';

